#include <windows.h>
#include "..\..\renderclient.h"
#include "..\..\3d.h"

void UPD_Window(int *nu,void* data,Camera_* cam,RenderClient *rc);
void UPD_SelectGame(int *nu,void* data,Camera_* cam,RenderClient *rc);//net game or single player
//I commented this one extensively..so look at this one first
void UPD_SelectProvider(int *nu,void* data,Camera_* cam,RenderClient *rc);//ipx or spx or ...
void UPD_Conect_Create(int *nu,void* data,Camera_* cam,RenderClient *rc);//host or join game


//standart
void DLLInterface_ShutDown();
