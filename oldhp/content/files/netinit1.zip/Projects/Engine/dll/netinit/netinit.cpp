// note: all function calls to external provided class membes have to pass
// the adress of the object the function belongs to, to solve the thiscall
// requirement

//has to be included!!
#include "..\pnpdll0005.h"

#include "menu.h"
#include "netinit.h"

RenderClient *Window_Render_View=NULL;
void_ret_dword returnControl=NULL;

void DLLInterface_ShutDown();

//<<<<DLLInterface functions>>>>

void DLLInterface_ReturnControl(void_ret_dword func)
{
	returnControl=func;
}

//optional interface func
void DLLInterface_CheckVersion()
{
	if(atof(Version)<PNPDLL_VERSION)
		((error)(Server,"server version  is %d but %d is needed",(DWORD)(10000*atof(Version)),(DWORD)(10000*PNPDLL_VERSION)));
	((_log)(Server,"netinit.dll(ref%d) (c) Alex ",(DWORD)(10000*PNPDLL_VERSION)));
}

//optional interface func
void DLLInterface_Register()
{
	if(*Net_Inited||*Net_Locked)
	{
		((_log)(Server,"(*Net) is locked or already inited."));
		__RUNFUNC("netinit.dll","DLLInterface_ShutDown");
	}
	*Net_Locked=1;
}

//<<DllFuncInit func..must be avalable in all dlls>>
void DLLInterface_Init()//push all funcs you need
{
	__TESTCOM();

	__GETCMD(PNP_VERSION,&Version);
	__GETCMD(CMD_ERROR,&error);
	__GETCMD(CMD_LOG,&_log);

	__RUNFUNC("netinit.dll","DLLInterface_CheckVersion");
	
	__GETCMD(VAL_TIME,&Time);

	__GETCMD(OBJ_IMPORTER,&Importer);
	
		__GETCMD(CMD_IMPORTDLL,&importdll);
		__GETCMD(CMD_UNLOADDLL,&unloaddll);
		__GETCMD(CMD_GETADRESS,&getadress);
		__GETCMD(CMD_REGISTER,&reg);
		__GETCMD(CMD_ISREGISTERED,&isregistered);
		__GETCMD(CMD_GETCLIENTAREA,&getclientarea);
		__GETCMD(CMD_IMPORTFUNC,&importfunc);
		
		__GETCMD(VAL_DLLDATA,&DLLData);
		
	__GETCMD(OBJ_WINMANAGER,&WinManager);

		__GETCMD(VAL_LINES,&Lines);
		__GETCMD(VAL_SCREENBUFFER,&ScreenBuffer);

	__GETCMD(OBJ_RASTERIZER,&Rasterizer);

		__GETCMD(CMD_DRAWTEXT,&drawtext);
		__GETCMD(CMD_DRAWQUAD,&drawquad);
		__GETCMD(CMD_TEXACTIVATE,&texactivate);
		__GETCMD(CMD_TEXARRAY,&texarray);
		__GETCMD(CMD_TEXEREASE,&texerease);
		__GETCMD(CMD_TEXLOAD,&texload);
		__GETCMD(CMD_TPUACTIVATE,&tpuactivate);

		__GETCMD(VAL_NUMTPUS,&Num_TPUs);
		__GETCMD(VAL_ACTTPU,&Act_TPU);

	__GETCMD(OBJ_NET,&Net);

		__GETCMD(CMD_HOSTCONNECT,&hostconnect);
		__GETCMD(CMD_HOSTOPEN,&hostopen);	
		__GETCMD(CMD_CREATEPLAYER,&createplayer);
		__GETCMD(CMD_RECEAVEMESSAGES,&receavemessages);
		__GETCMD(CMD_SEND,&dpsend);			
		__GETCMD(CMD_KILLDP,&killdp);				
		__GETCMD(CMD_CREATEPROVIDERLIST,&createproviderlist);
		__GETCMD(CMD_CREATESESSIONLIST,&createsessionslist);	
		__GETCMD(CMD_CHOOSEPROVIDER,&chooseprovider);		

		__GETCMD(VAL_HOSTGAME,&HostGame);		
		__GETCMD(VAL_NET_INITED,&Net_Inited);		
		__GETCMD(VAL_NET_LOCKED,&Net_Locked);		

		__GETCMD(VAL_PROVIDERINFO,&ProviderInfo);		

		__GETCMD(CMD_NETSERVERTHREAD,&netserverthread);		
/*
	__GETCMD(OBJ_SOUND,&Sound);

		__GETCMD(CMD_S_LOADSOUND,&loadsound);
		__GETCMD(CMD_S_UPLOADSOUND,&uploadsound);
		__GETCMD(CMD_S_RESIDENTSOUND,&residentsound);

		__GETCMD(CMD_S_PLAYSOUND,&playsound);
		__GETCMD(CMD_S_STOPSOUND,&stopsound);
		__GETCMD(CMD_S_RESETSOUND,&resetsound);	

		__GETCMD(CMD_S3D_SET3DSOUNDPOS,&set3dsoundpos);
		__GETCMD(CMD_S3D_SETLISTENERDIR,&setlistenerdir);	
		__GETCMD(CMD_S3D_SETLISTENERPOS,&setlistenerpos);

		__GETCMD(CMD_CDA_CLOSECDAUDIO,&closecdaudio);
		__GETCMD(CMD_CDA_PLAYCDAUDIO,&playcdaudio);
		__GETCMD(CMD_CDA_READCDINFOS,&readcdinfos);	
		__GETCMD(CMD_CDA_GETTRACKLENACT,&gettracklenact);
		__GETCMD(CMD_CDA_GETTRACKLEN,&gettracklen);	
		__GETCMD(CMD_CDA_GETTRACKTIME,&gettracktime);
		__GETCMD(CMD_CDA_ENABLE,&cda_enable);
*/	
	__RUNFUNC("netinit.dll","DLLInterface_Register");

	__GETWINDOW(UPD_Window,UPD_SelectGame,"netinit.dll",0,0,1,1,0.01,0.01,0.01,&Window_Render_View);
}

//<<DllShutDown func..must be avalable in all dlls>>
void DLLInterface_ShutDown()
{
	__DELETEWINDOW(Window_Render_View->number);
	((_log)(Server,"netinit.dll shutdown"));
//	__UPDATEALL();
	if(returnControl)
	{
		try
		{
			((returnControl)(*HostGame));
		}
		catch(...)
		{
			((_log)(Server,"An error occured while trying to return control."));	
		}
	}
}

