#ifndef __NETINT_PLUGIN_CLIENT
#define __NETINT_PLUGIN_CLIENT


#ifdef NETINIT_EXPORTS
#define DLL_API __declspec(dllexport)
#else
#define DLL_API __declspec(dllimport)
#endif

//the dll will return gametype 
#define NET_GAME_CLIENT 0
#define NET_GAME_HOST 1

//pas this to type DLLInterface_ReturnControl
typedef void(__cdecl*void_ret_dword)(DWORD dw);
//void DLLInterface_ReturnControl(void_ret_dword func);

//use DLL_API for unique functions to be exported


#endif