#include <windows.h>
#include <stdio.h> 
#include <process.h>

#include "..\pnpdll0005.h"

#include "menu.h"


#pragma warning( disable : 4096 )
#pragma warning( disable : 4800 )

//bool IsKeyDown(int virtKeyCode){if (GetAsyncKeyState(virtKeyCode) & 0x8000) return TRUE;return FALSE;}
float absf(float x){if(x<0)return x;else return x;}

void UPD_Window(int *nu,void* data,Camera_* cam,RenderClient *rc)
//my standat event update func...
//useable for all menus
//DO NOT DRAW IN EVENT FUNC!!
{
	if(IsKeyDown(VK_UP)||IsKeyDown(VK_DOWN)||IsKeyDown(VK_RETURN)
		||IsKeyDown(VK_ESCAPE)||IsKeyDown(VK_CONTROL))
		*nu=2;

}


void UPD_Game(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();
	glScalef (1, -1, -1);//left hand system
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	glScalef (absf(cam->zoom), -absf(cam->zoom), -1);//left hand system
	((drawquad)((*Rasterizer),43,-1,-1,2,2,1,0.0,0.0,0.0,1,1));	//draw background
	gluPerspective(cam->fov, cam->aspect, cam->nearclip, cam->farclip);
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();

	static bool unloaded=0;
	if(!unloaded)
	{
		*Net_Locked=0;
		*Net_Inited=1;
		__DLLUNLOAD("netinit.dll");
		unloaded=1;
	}
}


void UPD_Select_Session(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();
	glScalef (1, -1, -1);//left hand system
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	glScalef (absf(cam->zoom), -absf(cam->zoom), -1);//left hand system
	static BYTE active =0;
	int NumSession=0;
	while((ProviderInfo+NumSession)->Name)
	{
		NumSession++;
	}
	NumSession--;

	if(IsKeyDown(VK_UP))
	{
		if(!active)active=NumSession;
		else active--;
		do{}while(IsKeyDown(VK_UP));
	}
	else if(IsKeyDown(VK_DOWN))
	{
		if(active==NumSession)active=0;
		else active++;
		do{}while(IsKeyDown(VK_DOWN));
	}
	else if(IsKeyDown(VK_ESCAPE))
	{
		rc->RenderWindow=UPD_SelectProvider;
		do{}while(IsKeyDown(VK_ESCAPE));
		*nu=2;
	}
	else if(IsKeyDown(VK_RETURN))
	{
		if(NumSession>=0)
		{
			((hostconnect)((*Net),active));
			((createplayer)((*Net),&Server->NetId));
			((push)(Server,1,GET_NET));
			((push)(Server,1,RETRY_CONNECTION));
			do{}while(IsKeyDown(VK_RETURN));
			rc->RenderWindow=UPD_Game;
			rc->UpdateWindow=UPD_Window;
			*nu=2;
		}
	}

	glDepthFunc(GL_ALWAYS);
	((drawquad)((*Rasterizer),43,-1,-1,2,2,1,0.7,0.7,0.7,1,1));	//draw background

	((drawtext)((*Rasterizer),"select session",-0.6f,0.8f,0.1f,1,1,1,1,1,1));
	if(NumSession>=0)
	{
		int i=0;
		while((ProviderInfo+i)->Name)
		{
			float red;
			if(active==i)
				red=0;
			else red=1;
			((drawtext)((*Rasterizer),strlwr((ProviderInfo+i)->Name),-0.7,0.7-i*0.1f,0.08f,1,1,red,red,1,1));
			i++;
		}
	}
	else
	{
		((drawtext)((*Rasterizer),"No session found",-0.5f,0.05f,0.08f,1,1,0,0,1,1));		
		((drawtext)((*Rasterizer),"Press esc to retry",-0.55f,-0.05f,0.08f,1,1,0,0,1,1));				
	}
	glDepthFunc(GL_LEQUAL);
	gluPerspective(cam->fov, cam->aspect, cam->nearclip, cam->farclip);
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();

}

void UPD_CreateSessionList(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	DWORD timeout=3000;
	((createsessionslist)((*Net),timeout));
	rc->RenderWindow=UPD_Select_Session;
	*nu=2;
}

void UPD_Search_Session(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();
	glScalef (1, -1, -1);//left hand system
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	glScalef (absf(cam->zoom), -absf(cam->zoom), -1);//left hand system
	glDepthFunc(GL_ALWAYS);
	((drawquad)((*Rasterizer),43,-1,-1,2,2,1,0.7,0.7,0.7,1,1));	//draw background

		((drawtext)((*Rasterizer),"Searching session",-0.7f,0.05f,0.1f,1,1,1,1,1,1));		
		((drawtext)((*Rasterizer),"Please wait",-0.5f,-0.05f,0.1f,1,1,1,1,1,1));		
		
	rc->RenderWindow=UPD_CreateSessionList;
	*nu=2;
	glDepthFunc(GL_LEQUAL);
	gluPerspective(cam->fov, cam->aspect, cam->nearclip, cam->farclip);
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();
}

void UPD_SelectProvider(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();
	glScalef (1, -1, -1);//left hand system
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	glScalef (absf(cam->zoom), -absf(cam->zoom), -1);//left hand system
	static BYTE active =0;
	int NumProvider=0;
	while((ProviderInfo+NumProvider)->Text)
	{
		NumProvider++;
	}
	NumProvider--;

	if(IsKeyDown(VK_UP))
	{
		if(!active)active=NumProvider;
		else active--;
		do{}while(IsKeyDown(VK_UP));
	}
	else if(IsKeyDown(VK_DOWN))
	{
		if(active==NumProvider)active=0;
		else active++;
		do{}while(IsKeyDown(VK_DOWN));
	}
	else if(IsKeyDown(VK_ESCAPE))
	{
		rc->RenderWindow=UPD_Conect_Create;
		do{}while(IsKeyDown(VK_ESCAPE));
		if(*HostGame)
			((dpsend)((*Net),Server->ServerId,2,SHUTDOWN,0));

		((killdp)((*Net)));
		Server->Connection=0;
		Server->ServerId=0;
		Server->NumPlayer=0;
		*nu=2;
	}
	else if(IsKeyDown(VK_RETURN))
	{
		if(*HostGame&&Server->Connection)
		{
			((dpsend)((*Net),Server->ServerId,2,CREATE_DPLAY,active));
			rc->RenderWindow=UPD_Game;
			rc->UpdateWindow=UPD_Window;
			*nu=2;
		}
		else 
		{
			((chooseprovider)((*Net),active));
			rc->RenderWindow=UPD_Search_Session;
			*nu=2;
		}
		do{}while(IsKeyDown(VK_RETURN));
		*nu=2;
	}

	glDepthFunc(GL_ALWAYS);
	((drawquad)((*Rasterizer),43,-1,-1,2,2,1,0.7,0.7,0.7,1,1));	//draw background

	//let's see how many providers

	((drawtext)((*Rasterizer),"select provider",-0.7f,0.8f,0.1f,1,1,1,1,1,1));
	if(*HostGame&&!Server->Connection)
	{
		((drawtext)((*Rasterizer),"Contacting server",-0.7f,0.05f,0.1f,1,1,1,1,1,1));		
		((drawtext)((*Rasterizer),"Please wait",-0.5f,-0.05f,0.1f,1,1,1,1,1,1));		
	}
	else
	{

		int i=0;
		while((ProviderInfo+i)->Text)
		{
			float red;
			if(active==i)
				red=0;
			else red=1;
			((drawtext)((*Rasterizer),strlwr((ProviderInfo+i)->Text),-0.7,0.7-i*0.1f,0.08f,1,1,red,red,1,1));
			i++;
		}
	}
	glDepthFunc(GL_LEQUAL);
	gluPerspective(cam->fov, cam->aspect, cam->nearclip, cam->farclip);
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();

}

void UPD_Conect_Create(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();
	glScalef (1, -1, -1);//left hand system
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	glScalef (absf(cam->zoom), -absf(cam->zoom), -1);//left hand system
	static BYTE active =0;

	if(IsKeyDown(VK_UP))
	{
		if(!active)active=1;
		else active--;
		do{}while(IsKeyDown(VK_UP));
	}
	else if(IsKeyDown(VK_DOWN))
	{
		if(active==1)active=0;
		else active++;
		do{}while(IsKeyDown(VK_DOWN));
	}
	else if(IsKeyDown(VK_ESCAPE))
	{
		rc->RenderWindow=UPD_SelectGame;
		do{}while(IsKeyDown(VK_ESCAPE));
		*nu=2;
	}
	else if(IsKeyDown(VK_RETURN))
	{
		if(active==1)
		{
				
			((_log)(Server,"creating ServerThread"));
			_beginthread( netserverthread, 0x1000, NULL );	
//			((push)(Server,1,RETRY_CONNECTION));
			rc->RenderWindow=UPD_SelectProvider;
			((createplayer)((*Net),&Server->NetId));
			((push)(Server,1,RETRY_CONNECTION));
			*HostGame=1;
			*nu=2;
		}
		else if(active==0)
		{
			rc->RenderWindow=UPD_SelectProvider;
			*HostGame=0;
			*nu=2;
		}
		do{}while(IsKeyDown(VK_RETURN));
	}

	glDepthFunc(GL_ALWAYS);
	((drawquad)((*Rasterizer),43,-1,-1,2,2,1,0.7,0.7,0.7,1,1));	//draw background

	//let's see how many providers

	float red[2]={1,1};
	red[active]=0;


	((drawtext)((*Rasterizer),"Join game",-0.35f,0.05f,0.1f,1,1,red[0],red[0],1,1));
	((drawtext)((*Rasterizer),"Host game",-0.35f,-0.05f,0.1f,1,1,red[1],red[1],1,1));
	glDepthFunc(GL_LEQUAL);
	gluPerspective(cam->fov, cam->aspect, cam->nearclip, cam->farclip);
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();
}

void UPD_SelectGame(int *nu,void* data,Camera_* cam,RenderClient *rc)
//let the user select what game(net/single player) he want's
//only called if UPD_Window set's NeedUpdate(nu) to 1
{
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();
	glScalef (1, -1, -1);//left hand system
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	glScalef (absf(cam->zoom), -absf(cam->zoom), -1);//left hand system
	static BYTE active=0;//which button is highlighted?
	if(IsKeyDown(VK_UP))
	{
		if(!active)active=2;//max 2..warp around
		else active--;
		do{}while(IsKeyDown(VK_UP));
	}
	else if(IsKeyDown(VK_DOWN))
	{
		if(active==2)active=0;
		else active++;
		do{}while(IsKeyDown(VK_DOWN));
	}
	else if(IsKeyDown(VK_RETURN))//button activated
	{
		if(active==0)//butoon "net game" activated
		{
			//do what is needed..
			((createproviderlist)((*Net)));//let Dplay enumerate all providers(ipx/tcp/..)
			rc->RenderWindow=UPD_Conect_Create;//set new render callback(renders subsequent menu)
			*nu=2;//tell window to update(as gfx changed)
			//(if no other update event for this window appears it willbeupdated twice..to fill
			//front and backbuffer)
		}
		else if(active==1)
		{
			((_log)((*WinManager),"creating ServerThread"));//single player..create server..
			_beginthread( netserverthread, 0x1000, NULL );	
			((createplayer)((*Net),&Server->NetId));
			((push)(Server,1,RETRY_CONNECTION));
			rc->RenderWindow=UPD_Game;
			rc->UpdateWindow=UPD_Window;
			*HostGame=1;
			*nu=2;
		}
		else
		{
			((push)(Server,1,SHUTDOWN));
		}
		do{}while(IsKeyDown(VK_RETURN));
	}

	float red[3]={1,1,1};//preset red
	red[active]=0;//make active button drawn red
	glDepthFunc(GL_ALWAYS);

	((drawquad)((*Rasterizer),43,-1,-1,2,2,1,0.7,0.7,0.7,1,1));	//draw background(fixed tex pos)
	((drawtext)((*Rasterizer),          "Net game",-0.3f,0.1f,0.1f,1,1,red[0],red[0],1,1));
	((drawtext)((*Rasterizer),"Single player game",-0.7f,0.0f,0.1f,1,1,red[1],red[1],1,1));
	((drawtext)((*Rasterizer),              "Exit",-0.15f,-0.1f,0.1f,1,1,red[2],red[2],1,1));
	glDepthFunc(GL_LEQUAL);

	gluPerspective(cam->fov, cam->aspect, cam->nearclip, cam->farclip);
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();
}

