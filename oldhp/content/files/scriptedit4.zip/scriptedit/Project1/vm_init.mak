/*ScripEdit*/

  #pragma enable debug_info

  #define _ALLIGN DWORD

//include_file_insert_pos
//#include "debug\vm_init.asm"

//#include "release\vm_init.asm"

//#include "header\server.h"

//#include "header\defs.h"

//#include "header\error.h"

//#include "header\memory.h"

//#include "header\importer.h"


//script_file_insert_pos
#compile "source\test.c"


