@echo off
copy vm_init.vxe c:\windows\desktop\q_test\scripts