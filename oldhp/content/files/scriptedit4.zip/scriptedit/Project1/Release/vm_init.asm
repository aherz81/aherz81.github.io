<Header Section>
Compiler Version: 5.100000, Debug Info: 0
<Code Section>
0: jmp const 4106 
19: mov data , const 440 
28: sne 
30: mov reg1 , const 1159744854 
39: mov [ const 0 ] , reg1 
50: mov reg1 , const 1919906418 
59: mov [ const 4 ] , reg1 
70: mov reg1 , const 1634882592 
79: mov [ const 8 ] , reg1 
90: mov reg1 , const 1684369520 
99: mov [ const 12 ] , reg1 
110: mov reg1 , const 623321146 
119: mov [ const 16 ] , reg1 
130: mov reg1 , const 10099 
139: mov [ const 20 ] , reg1 
150: mov reg1 , const 0 
159: mov [ const 24 ] , reg1 
170: mov reg1 , const 1667594341 
179: mov [ const 28 ] , reg1 
190: mov reg1 , const 1852404853 
199: mov [ const 32 ] , reg1 
210: mov reg1 , const 1297490023 
219: mov [ const 36 ] , reg1 
230: mov reg1 , const 1768835360 
239: mov [ const 40 ] , reg1 
250: mov reg1 , const 1818323316 
259: mov [ const 44 ] , reg1 
270: mov reg1 , const 1952543593 
279: mov [ const 48 ] , reg1 
290: mov reg1 , const 544108393 
299: mov [ const 52 ] , reg1 
310: mov reg1 , const 1769104211 
319: mov [ const 56 ] , reg1 
330: mov reg1 , const 773878896 
339: mov [ const 60 ] , reg1 
350: mov reg1 , const 11822 
359: mov [ const 64 ] , reg1 
370: mov reg1 , const 28 
379: mov [ const 68 ] , reg1 
390: mov reg1 , const 1701209458 
399: mov [ const 72 ] , reg1 
410: mov reg1 , const 1668179314 
419: mov [ const 76 ] , reg1 
430: mov reg1 , const 1818504805 
439: mov [ const 80 ] , reg1 
450: mov reg1 , const 108 
459: mov [ const 84 ] , reg1 
470: mov reg1 , const 72 
479: mov [ const 88 ] , reg1 
490: mov reg1 , const 1701209458 
499: mov [ const 92 ] , reg1 
510: mov reg1 , const 1668179314 
519: mov [ const 96 ] , reg1 
530: mov reg1 , const 1818504805 
539: mov [ const 100 ] , reg1 
550: mov reg1 , const 108 
559: mov [ const 104 ] , reg1 
570: mov reg1 , const 92 
579: mov [ const 108 ] , reg1 
590: mov reg1 , const 1769104211 
599: mov [ const 112 ] , reg1 
610: mov reg1 , const 1159754864 
619: mov [ const 116 ] , reg1 
630: mov reg1 , const 1969448312 
639: mov [ const 120 ] , reg1 
650: mov reg1 , const 1852795252 
659: mov [ const 124 ] , reg1 
670: mov reg1 , const 1835619360 
679: mov [ const 128 ] , reg1 
690: mov reg1 , const 622869093 
699: mov [ const 132 ] , reg1 
710: mov reg1 , const 1936531556 
719: mov [ const 136 ] , reg1 
730: mov reg1 , const 0 
739: mov [ const 140 ] , reg1 
750: mov reg1 , const 112 
759: mov [ const 144 ] , reg1 
770: mov reg1 , const 1601403219 
779: mov [ const 148 ] , reg1 
790: mov reg1 , const 1869440333 
799: mov [ const 152 ] , reg1 
810: mov reg1 , const 976910706 
819: mov [ const 156 ] , reg1 
830: mov reg1 , const 1635021676 
839: mov [ const 160 ] , reg1 
850: mov reg1 , const 29556 
859: mov [ const 164 ] , reg1 
870: mov reg1 , const 148 
879: mov [ const 168 ] , reg1 
890: mov reg1 , const 1684234079 
899: mov [ const 172 ] , reg1 
910: mov reg1 , const 543974245 
919: mov [ const 176 ] , reg1 
930: mov reg1 , const 1684631414 
939: mov [ const 180 ] , reg1 
950: mov reg1 , const 1835355424 
959: mov [ const 184 ] , reg1 
970: mov reg1 , const 1952543827 
979: mov [ const 188 ] , reg1 
990: mov reg1 , const 1143613555 
999: mov [ const 192 ] , reg1 
1010: mov reg1 , const 1146244951 
1019: mov [ const 196 ] , reg1 
1030: mov reg1 , const 41 
1039: mov [ const 200 ] , reg1 
1050: mov reg1 , const 172 
1059: mov [ const 204 ] , reg1 
1070: mov reg1 , const 1684234079 
1079: mov [ const 208 ] , reg1 
1090: mov reg1 , const 543974245 
1099: mov [ const 212 ] , reg1 
1110: mov reg1 , const 1684631414 
1119: mov [ const 216 ] , reg1 
1130: mov reg1 , const 1835355424 
1139: mov [ const 220 ] , reg1 
1150: mov reg1 , const 1952543827 
1159: mov [ const 224 ] , reg1 
1170: mov reg1 , const 1143613555 
1179: mov [ const 228 ] , reg1 
1190: mov reg1 , const 1146244951 
1199: mov [ const 232 ] , reg1 
1210: mov reg1 , const 41 
1219: mov [ const 236 ] , reg1 
1230: mov reg1 , const 208 
1239: mov [ const 240 ] , reg1 
1250: mov reg1 , const 1632783431 
1259: mov [ const 244 ] , reg1 
1270: mov reg1 , const 1919251571 
1279: mov [ const 248 ] , reg1 
1290: mov reg1 , const 1919253097 
1299: mov [ const 252 ] , reg1 
1310: mov reg1 , const 0 
1319: mov [ const 256 ] , reg1 
1330: mov reg1 , const 244 
1339: mov [ const 260 ] , reg1 
1350: mov reg1 , const 1701666655 
1359: mov [ const 264 ] , reg1 
1370: mov reg1 , const 1464082541 
1379: mov [ const 268 ] , reg1 
1390: mov reg1 , const 709120591 
1399: mov [ const 272 ] , reg1 
1410: mov reg1 , const 1935757856 
1419: mov [ const 276 ] , reg1 
1430: mov reg1 , const 1769104756 
1439: mov [ const 280 ] , reg1 
1450: mov reg1 , const 7497082 
1459: mov [ const 284 ] , reg1 
1470: mov reg1 , const 0 
1479: mov [ const 288 ] , reg1 
1490: mov reg1 , const 264 
1499: mov [ const 292 ] , reg1 
1510: mov reg1 , const 1701666655 
1519: mov [ const 296 ] , reg1 
1530: mov reg1 , const 1464082541 
1539: mov [ const 300 ] , reg1 
1550: mov reg1 , const 709120591 
1559: mov [ const 304 ] , reg1 
1570: mov reg1 , const 1935757856 
1579: mov [ const 308 ] , reg1 
1590: mov reg1 , const 1769104756 
1599: mov [ const 312 ] , reg1 
1610: mov reg1 , const 7497082 
1619: mov [ const 316 ] , reg1 
1630: mov reg1 , const 0 
1639: mov [ const 320 ] , reg1 
1650: mov reg1 , const 296 
1659: mov [ const 324 ] , reg1 
1670: mov reg1 , const 1601403219 
1679: mov [ const 328 ] , reg1 
1690: mov reg1 , const 7628110 
1699: mov [ const 332 ] , reg1 
1710: mov reg1 , const 0 
1719: mov [ const 336 ] , reg1 
1730: mov reg1 , const 328 
1739: mov [ const 340 ] , reg1 
1750: mov reg1 , const 1701666655 
1759: mov [ const 344 ] , reg1 
1770: mov reg1 , const 1464082541 
1779: mov [ const 348 ] , reg1 
1790: mov reg1 , const 709120591 
1799: mov [ const 352 ] , reg1 
1810: mov reg1 , const 1952796192 
1819: mov [ const 356 ] , reg1 
1830: mov reg1 , const 0 
1839: mov [ const 360 ] , reg1 
1850: mov reg1 , const 344 
1859: mov [ const 364 ] , reg1 
1870: mov reg1 , const 1701666655 
1879: mov [ const 368 ] , reg1 
1890: mov reg1 , const 1464082541 
1899: mov [ const 372 ] , reg1 
1910: mov reg1 , const 709120591 
1919: mov [ const 376 ] , reg1 
1930: mov reg1 , const 1952796192 
1939: mov [ const 380 ] , reg1 
1950: mov reg1 , const 0 
1959: mov [ const 384 ] , reg1 
1970: mov reg1 , const 368 
1979: mov [ const 388 ] , reg1 
1990: mov reg1 , const 29477 
1999: mov [ const 392 ] , reg1 
2010: mov reg1 , const 392 
2019: mov [ const 396 ] , reg1 
2030: mov reg1 , const 1768843622 
2039: mov [ const 400 ] , reg1 
2050: mov reg1 , const 1684367475 
2059: mov [ const 404 ] , reg1 
2070: mov reg1 , const 541939232 
2079: mov [ const 408 ] , reg1 
2090: mov reg1 , const 1953066569 
2099: mov [ const 412 ] , reg1 
2110: mov reg1 , const 1768710505 
2119: mov [ const 416 ] , reg1 
2130: mov reg1 , const 1769234803 
2139: mov [ const 420 ] , reg1 
2150: mov reg1 , const 1394634351 
2159: mov [ const 424 ] , reg1 
2170: mov reg1 , const 1885958755 
2179: mov [ const 428 ] , reg1 
2190: mov reg1 , const 116 
2199: mov [ const 432 ] , reg1 
2210: mov reg1 , const 400 
2219: mov [ const 436 ] , reg1 
2230: ret 
2232: mov reg1 , data 
2237: sne 
2239: pushn reg1 , const 2 
2248: mov reg2 , const 18 
2257: mov reg2 , [ reg2 ] 
2264: push reg2 
2267: mov reg2 , const 24 
2276: mov reg2 , [ reg2 ] 
2283: push reg2 
2286: mov reg2 , reg1 
2291: add reg2 , const 4 
2300: mov reg2 , [ reg2 ] 
2307: push reg2 
2310: se 
2312: call const 84 
2319: mov reg3 , reg1 
2324: add data , const 12 
2333: pop reg1 , const 2 
2342: mov reg2 , reg3 
2347: sne 
2349: mov data , reg1 
2354: ret 
2356: mov reg1 , data 
2361: sne 
2363: sub data , const 24 
2372: pushn reg1 , const 2 
2381: se 
2383: call const 84 
2390: mov reg3 , reg1 
2395: pop reg1 , const 2 
2404: mov reg2 , reg3 
2409: mov reg3 , reg1 - const 4 
2420: mov [ reg3 ] , reg2 
2427: mov reg2 , const 18 
2436: mov reg2 , [ reg2 ] 
2443: mov reg3 , reg1 - const 24 
2454: mov [ reg3 ] , reg2 
2461: mov reg2 , const 60 
2470: mov reg3 , const 2232 
2479: mov [ reg2 ] , reg3 
2486: pushn reg1 , const 2 
2495: mov reg2 , const 18 
2504: mov reg2 , [ reg2 ] 
2511: push reg2 
2514: mov reg2 , const 68 
2523: mov reg2 , [ reg2 ] 
2530: push reg2 
2533: call const 84 
2540: mov reg3 , reg1 
2545: add data , const 8 
2554: pop reg1 , const 2 
2563: mov reg2 , reg3 
2568: mov reg2 , const 0 
2577: mov reg3 , reg2 
2582: mul reg3 , const 4 
2591: mov reg4 , reg1 - const 20 
2602: add reg3 , reg4 
2607: mov reg2 , reg3 
2612: mov reg3 , const 0 
2621: mov [ reg2 ] , reg3 
2628: mov reg2 , const 1 
2637: mov reg3 , reg2 
2642: mul reg3 , const 4 
2651: mov reg4 , reg1 - const 20 
2662: add reg3 , reg4 
2667: mov reg2 , reg3 
2672: mov reg3 , const 0 
2681: mov [ reg2 ] , reg3 
2688: mov reg2 , const 2 
2697: mov reg3 , reg2 
2702: mul reg3 , const 4 
2711: mov reg4 , reg1 - const 20 
2722: add reg3 , reg4 
2727: mov reg2 , reg3 
2732: mov reg3 , const 1065353216 
2741: mov [ reg2 ] , reg3 
2748: mov reg2 , const 3 
2757: mov reg3 , reg2 
2762: mul reg3 , const 4 
2771: mov reg4 , reg1 - const 20 
2782: add reg3 , reg4 
2787: mov reg2 , reg3 
2792: mov reg3 , const 1065353216 
2801: mov [ reg2 ] , reg3 
2808: pushn reg1 , const 2 
2817: mov reg2 , const 42 
2826: mov reg2 , [ reg2 ] 
2833: push reg2 
2836: mov reg2 , const 88 
2845: mov reg2 , [ reg2 ] 
2852: push reg2 
2855: mov reg2 , reg1 - const 20 
2866: push reg2 
2869: call const 84 
2876: mov reg3 , reg1 
2881: add data , const 12 
2890: pop reg1 , const 2 
2899: mov reg2 , reg3 
2904: pushn reg1 , const 2 
2913: mov reg2 , const 108 
2922: mov reg2 , [ reg2 ] 
2929: push reg2 
2932: call const 84 
2939: mov reg3 , reg1 
2944: add data , const 4 
2953: pop reg1 , const 2 
2962: mov reg2 , reg3 
2967: mov reg2 , reg1 - const 4 
2978: pushn reg1 , const 3 
2987: call const 84 
2994: mov reg4 , reg1 
2999: pop reg1 , const 3 
3008: mov reg5 , reg1 - const 4 
3019: mov reg5 , [ reg5 ] 
3026: sub reg4 , reg5 
3031: mov reg3 , reg4 
3036: mov [ reg2 ] , reg3 
3043: pushn reg1 , const 2 
3052: mov reg2 , const 18 
3061: mov reg2 , [ reg2 ] 
3068: push reg2 
3071: mov reg2 , const 144 
3080: mov reg2 , [ reg2 ] 
3087: push reg2 
3090: mov reg2 , reg1 - const 4 
3101: mov reg2 , [ reg2 ] 
3108: push reg2 
3111: call const 84 
3118: mov reg3 , reg1 
3123: add data , const 12 
3132: pop reg1 , const 2 
3141: mov reg2 , reg3 
3146: pushn reg1 , const 2 
3155: mov reg2 , const 42 
3164: mov reg2 , [ reg2 ] 
3171: push reg2 
3174: mov reg2 , const 168 
3183: mov reg2 , [ reg2 ] 
3190: push reg2 
3193: mov reg2 , const 204 
3202: mov reg2 , [ reg2 ] 
3209: push reg2 
3212: call const 84 
3219: mov reg3 , reg1 
3224: add data , const 12 
3233: pop reg1 , const 2 
3242: mov reg2 , reg3 
3247: pushn reg1 , const 2 
3256: mov reg2 , const 240 
3265: mov reg2 , [ reg2 ] 
3272: push reg2 
3275: call const 84 
3282: mov reg3 , reg1 
3287: add data , const 4 
3296: pop reg1 , const 2 
3305: mov reg2 , reg3 
3310: pushn reg1 , const 2 
3319: mov reg2 , const 42 
3328: mov reg2 , [ reg2 ] 
3335: push reg2 
3338: mov reg2 , const 260 
3347: mov reg2 , [ reg2 ] 
3354: push reg2 
3357: mov reg2 , const 292 
3366: mov reg2 , [ reg2 ] 
3373: push reg2 
3376: call const 84 
3383: mov reg3 , reg1 
3388: add data , const 12 
3397: pop reg1 , const 2 
3406: mov reg2 , reg3 
3411: pushn reg1 , const 2 
3420: mov reg2 , const 324 
3429: mov reg2 , [ reg2 ] 
3436: push reg2 
3439: call const 84 
3446: mov reg3 , reg1 
3451: add data , const 4 
3460: pop reg1 , const 2 
3469: mov reg2 , reg3 
3474: pushn reg1 , const 2 
3483: mov reg2 , const 42 
3492: mov reg2 , [ reg2 ] 
3499: push reg2 
3502: mov reg2 , const 340 
3511: mov reg2 , [ reg2 ] 
3518: push reg2 
3521: mov reg2 , const 364 
3530: mov reg2 , [ reg2 ] 
3537: push reg2 
3540: call const 84 
3547: mov reg3 , reg1 
3552: add data , const 12 
3561: pop reg1 , const 2 
3570: mov reg2 , reg3 
3575: pushn reg1 , const 2 
3584: mov reg2 , const 388 
3593: mov reg2 , [ reg2 ] 
3600: push reg2 
3603: call const 84 
3610: mov reg3 , reg1 
3615: add data , const 4 
3624: pop reg1 , const 2 
3633: mov reg2 , reg3 
3638: pushn reg1 , const 2 
3647: mov reg2 , const 42 
3656: mov reg2 , [ reg2 ] 
3663: push reg2 
3666: call const 150 
3673: mov reg3 , reg1 
3678: add data , const 4 
3687: pop reg1 , const 2 
3696: mov reg2 , reg3 
3701: pushn reg1 , const 2 
3710: mov reg2 , const 18 
3719: mov reg2 , [ reg2 ] 
3726: push reg2 
3729: call const 150 
3736: mov reg3 , reg1 
3741: add data , const 4 
3750: pop reg1 , const 2 
3759: mov reg2 , reg3 
3764: pushn reg1 , const 2 
3773: mov reg2 , const 90 
3782: mov reg2 , [ reg2 ] 
3789: push reg2 
3792: call const 150 
3799: mov reg3 , reg1 
3804: add data , const 4 
3813: pop reg1 , const 2 
3822: mov reg2 , reg3 
3827: pushn reg1 , const 2 
3836: mov reg2 , const 120 
3845: mov reg2 , [ reg2 ] 
3852: push reg2 
3855: call const 150 
3862: mov reg3 , reg1 
3867: add data , const 4 
3876: pop reg1 , const 2 
3885: mov reg2 , reg3 
3890: fcmp const 0 , const 1066192077 
3903: pushn reg1 , const 2 
3912: mov reg2 , const 18 
3921: mov reg2 , [ reg2 ] 
3928: push reg2 
3931: mov reg2 , const 396 
3940: mov reg2 , [ reg2 ] 
3947: push reg2 
3950: mov reg2 , reg1 - const 24 
3961: mov reg2 , [ reg2 ] 
3968: add reg2 , const 4 
3977: push reg2 
3980: call const 84 
3987: mov reg3 , reg1 
3992: add data , const 12 
4001: pop reg1 , const 2 
4010: mov reg2 , reg3 
4015: pushn reg1 , const 2 
4024: mov reg2 , const 18 
4033: mov reg2 , [ reg2 ] 
4040: push reg2 
4043: mov reg2 , const 436 
4052: mov reg2 , [ reg2 ] 
4059: push reg2 
4062: call const 84 
4069: mov reg3 , reg1 
4074: add data , const 8 
4083: pop reg1 , const 2 
4092: mov reg2 , reg3 
4097: sne 
4099: mov data , reg1 
4104: ret 
4106:  <Link Section>
	<Imports>
		__mem DWORD* Server @ 2252
		__cdecl void _log(*DWORD,?) @ 2314
		__cdecl DWORD timeGetTime() @ 2385
		__mem DWORD* Server @ 2431
		__mem void OnError @ 2465
		__mem DWORD* Server @ 2499
		__cdecl void _log(*DWORD,?) @ 2535
		__mem DWORD* Importer @ 2821
		__cdecl void ImportDll(*DWORD,*char,*float) @ 2871
		__cdecl void __DLLRUN(*char) @ 2934
		__cdecl DWORD timeGetTime() @ 2989
		__mem DWORD* Server @ 3056
		__cdecl void _log(*DWORD,?) @ 3113
		__mem DWORD* Importer @ 3159
		__cdecl void AddLinkInfo(*DWORD,*char,*char) @ 3214
		__cdecl void RunTimeLink(*char) @ 3277
		__mem DWORD* Importer @ 3323
		__cdecl void AddLinkInfo(*DWORD,*char,*char) @ 3378
		__cdecl void RunTimeLink(*char) @ 3441
		__mem DWORD* Importer @ 3487
		__cdecl void AddLinkInfo(*DWORD,*char,*char) @ 3542
		__cdecl void RunTimeLink(*char) @ 3605
		__mem DWORD* Importer @ 3651
		__cdecl void MemStats(*DWORD) @ 3668
		__mem DWORD* Server @ 3714
		__cdecl void MemStats(*DWORD) @ 3731
		__mem DWORD* Rasterizer @ 3777
		__cdecl void MemStats(*DWORD) @ 3794
		__mem DWORD* Net @ 3840
		__cdecl void MemStats(*DWORD) @ 3857
		__mem DWORD* Server @ 3916
		__cdecl void _log(*DWORD,?) @ 3982
		__mem DWORD* Server @ 4028
		__cdecl void _log(*DWORD,?) @ 4064
	<Uses>
		global @ 62
		global @ 82
		global @ 102
		global @ 122
		global @ 142
		global @ 154
		global @ 162
		global @ 182
		global @ 202
		global @ 222
		global @ 242
		global @ 262
		global @ 282
		global @ 302
		global @ 322
		global @ 342
		global @ 362
		global @ 374
		global @ 382
		global @ 402
		global @ 422
		global @ 442
		global @ 462
		global @ 474
		global @ 482
		global @ 502
		global @ 522
		global @ 542
		global @ 562
		global @ 574
		global @ 582
		global @ 602
		global @ 622
		global @ 642
		global @ 662
		global @ 682
		global @ 702
		global @ 722
		global @ 742
		global @ 754
		global @ 762
		global @ 782
		global @ 802
		global @ 822
		global @ 842
		global @ 862
		global @ 874
		global @ 882
		global @ 902
		global @ 922
		global @ 942
		global @ 962
		global @ 982
		global @ 1002
		global @ 1022
		global @ 1042
		global @ 1054
		global @ 1062
		global @ 1082
		global @ 1102
		global @ 1122
		global @ 1142
		global @ 1162
		global @ 1182
		global @ 1202
		global @ 1222
		global @ 1234
		global @ 1242
		global @ 1262
		global @ 1282
		global @ 1302
		global @ 1322
		global @ 1334
		global @ 1342
		global @ 1362
		global @ 1382
		global @ 1402
		global @ 1422
		global @ 1442
		global @ 1462
		global @ 1482
		global @ 1494
		global @ 1502
		global @ 1522
		global @ 1542
		global @ 1562
		global @ 1582
		global @ 1602
		global @ 1622
		global @ 1642
		global @ 1654
		global @ 1662
		global @ 1682
		global @ 1702
		global @ 1722
		global @ 1734
		global @ 1742
		global @ 1762
		global @ 1782
		global @ 1802
		global @ 1822
		global @ 1842
		global @ 1854
		global @ 1862
		global @ 1882
		global @ 1902
		global @ 1922
		global @ 1942
		global @ 1962
		global @ 1974
		global @ 1982
		global @ 2002
		global @ 2014
		global @ 2022
		global @ 2042
		global @ 2062
		global @ 2082
		global @ 2102
		global @ 2122
		global @ 2142
		global @ 2162
		global @ 2182
		global @ 2202
		global @ 2214
		global @ 2222
		global @ 2271
		global @ 2518
		global @ 2840
		global @ 2917
		global @ 3075
		global @ 3178
		global @ 3197
		global @ 3260
		global @ 3342
		global @ 3361
		global @ 3424
		global @ 3506
		global @ 3525
		global @ 3588
		global @ 3935
		global @ 4047
	<Exports>
		void OnErr(*char) @ 2232
		void Init() @ 2356
	<Info Section>
		global(0)::Server @ 0
		global(0)::Importer @ 0
		global(0)::OnError @ 0
		malloc(0)::size @ 4
		free(0)::p @ 4
		_log(0)::server @ 8
		_log(0)::?CompilerGeneratedID14017734 @ 4
		Error(0)::server @ 8
		Error(0)::?CompilerGeneratedID14017776 @ 4
		Push(0)::server @ 12
		Push(0)::num_cmds @ 8
		Push(0)::?CompilerGeneratedID14017778 @ 4
		CreatePrintableFloat(0)::f @ 4
		RunTimeLink(0)::name @ 4
		AddLinkInfo(0)::Importer @ 12
		AddLinkInfo(0)::ID @ 8
		AddLinkInfo(0)::LinkInfo @ 4
		ImportDll(0)::Importer @ 12
		ImportDll(0)::dll_name @ 8
		ImportDll(0)::area @ 4
		UnloadDll(0)::Importer @ 8
		UnloadDll(0)::dll_name @ 4
		GetAdress(0)::Importer @ 8
		GetAdress(0)::name @ 4
		__DLLRUN(0)::dll_name @ 4
		MessageBox(0)::hwnd @ 16
		MessageBox(0)::text @ 12
		MessageBox(0)::caption @ 8
		MessageBox(0)::style @ 4
		FILE::dummy @ -4
		fpos_t::pos1 @ -4
		fpos_t::pos2 @ -20
		memcpy(0)::target @ 12
		memcpy(0)::source @ 8
		memcpy(0)::size @ 4
		sprintf(0)::out @ 12
		sprintf(0)::in @ 8
		sprintf(0)::?CompilerGeneratedID14017845 @ 4
		fopen(0)::file_name @ 8
		fopen(0)::mode @ 4
		fclose(0)::f @ 4
		fread(0)::target @ 16
		fread(0)::size @ 12
		fread(0)::count @ 8
		fread(0)::f @ 4
		fwrite(0)::source @ 16
		fwrite(0)::size @ 12
		fwrite(0)::count @ 8
		fwrite(0)::f @ 4
		fgetpos(0)::f @ 8
		fgetpos(0)::pos @ 4
		fsetpos(0)::f @ 8
		fsetpos(0)::pos @ 4
		global(0)::Rasterizer @ 0
		global(0)::Net @ 0
		MemStats(0)::Object @ 4
		OnErr(0)::error @ 4
		string0 @ 24
		Test::this @ -4
		Test::ClassName @ -20
		Init(1)::time @ -4
		string1 @ 68
		Init(1)::area @ -20
		string2 @ 88
		string3 @ 108
		string4 @ 144
		string5 @ 168
		string6 @ 204
		string7 @ 240
		string8 @ 260
		string9 @ 292
		string10 @ 324
		string11 @ 340
		string12 @ 364
		string13 @ 388
		Init(1)::mt @ -24
		string14 @ 396
		string15 @ 436
<End>