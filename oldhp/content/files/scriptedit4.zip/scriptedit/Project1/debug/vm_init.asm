<Header Section>
Compiler Version: 5.100000, Debug Info: 1
<Code Section>
0: jmp const 12013 
187: mov data , const 656 
204: sne 
214: mov reg1 , const 1159744854 
231: mov [ const 0 ] , reg1 
250: mov reg1 , const 1919906418 
267: mov [ const 4 ] , reg1 
286: mov reg1 , const 1634882592 
303: mov [ const 8 ] , reg1 
322: mov reg1 , const 1684369520 
339: mov [ const 12 ] , reg1 
358: mov reg1 , const 623321146 
375: mov [ const 16 ] , reg1 
394: mov reg1 , const 10099 
411: mov [ const 20 ] , reg1 
430: mov reg1 , const 0 
447: mov [ const 24 ] , reg1 
466: mov reg1 , const 1633906540 
483: mov [ const 28 ] , reg1 
502: mov reg1 , const 1969627244 
519: mov [ const 32 ] , reg1 
538: mov reg1 , const 1948279662 
555: mov [ const 36 ] , reg1 
574: mov reg1 , const 7631717 
591: mov [ const 40 ] , reg1 
610: mov reg1 , const 10099 
627: mov [ const 44 ] , reg1 
646: mov reg1 , const 28 
663: mov [ const 48 ] , reg1 
682: mov reg1 , const 1663394597 
699: mov [ const 52 ] , reg1 
718: mov reg1 , const 757935405 
735: mov [ const 56 ] , reg1 
754: mov reg1 , const 757935405 
771: mov [ const 60 ] , reg1 
790: mov reg1 , const 757935405 
807: mov [ const 64 ] , reg1 
826: mov reg1 , const 1380143917 
843: mov [ const 68 ] , reg1 
862: mov reg1 , const 760500297 
879: mov [ const 72 ] , reg1 
898: mov reg1 , const 757935405 
915: mov [ const 76 ] , reg1 
934: mov reg1 , const 757935405 
951: mov [ const 80 ] , reg1 
970: mov reg1 , const 757935405 
987: mov [ const 84 ] , reg1 
1006: mov reg1 , const 25381 
1023: mov [ const 88 ] , reg1 
1042: mov reg1 , const 52 
1059: mov [ const 92 ] , reg1 
1078: mov reg1 , const 1953719668 
1095: mov [ const 96 ] , reg1 
1114: mov reg1 , const 1768452896 
1131: mov [ const 100 ] , reg1 
1150: mov reg1 , const 116 
1167: mov [ const 104 ] , reg1 
1186: mov reg1 , const 96 
1203: mov [ const 108 ] , reg1 
1222: mov reg1 , const 1667594341 
1239: mov [ const 112 ] , reg1 
1258: mov reg1 , const 1852404853 
1275: mov [ const 116 ] , reg1 
1294: mov reg1 , const 1297490023 
1311: mov [ const 120 ] , reg1 
1330: mov reg1 , const 1768835360 
1347: mov [ const 124 ] , reg1 
1366: mov reg1 , const 1818323316 
1383: mov [ const 128 ] , reg1 
1402: mov reg1 , const 1952543593 
1419: mov [ const 132 ] , reg1 
1438: mov reg1 , const 544108393 
1455: mov [ const 136 ] , reg1 
1474: mov reg1 , const 1769104211 
1491: mov [ const 140 ] , reg1 
1510: mov reg1 , const 773878896 
1527: mov [ const 144 ] , reg1 
1546: mov reg1 , const 11822 
1563: mov [ const 148 ] , reg1 
1582: mov reg1 , const 112 
1599: mov [ const 152 ] , reg1 
1618: mov reg1 , const 1701082228 
1635: mov [ const 156 ] , reg1 
1654: mov reg1 , const 778532194 
1671: mov [ const 160 ] , reg1 
1690: mov reg1 , const 7105636 
1707: mov [ const 164 ] , reg1 
1726: mov reg1 , const 11822 
1743: mov [ const 168 ] , reg1 
1762: mov reg1 , const 156 
1779: mov [ const 172 ] , reg1 
1798: mov reg1 , const 1701082228 
1815: mov [ const 176 ] , reg1 
1834: mov reg1 , const 778532194 
1851: mov [ const 180 ] , reg1 
1870: mov reg1 , const 7105636 
1887: mov [ const 184 ] , reg1 
1906: mov reg1 , const 11822 
1923: mov [ const 188 ] , reg1 
1942: mov reg1 , const 176 
1959: mov [ const 192 ] , reg1 
1978: mov reg1 , const 1953719668 
1995: mov [ const 196 ] , reg1 
2014: mov reg1 , const 1768452896 
2031: mov [ const 200 ] , reg1 
2050: mov reg1 , const 12660 
2067: mov [ const 204 ] , reg1 
2086: mov reg1 , const 196 
2103: mov [ const 208 ] , reg1 
2122: mov reg1 , const 1953719668 
2139: mov [ const 212 ] , reg1 
2158: mov reg1 , const 1768452896 
2175: mov [ const 216 ] , reg1 
2194: mov reg1 , const 12916 
2211: mov [ const 220 ] , reg1 
2230: mov reg1 , const 212 
2247: mov [ const 224 ] , reg1 
2266: mov reg1 , const 1601403219 
2283: mov [ const 228 ] , reg1 
2302: mov reg1 , const 1869440333 
2319: mov [ const 232 ] , reg1 
2338: mov reg1 , const 976910706 
2355: mov [ const 236 ] , reg1 
2374: mov reg1 , const 1635021676 
2391: mov [ const 240 ] , reg1 
2410: mov reg1 , const 29556 
2427: mov [ const 244 ] , reg1 
2446: mov reg1 , const 228 
2463: mov [ const 248 ] , reg1 
2482: mov reg1 , const 1684234079 
2499: mov [ const 252 ] , reg1 
2518: mov reg1 , const 543974245 
2535: mov [ const 256 ] , reg1 
2554: mov reg1 , const 1684631414 
2571: mov [ const 260 ] , reg1 
2590: mov reg1 , const 1835355424 
2607: mov [ const 264 ] , reg1 
2626: mov reg1 , const 1952543827 
2643: mov [ const 268 ] , reg1 
2662: mov reg1 , const 1395271795 
2679: mov [ const 272 ] , reg1 
2698: mov reg1 , const 1298101113 
2715: mov [ const 276 ] , reg1 
2734: mov reg1 , const 1919905125 
2751: mov [ const 280 ] , reg1 
2770: mov reg1 , const 10617 
2787: mov [ const 284 ] , reg1 
2806: mov reg1 , const 252 
2823: mov [ const 288 ] , reg1 
2842: mov reg1 , const 1684234079 
2859: mov [ const 292 ] , reg1 
2878: mov reg1 , const 543974245 
2895: mov [ const 296 ] , reg1 
2914: mov reg1 , const 1684631414 
2931: mov [ const 300 ] , reg1 
2950: mov reg1 , const 1835355424 
2967: mov [ const 304 ] , reg1 
2986: mov reg1 , const 1952543827 
3003: mov [ const 308 ] , reg1 
3022: mov reg1 , const 1395271795 
3039: mov [ const 312 ] , reg1 
3058: mov reg1 , const 1298101113 
3075: mov [ const 316 ] , reg1 
3094: mov reg1 , const 1919905125 
3111: mov [ const 320 ] , reg1 
3130: mov reg1 , const 10617 
3147: mov [ const 324 ] , reg1 
3166: mov reg1 , const 292 
3183: mov [ const 328 ] , reg1 
3202: mov reg1 , const 1632783431 
3219: mov [ const 332 ] , reg1 
3238: mov reg1 , const 1919251571 
3255: mov [ const 336 ] , reg1 
3274: mov reg1 , const 1919253097 
3291: mov [ const 340 ] , reg1 
3310: mov reg1 , const 10496 
3327: mov [ const 344 ] , reg1 
3346: mov reg1 , const 332 
3363: mov [ const 348 ] , reg1 
3382: mov reg1 , const 1701666655 
3399: mov [ const 352 ] , reg1 
3418: mov reg1 , const 2035490925 
3435: mov [ const 356 ] , reg1 
3454: mov reg1 , const 1699569523 
3471: mov [ const 360 ] , reg1 
3490: mov reg1 , const 2037542765 
3507: mov [ const 364 ] , reg1 
3526: mov reg1 , const 1632772138 
3543: mov [ const 368 ] , reg1 
3562: mov reg1 , const 1919251571 
3579: mov [ const 372 ] , reg1 
3598: mov reg1 , const 1919253097 
3615: mov [ const 376 ] , reg1 
3634: mov reg1 , const 10496 
3651: mov [ const 380 ] , reg1 
3670: mov reg1 , const 352 
3687: mov [ const 384 ] , reg1 
3706: mov reg1 , const 1701666655 
3723: mov [ const 388 ] , reg1 
3742: mov reg1 , const 2035490925 
3759: mov [ const 392 ] , reg1 
3778: mov reg1 , const 1699569523 
3795: mov [ const 396 ] , reg1 
3814: mov reg1 , const 2037542765 
3831: mov [ const 400 ] , reg1 
3850: mov reg1 , const 1632772138 
3867: mov [ const 404 ] , reg1 
3886: mov reg1 , const 1919251571 
3903: mov [ const 408 ] , reg1 
3922: mov reg1 , const 1919253097 
3939: mov [ const 412 ] , reg1 
3958: mov reg1 , const 10496 
3975: mov [ const 416 ] , reg1 
3994: mov reg1 , const 388 
4011: mov [ const 420 ] , reg1 
4030: mov reg1 , const 1601403219 
4047: mov [ const 424 ] , reg1 
4066: mov reg1 , const 7628110 
4083: mov [ const 428 ] , reg1 
4102: mov reg1 , const 10496 
4119: mov [ const 432 ] , reg1 
4138: mov reg1 , const 424 
4155: mov [ const 436 ] , reg1 
4174: mov reg1 , const 1701666655 
4191: mov [ const 440 ] , reg1 
4210: mov reg1 , const 2035490925 
4227: mov [ const 444 ] , reg1 
4246: mov reg1 , const 1699569523 
4263: mov [ const 448 ] , reg1 
4282: mov reg1 , const 2037542765 
4299: mov [ const 452 ] , reg1 
4318: mov reg1 , const 1699618858 
4335: mov [ const 456 ] , reg1 
4354: mov reg1 , const 116 
4371: mov [ const 460 ] , reg1 
4390: mov reg1 , const 440 
4407: mov [ const 464 ] , reg1 
4426: mov reg1 , const 1701666655 
4443: mov [ const 468 ] , reg1 
4462: mov reg1 , const 2035490925 
4479: mov [ const 472 ] , reg1 
4498: mov reg1 , const 1699569523 
4515: mov [ const 476 ] , reg1 
4534: mov reg1 , const 2037542765 
4551: mov [ const 480 ] , reg1 
4570: mov reg1 , const 1699618858 
4587: mov [ const 484 ] , reg1 
4606: mov reg1 , const 116 
4623: mov [ const 488 ] , reg1 
4642: mov reg1 , const 468 
4659: mov [ const 492 ] , reg1 
4678: mov reg1 , const 1935764547 
4695: mov [ const 496 ] , reg1 
4714: mov reg1 , const 623327859 
4731: mov [ const 500 ] , reg1 
4750: mov reg1 , const 1143744371 
4767: mov [ const 504 ] , reg1 
4786: mov reg1 , const 778138721 
4803: mov [ const 508 ] , reg1 
4822: mov reg1 , const 1668183398 
4839: mov [ const 512 ] , reg1 
4858: mov reg1 , const 1563515763 
4875: mov [ const 516 ] , reg1 
4894: mov reg1 , const 1835101742 
4911: mov [ const 520 ] , reg1 
4930: mov reg1 , const 623321189 
4947: mov [ const 524 ] , reg1 
4966: mov reg1 , const 10099 
4983: mov [ const 528 ] , reg1 
5002: mov reg1 , const 496 
5019: mov [ const 532 ] , reg1 
5038: mov reg1 , const 1768843622 
5055: mov [ const 536 ] , reg1 
5074: mov reg1 , const 1684367475 
5091: mov [ const 540 ] , reg1 
5110: mov reg1 , const 541939232 
5127: mov [ const 544 ] , reg1 
5146: mov reg1 , const 1953066569 
5163: mov [ const 548 ] , reg1 
5182: mov reg1 , const 1768710505 
5199: mov [ const 552 ] , reg1 
5218: mov reg1 , const 1769234803 
5235: mov [ const 556 ] , reg1 
5254: mov reg1 , const 1394634351 
5271: mov [ const 560 ] , reg1 
5290: mov reg1 , const 1885958755 
5307: mov [ const 564 ] , reg1 
5326: mov reg1 , const 116 
5343: mov [ const 568 ] , reg1 
5362: mov reg1 , const 536 
5379: mov [ const 572 ] , reg1 
5398: mov reg1 , const 1769104211 
5415: mov [ const 576 ] , reg1 
5434: mov reg1 , const 1159754864 
5451: mov [ const 580 ] , reg1 
5470: mov reg1 , const 1969448312 
5487: mov [ const 584 ] , reg1 
5506: mov reg1 , const 1852795252 
5523: mov [ const 588 ] , reg1 
5542: mov reg1 , const 1835619360 
5559: mov [ const 592 ] , reg1 
5578: mov reg1 , const 622869093 
5595: mov [ const 596 ] , reg1 
5614: mov reg1 , const 1936531556 
5631: mov [ const 600 ] , reg1 
5650: mov reg1 , const 0 
5667: mov [ const 604 ] , reg1 
5686: mov reg1 , const 576 
5703: mov [ const 608 ] , reg1 
5722: mov reg1 , const 1663394597 
5739: mov [ const 612 ] , reg1 
5758: mov reg1 , const 757935405 
5775: mov [ const 616 ] , reg1 
5794: mov reg1 , const 757935405 
5811: mov [ const 620 ] , reg1 
5830: mov reg1 , const 1145980205 
5847: mov [ const 624 ] , reg1 
5866: mov reg1 , const 1380143904 
5883: mov [ const 628 ] , reg1 
5902: mov reg1 , const 760500297 
5919: mov [ const 632 ] , reg1 
5938: mov reg1 , const 757935405 
5955: mov [ const 636 ] , reg1 
5974: mov reg1 , const 757935405 
5991: mov [ const 640 ] , reg1 
6010: mov reg1 , const 757935405 
6027: mov [ const 644 ] , reg1 
6046: mov reg1 , const 25381 
6063: mov [ const 648 ] , reg1 
6082: mov reg1 , const 612 
6099: mov [ const 652 ] , reg1 
6118: ret 
6128: mov reg1 , data 
source\test.c(9)
6141: sne 
6151: pushn reg1 , const 2 
source\test.c(10)
6168: mov reg2 , const 167 
6185: mov reg2 , [ reg2 ] 
6200: push reg2 
6211: mov reg2 , const 24 
6228: mov reg2 , [ reg2 ] 
6243: push reg2 
6254: mov reg2 , reg1 
6267: add reg2 , const 4 
6284: mov reg2 , [ reg2 ] 
6299: push reg2 
6310: se 
6320: call const 223 
6335: mov reg3 , reg1 
6348: add data , const 12 
6365: pop reg1 , const 2 
6382: mov reg2 , reg3 
6395: sne 
source\test.c(11)
6405: mov data , reg1 
6418: ret 
6428: mov reg1 , data 
source\test.c(14)
6441: sne 
6451: mov reg2 , reg1 
source\test.c(15)
6464: add reg2 , const 4 
6481: mov reg3 , const 10 
6498: mov reg4 , reg1 
6511: add reg4 , const 4 
6528: mov reg4 , [ reg4 ] 
6543: add reg4 , reg3 
6556: mov reg3 , reg4 
6569: mov [ reg2 ] , reg3 
6584: mov reg2 , reg1 
source\test.c(16)
6597: add reg2 , const 4 
6614: mov reg3 , const 10 
6631: mov reg4 , reg1 
6644: add reg4 , const 4 
6661: mov reg4 , [ reg4 ] 
6676: div reg4 , reg3 
6689: mov reg3 , reg4 
6702: mov [ reg2 ] , reg3 
6717: pushn reg1 , const 2 
source\test.c(17)
6734: mov reg2 , const 167 
6751: mov reg2 , [ reg2 ] 
6766: push reg2 
6777: mov reg2 , const 48 
6794: mov reg2 , [ reg2 ] 
6809: push reg2 
6820: se 
6830: call const 223 
6845: mov reg3 , reg1 
6858: add data , const 8 
6875: pop reg1 , const 2 
6892: mov reg2 , reg3 
6905: sne 
source\test.c(18)
6915: mov data , reg1 
6928: ret 
6938: mov reg1 , data 
source\test.c(21)
6951: sne 
6961: sub data , const 20 
6978: pushn reg1 , const 2 
6995: se 
7005: call const 111 
7020: mov reg3 , reg1 
7033: pop reg1 , const 2 
7050: mov reg2 , reg3 
7063: mov reg3 , reg1 - const 4 
7082: mov [ reg3 ] , reg2 
7097: pushn reg1 , const 2 
source\test.c(25)
7114: mov reg2 , const 10 
7131: mov reg3 , const 10 
7148: mov reg4 , const 10 
7165: mov reg5 , const 167 
7182: mov reg5 , [ reg5 ] 
7197: push reg5 
7208: mov reg5 , const 92 
7225: mov reg5 , [ reg5 ] 
7240: push reg5 
7251: push reg2 
7262: push reg3 
7273: push reg4 
7284: call const 223 
7299: mov reg3 , reg1 
7312: add data , const 20 
7329: pop reg1 , const 2 
7346: mov reg2 , reg3 
7359: pushn reg1 , const 2 
source\test.c(27)
7376: mov reg2 , const 108 
7393: mov reg2 , [ reg2 ] 
7408: push reg2 
7419: call const 111 
7434: mov reg3 , reg1 
7447: add data , const 4 
7464: pop reg1 , const 2 
7481: mov reg2 , reg3 
7494: pushn reg1 , const 2 
source\test.c(29)
7511: mov reg2 , const 167 
7528: mov reg2 , [ reg2 ] 
7543: push reg2 
7554: mov reg2 , const 152 
7571: mov reg2 , [ reg2 ] 
7586: push reg2 
7597: call const 223 
7612: mov reg3 , reg1 
7625: add data , const 8 
7642: pop reg1 , const 2 
7659: mov reg2 , reg3 
7672: mov reg2 , const 0 
source\test.c(31)
7689: mov reg3 , reg2 
7702: mul reg3 , const 4 
7719: mov reg4 , reg1 - const 20 
7738: add reg3 , reg4 
7751: mov reg2 , reg3 
7764: mov reg3 , const 0 
7781: mov [ reg2 ] , reg3 
7796: mov reg2 , const 1 
source\test.c(32)
7813: mov reg3 , reg2 
7826: mul reg3 , const 4 
7843: mov reg4 , reg1 - const 20 
7862: add reg3 , reg4 
7875: mov reg2 , reg3 
7888: mov reg3 , const 0 
7905: mov [ reg2 ] , reg3 
7920: mov reg2 , const 2 
source\test.c(33)
7937: mov reg3 , reg2 
7950: mul reg3 , const 4 
7967: mov reg4 , reg1 - const 20 
7986: add reg3 , reg4 
7999: mov reg2 , reg3 
8012: mov reg3 , const 1065353216 
8029: mov [ reg2 ] , reg3 
8044: mov reg2 , const 3 
source\test.c(34)
8061: mov reg3 , reg2 
8074: mul reg3 , const 4 
8091: mov reg4 , reg1 - const 20 
8110: add reg3 , reg4 
8123: mov reg2 , reg3 
8136: mov reg3 , const 1065353216 
8153: mov [ reg2 ] , reg3 
8168: pushn reg1 , const 2 
source\test.c(36)
8185: mov reg2 , const 111 
8202: mov reg2 , [ reg2 ] 
8217: push reg2 
8228: mov reg2 , const 172 
8245: mov reg2 , [ reg2 ] 
8260: push reg2 
8271: mov reg2 , reg1 - const 20 
8290: push reg2 
8301: call const 167 
8316: mov reg3 , reg1 
8329: add data , const 12 
8346: pop reg1 , const 2 
8363: mov reg2 , reg3 
8376: pushn reg1 , const 2 
source\test.c(37)
8393: mov reg2 , const 192 
8410: mov reg2 , [ reg2 ] 
8425: push reg2 
8436: call const 167 
8451: mov reg3 , reg1 
8464: add data , const 4 
8481: pop reg1 , const 2 
8498: mov reg2 , reg3 
8511: pushn reg1 , const 2 
source\test.c(44)
8528: mov reg2 , const 208 
8545: mov reg2 , [ reg2 ] 
8560: push reg2 
8571: call const 111 
8586: mov reg3 , reg1 
8599: add data , const 4 
8616: pop reg1 , const 2 
8633: mov reg2 , reg3 
8646: pushn reg1 , const 2 
source\test.c(45)
8663: mov reg2 , const 99 
8680: push reg2 
8691: sne 
8701: call const 6428 
8716: mov reg3 , reg1 
8729: add data , const 4 
8746: pop reg1 , const 2 
8763: mov reg2 , reg3 
8776: pushn reg1 , const 2 
source\test.c(46)
8793: mov reg2 , const 224 
8810: mov reg2 , [ reg2 ] 
8825: push reg2 
8836: se 
8846: call const 111 
8861: mov reg3 , reg1 
8874: add data , const 4 
8891: pop reg1 , const 2 
8908: mov reg2 , reg3 
8921: pushn reg1 , const 2 
source\test.c(48)
8938: mov reg2 , const 111 
8955: mov reg2 , [ reg2 ] 
8970: push reg2 
8981: mov reg2 , const 248 
8998: mov reg2 , [ reg2 ] 
9013: push reg2 
9024: mov reg2 , const 288 
9041: mov reg2 , [ reg2 ] 
9056: push reg2 
9067: call const 167 
9082: mov reg3 , reg1 
9095: add data , const 12 
9112: pop reg1 , const 2 
9129: mov reg2 , reg3 
9142: pushn reg1 , const 2 
source\test.c(49)
9159: mov reg2 , const 328 
9176: mov reg2 , [ reg2 ] 
9191: push reg2 
9202: call const 111 
9217: mov reg3 , reg1 
9230: add data , const 4 
9247: pop reg1 , const 2 
9264: mov reg2 , reg3 
9277: pushn reg1 , const 2 
source\test.c(50)
9294: mov reg2 , const 111 
9311: mov reg2 , [ reg2 ] 
9326: push reg2 
9337: mov reg2 , const 348 
9354: mov reg2 , [ reg2 ] 
9369: push reg2 
9380: mov reg2 , const 384 
9397: mov reg2 , [ reg2 ] 
9412: push reg2 
9423: call const 167 
9438: mov reg3 , reg1 
9451: add data , const 12 
9468: pop reg1 , const 2 
9485: mov reg2 , reg3 
9498: pushn reg1 , const 2 
source\test.c(51)
9515: mov reg2 , const 420 
9532: mov reg2 , [ reg2 ] 
9547: push reg2 
9558: call const 111 
9573: mov reg3 , reg1 
9586: add data , const 4 
9603: pop reg1 , const 2 
9620: mov reg2 , reg3 
9633: pushn reg1 , const 2 
source\test.c(52)
9650: mov reg2 , const 111 
9667: mov reg2 , [ reg2 ] 
9682: push reg2 
9693: mov reg2 , const 436 
9710: mov reg2 , [ reg2 ] 
9725: push reg2 
9736: mov reg2 , const 464 
9753: mov reg2 , [ reg2 ] 
9768: push reg2 
9779: call const 167 
9794: mov reg3 , reg1 
9807: add data , const 12 
9824: pop reg1 , const 2 
9841: mov reg2 , reg3 
9854: pushn reg1 , const 2 
source\test.c(53)
9871: mov reg2 , const 492 
9888: mov reg2 , [ reg2 ] 
9903: push reg2 
9914: call const 111 
9929: mov reg3 , reg1 
9942: add data , const 4 
9959: pop reg1 , const 2 
9976: mov reg2 , reg3 
9989: pushn reg1 , const 2 
source\test.c(55)
10006: mov reg2 , const 111 
10023: mov reg2 , [ reg2 ] 
10038: push reg2 
10049: call const 377 
10064: mov reg3 , reg1 
10077: add data , const 4 
10094: pop reg1 , const 2 
10111: mov reg2 , reg3 
10124: pushn reg1 , const 2 
source\test.c(56)
10141: mov reg2 , const 167 
10158: mov reg2 , [ reg2 ] 
10173: push reg2 
10184: call const 377 
10199: mov reg3 , reg1 
10212: add data , const 4 
10229: pop reg1 , const 2 
10246: mov reg2 , reg3 
10259: pushn reg1 , const 2 
source\test.c(57)
10276: mov reg2 , const 237 
10293: mov reg2 , [ reg2 ] 
10308: push reg2 
10319: call const 377 
10334: mov reg3 , reg1 
10347: add data , const 4 
10364: pop reg1 , const 2 
10381: mov reg2 , reg3 
10394: pushn reg1 , const 2 
source\test.c(58)
10411: mov reg2 , const 307 
10428: mov reg2 , [ reg2 ] 
10443: push reg2 
10454: call const 377 
10469: mov reg3 , reg1 
10482: add data , const 4 
10499: pop reg1 , const 2 
10516: mov reg2 , reg3 
10529: pushn reg1 , const 2 
source\test.c(60)
10546: mov reg2 , const 167 
10563: mov reg2 , [ reg2 ] 
10578: push reg2 
10589: mov reg2 , const 532 
10606: mov reg2 , [ reg2 ] 
10621: push reg2 
10632: mov reg2 , const 111 
10649: mov reg2 , [ reg2 ] 
10664: add reg2 , const 0 
10681: add reg2 , const 0 
10698: add reg2 , const 4 
10715: push reg2 
10726: mov reg3 , const 111 
10743: mov reg3 , [ reg3 ] 
10758: add reg3 , const 60 
10775: add reg3 , const 8 
10792: mov reg3 , [ reg3 ] 
10807: add reg3 , const 12 
10824: mov reg3 , [ reg3 ] 
10839: add reg3 , const 4 
10856: mov reg2 , reg3 
10869: mov reg2 , [ reg2 ] 
10884: push reg2 
10895: call const 223 
10910: mov reg3 , reg1 
10923: add data , const 16 
10940: pop reg1 , const 2 
10957: mov reg2 , reg3 
10970: pushn reg1 , const 2 
source\test.c(62)
10987: mov reg2 , const 167 
11004: mov reg2 , [ reg2 ] 
11019: push reg2 
11030: mov reg2 , const 572 
11047: mov reg2 , [ reg2 ] 
11062: push reg2 
11073: call const 223 
11088: mov reg3 , reg1 
11101: add data , const 8 
11118: pop reg1 , const 2 
11135: mov reg2 , reg3 
11148: mov reg2 , reg1 - const 4 
source\test.c(63)
11167: pushn reg1 , const 3 
11184: call const 111 
11199: mov reg4 , reg1 
11212: pop reg1 , const 3 
11229: mov reg5 , reg1 - const 4 
11248: mov reg5 , [ reg5 ] 
11263: sub reg4 , reg5 
11276: mov reg3 , reg4 
11289: mov [ reg2 ] , reg3 
11304: pushn reg1 , const 2 
source\test.c(64)
11321: mov reg2 , const 167 
11338: mov reg2 , [ reg2 ] 
11353: push reg2 
11364: mov reg2 , const 608 
11381: mov reg2 , [ reg2 ] 
11396: push reg2 
11407: mov reg2 , reg1 - const 4 
11426: mov reg2 , [ reg2 ] 
11441: push reg2 
11452: call const 223 
11467: mov reg3 , reg1 
11480: add data , const 12 
11497: pop reg1 , const 2 
11514: mov reg2 , reg3 
11527: pushn reg1 , const 2 
source\test.c(66)
11544: mov reg2 , const 10 
11561: mov reg3 , const 10 
11578: mov reg4 , const 10 
11595: mov reg5 , const 167 
11612: mov reg5 , [ reg5 ] 
11627: push reg5 
11638: mov reg5 , const 652 
11655: mov reg5 , [ reg5 ] 
11670: push reg5 
11681: push reg2 
11692: push reg3 
11703: push reg4 
11714: call const 223 
11729: mov reg3 , reg1 
11742: add data , const 20 
11759: pop reg1 , const 2 
11776: mov reg2 , reg3 
11789: pushn reg1 , const 2 
source\test.c(68)
11806: mov reg2 , const 1 
11823: mov reg3 , const 2 
11840: mov reg4 , const 167 
11857: mov reg4 , [ reg4 ] 
11872: push reg4 
11883: push reg2 
11894: push reg3 
11905: call const 223 
11920: mov reg3 , reg1 
11933: add data , const 12 
11950: pop reg1 , const 2 
11967: mov reg2 , reg3 
11980: sne 
source\test.c(69)
11990: mov data , reg1 
12003: ret 
12013:  <Link Section>
	<Imports>
		__mem Sys_Server* Server @ 6172
		__cdecl void _log(*Sys_Server,?) @ 6322
		__mem Sys_Server* Server @ 6738
		__cdecl void _log(*Sys_Server,?) @ 6832
		__cdecl DWORD timeGetTime() @ 7007
		__mem Sys_Server* Server @ 7169
		__cdecl void _log(*Sys_Server,?) @ 7286
		__cdecl void OutputDebugString(*char) @ 7421
		__mem Sys_Server* Server @ 7515
		__cdecl void _log(*Sys_Server,?) @ 7599
		__mem DLLImport* Importer @ 8189
		__cdecl void ImportDll(*DLLImport,*char,*float) @ 8303
		__cdecl void __DLLRUN(*char) @ 8438
		__cdecl void OutputDebugString(*char) @ 8573
		__cdecl void OutputDebugString(*char) @ 8848
		__mem DLLImport* Importer @ 8942
		__cdecl void AddLinkInfo(*DLLImport,*char,*char) @ 9069
		__cdecl void RunTimeLink(*char) @ 9204
		__mem DLLImport* Importer @ 9298
		__cdecl void AddLinkInfo(*DLLImport,*char,*char) @ 9425
		__cdecl void RunTimeLink(*char) @ 9560
		__mem DLLImport* Importer @ 9654
		__cdecl void AddLinkInfo(*DLLImport,*char,*char) @ 9781
		__cdecl void RunTimeLink(*char) @ 9916
		__mem DLLImport* Importer @ 10010
		__cdecl void MemStats(*Sys_Memory) @ 10051
		__mem Sys_Server* Server @ 10145
		__cdecl void MemStats(*Sys_Memory) @ 10186
		__mem Sys_Memory* Rasterizer @ 10280
		__cdecl void MemStats(*Sys_Memory) @ 10321
		__mem Sys_Memory* Net @ 10415
		__cdecl void MemStats(*Sys_Memory) @ 10456
		__mem Sys_Server* Server @ 10550
		__mem DLLImport* Importer @ 10636
		__mem DLLImport* Importer @ 10730
		__cdecl void _log(*Sys_Server,?) @ 10897
		__mem Sys_Server* Server @ 10991
		__cdecl void _log(*Sys_Server,?) @ 11075
		__cdecl DWORD timeGetTime() @ 11186
		__mem Sys_Server* Server @ 11325
		__cdecl void _log(*Sys_Server,?) @ 11454
		__mem Sys_Server* Server @ 11599
		__cdecl void _log(*Sys_Server,?) @ 11716
		__mem Sys_Server* Server @ 11844
		__cdecl void Push(*Sys_Server,DWORD,?) @ 11907
	<Uses>
		global @ 270
		global @ 306
		global @ 342
		global @ 378
		global @ 414
		global @ 434
		global @ 450
		global @ 486
		global @ 522
		global @ 558
		global @ 594
		global @ 630
		global @ 650
		global @ 666
		global @ 702
		global @ 738
		global @ 774
		global @ 810
		global @ 846
		global @ 882
		global @ 918
		global @ 954
		global @ 990
		global @ 1026
		global @ 1046
		global @ 1062
		global @ 1098
		global @ 1134
		global @ 1170
		global @ 1190
		global @ 1206
		global @ 1242
		global @ 1278
		global @ 1314
		global @ 1350
		global @ 1386
		global @ 1422
		global @ 1458
		global @ 1494
		global @ 1530
		global @ 1566
		global @ 1586
		global @ 1602
		global @ 1638
		global @ 1674
		global @ 1710
		global @ 1746
		global @ 1766
		global @ 1782
		global @ 1818
		global @ 1854
		global @ 1890
		global @ 1926
		global @ 1946
		global @ 1962
		global @ 1998
		global @ 2034
		global @ 2070
		global @ 2090
		global @ 2106
		global @ 2142
		global @ 2178
		global @ 2214
		global @ 2234
		global @ 2250
		global @ 2286
		global @ 2322
		global @ 2358
		global @ 2394
		global @ 2430
		global @ 2450
		global @ 2466
		global @ 2502
		global @ 2538
		global @ 2574
		global @ 2610
		global @ 2646
		global @ 2682
		global @ 2718
		global @ 2754
		global @ 2790
		global @ 2810
		global @ 2826
		global @ 2862
		global @ 2898
		global @ 2934
		global @ 2970
		global @ 3006
		global @ 3042
		global @ 3078
		global @ 3114
		global @ 3150
		global @ 3170
		global @ 3186
		global @ 3222
		global @ 3258
		global @ 3294
		global @ 3330
		global @ 3350
		global @ 3366
		global @ 3402
		global @ 3438
		global @ 3474
		global @ 3510
		global @ 3546
		global @ 3582
		global @ 3618
		global @ 3654
		global @ 3674
		global @ 3690
		global @ 3726
		global @ 3762
		global @ 3798
		global @ 3834
		global @ 3870
		global @ 3906
		global @ 3942
		global @ 3978
		global @ 3998
		global @ 4014
		global @ 4050
		global @ 4086
		global @ 4122
		global @ 4142
		global @ 4158
		global @ 4194
		global @ 4230
		global @ 4266
		global @ 4302
		global @ 4338
		global @ 4374
		global @ 4394
		global @ 4410
		global @ 4446
		global @ 4482
		global @ 4518
		global @ 4554
		global @ 4590
		global @ 4626
		global @ 4646
		global @ 4662
		global @ 4698
		global @ 4734
		global @ 4770
		global @ 4806
		global @ 4842
		global @ 4878
		global @ 4914
		global @ 4950
		global @ 4986
		global @ 5006
		global @ 5022
		global @ 5058
		global @ 5094
		global @ 5130
		global @ 5166
		global @ 5202
		global @ 5238
		global @ 5274
		global @ 5310
		global @ 5346
		global @ 5366
		global @ 5382
		global @ 5418
		global @ 5454
		global @ 5490
		global @ 5526
		global @ 5562
		global @ 5598
		global @ 5634
		global @ 5670
		global @ 5690
		global @ 5706
		global @ 5742
		global @ 5778
		global @ 5814
		global @ 5850
		global @ 5886
		global @ 5922
		global @ 5958
		global @ 5994
		global @ 6030
		global @ 6066
		global @ 6086
		global @ 6102
		global @ 6215
		global @ 6781
		global @ 7212
		global @ 7380
		global @ 7558
		global @ 8232
		global @ 8397
		global @ 8532
		global @ 8797
		global @ 8985
		global @ 9028
		global @ 9163
		global @ 9341
		global @ 9384
		global @ 9519
		global @ 9697
		global @ 9740
		global @ 9875
		global @ 10593
		global @ 11034
		global @ 11368
		global @ 11642
	<Exports>
		void OnErr(*char) @ 6128
		void LocFunc(DWORD) @ 6428
		void Init() @ 6938
	<Info Section>
		global(0)::OnError @ 0
		CreatePrintableFloat(0)::f @ 4
		RunTimeLink(0)::name @ 4
		malloc(0)::size @ 4
		free(0)::p @ 4
		MessageBox(0)::hwnd @ 16
		MessageBox(0)::text @ 12
		MessageBox(0)::caption @ 8
		MessageBox(0)::style @ 4
		FILE::dummy @ -4
		fpos_t::pos1 @ -4
		fpos_t::pos2 @ -20
		memcpy(0)::target @ 12
		memcpy(0)::source @ 8
		memcpy(0)::size @ 4
		sprintf(0)::out @ 12
		sprintf(0)::in @ 8
		sprintf(0)::?CompilerGeneratedID6689891 @ 4
		fopen(0)::file_name @ 8
		fopen(0)::mode @ 4
		fclose(0)::f @ 4
		fread(0)::target @ 16
		fread(0)::size @ 12
		fread(0)::count @ 8
		fread(0)::f @ 4
		fwrite(0)::source @ 16
		fwrite(0)::size @ 12
		fwrite(0)::count @ 8
		fwrite(0)::f @ 4
		fgetpos(0)::f @ 8
		fgetpos(0)::pos @ 4
		fsetpos(0)::f @ 8
		fsetpos(0)::pos @ 4
		OutputDebugString(0)::string @ 4
		Sys_Error::this @ -4
		Sys_Error::ClassName @ -20
		Sys_Error::c2 @ -24
		Sys_Error::c3 @ -28
		Sys_Error::c4 @ -32
		Sys_Error::d1 @ -36
		Sys_Error::d2 @ -52
		Sys_Error::d3 @ -68
		Sys_Error::d4 @ -84
		Sys_Error::d5 @ -100
		Sys_Error::d6 @ -116
		Sys_Error::d7 @ -132
		Sys_Error::d8 @ -148
		Sys_Error::d9 @ -164
		Sys_Memory::Error @ -4
		Sys_Memory::AllocHistory @ -180
		Sys_Memory::Ptr @ -196
		Sys_Memory::CleanedUp @ -212
		Sys_Memory::IPMem @ -228
		_ImpFunc::func @ -4
		_ImpFunc::name @ -20
		_ImpFunc::link @ -36
		_ImpFunc::next @ -52
		_DLLData::hi @ -4
		_DLLData::name @ -20
		_DLLData::funcs @ -36
		_DLLData::next @ -52
		_DLLData::ClientArea1 @ -68
		_DLLData::ClientArea2 @ -84
		_DLLData::ClientArea3 @ -100
		_DLLData::ClientArea4 @ -116
		DLLImport::Memory @ -4
		DLLImport::Data @ -244
		global(0)::Importer @ 0
		AddLinkInfo(0)::Importer @ 12
		AddLinkInfo(0)::ID @ 8
		AddLinkInfo(0)::LinkInfo @ 4
		ImportDll(0)::Importer @ 12
		ImportDll(0)::dll_name @ 8
		ImportDll(0)::area @ 4
		UnloadDll(0)::Importer @ 8
		UnloadDll(0)::dll_name @ 4
		GetAdress(0)::Importer @ 8
		GetAdress(0)::name @ 4
		__DLLRUN(0)::dll_name @ 4
		Sys_Server::Memory @ -4
		global(0)::Server @ 0
		_log(0)::server @ 8
		_log(0)::?CompilerGeneratedID6690378 @ 4
		Error(0)::server @ 8
		Error(0)::?CompilerGeneratedID6690380 @ 4
		Push(0)::server @ 12
		Push(0)::num_cmds @ 8
		Push(0)::?CompilerGeneratedID6690382 @ 4
		global(0)::Rasterizer @ 0
		global(0)::Net @ 0
		MemStats(0)::Object @ 4
		OnErr(0)::error @ 4
		string0 @ 24
		LocFunc(0)::d @ 4
		string1 @ 48
		Init(1)::time @ -4
		string2 @ 92
		string3 @ 108
		string4 @ 152
		Init(1)::area @ -20
		string5 @ 172
		string6 @ 192
		string7 @ 208
		string8 @ 224
		string9 @ 248
		string10 @ 288
		string11 @ 328
		string12 @ 348
		string13 @ 384
		string14 @ 420
		string15 @ 436
		string16 @ 464
		string17 @ 492
		string18 @ 532
		string19 @ 572
		string20 @ 608
		string21 @ 652
<End>