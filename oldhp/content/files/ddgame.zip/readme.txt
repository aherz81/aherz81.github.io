NOTE:


convert odd.jpg to odd.bmp ...otherwise it won't work!!
the bitmap was just too big t upload..and i was too lazy to read in .jpgs



ddgame is just a stupid game I made for a little c course I gave in my school.
My 'pupils' should use it as basis to create a game from it.
Stupidely nobody told them that they should have basic c knowledge at least for my course.
So we coded text adventures :)

Anyways...
you are the gray plane..
FORWARD -> accelerate (don't get to fast while on the ground)
BACKWARD -> decelerate (get slower before landing)
LEFT -> turn left
RIGHT -> turn right
ALT+BACK -> climb 
ALT+FORE -> down (if you're low you migt crash into the trees)

STRG(CTRL) -> fire (go kill the scuds!!)

on the top you see the fps,your points,your fuel(landing increases fuel),and your damage


Alex Herz,
SoftCOre
www.accessviolation.net