#ifndef __NVHEADER
#define __NVHEADER

#define _DBGMSG "NV Vertex App extention included"

#define NV_CONST c
#define NV_OUT o
#define NV_IN v
#define NV_REGS R


struct nvvector
{
	float x,y,z,w;
	nvvector wwwy;
	nvvector xyz;
	nvvector xyzw;
};

struct nvmatrix
{
	nvvector rows[4];
};

nvvector v[16];
nvvector o[16];
nvvector c[96];

nvvector R[12];

nvvector *A0;					//Adress register


#define NV_REGISTER_NAMES

#define  OPOS 0
#define  WGHT 1
#define  NRML 2
#define  COL0 3
#define  COL1 4
#define  FOGC 5
#define  TEX0 8
#define  TEX1 9
#define  TEX2 10
#define  TEX3 11
#define  TEX4 12
#define  TEX5 13
#define  TEX6 14
#define  TEX7 15


#define  HPOS 16
#define  BFC0 17
#define  BFC1 18
#define  PSIZ 19

#endif 