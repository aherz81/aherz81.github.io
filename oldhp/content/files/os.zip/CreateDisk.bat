@ECHO Creating bootable disk (be sure to have a disk in drive a: which is writeable)
@ECHO Copying boot sector:
@copyboot bootsec.bin 0
@ECHO Copying boot code:
@copyboot bootcode.bin 25
@updateb 15
