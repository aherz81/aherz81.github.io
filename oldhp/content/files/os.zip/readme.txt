1.	Put a disk in your drive a:\ which is write enabled and run CreateDisk.bat.
2.	leave the disk in the drive and reboot the system to start the OS.

-typing 'help' + RETURN will list a list of avaiable commands (pretty few so far)
-yet you cannot navigate through the filesystem or execute anything but the commands listed with help

the tools needed to copy the stuff into the bootsector were not created by me..sadly the
author didn't leave a comment stating who he is in the sources..so I cannot give credits..
if you made em drop me a mail at softcore@web.de

enjoy the shit..oh..it's no virus by the way..you have to trust me..
if anyone happens to have some asm coded procedurally generated marijuana
(or how ever you write that) I'd highly apriciate to get a copy so I can out it in as a
logo...

ALex
