// dll_test.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

#define STAND_ALONE_VM	//MUST BE DEFINED!!

#include "..\ivm.h"


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.

	InitVM();//init VM

	//load sap.vxe (stand alone project.virtual executable)
	if(UploadScript("scripts\\sap.vxe"))//try to load init script
	{
		DWORD ret_val;
		//call a function which should be inside the script
		//pass number of arguments for function(2) and arguments("Argument passed from real binary.",10)
		Exec("__script int main(*char,int)",&ret_val,2,"Argument passed from real binary.",10);

	}

	ShutDownVM();//called once when finished with any kinda script stuff

	return 0;
}



