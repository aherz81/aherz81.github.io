// interface for the VM.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEDLL_H__1AAB2E75_866D_4AB0_9D56_E72A621B2A12__INCLUDED_)
#define AFX_GAMEDLL_H__1AAB2E75_866D_4AB0_9D56_E72A621B2A12__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>

//#define STAND_ALONE_VM

#ifndef STAND_ALONE_VM

	#include "..\pnpdll0005.h" 

	#define VM_API 

#else

	#ifdef VM_EXPORTS
	#define VM_API __declspec(dllexport)
	#else
	#define VM_API __declspec(dllimport)
	#endif

	//define needed structures
	typedef void* (*lpFunc)(...);

	struct _ImpFunc
	{
		lpFunc func;
		char *name;
		char *link;
		_ImpFunc *next;
	};

	struct _DLLData
	{
		HINSTANCE hi;
		char *name;
		_ImpFunc *funcs;
		_DLLData *next;
		float ClientArea[4];
	};

#endif

//function pointer definition of the interesting functions(my plugin system heavily uses function pointers)
typedef void(__cdecl*void_ret_dword)(DWORD dw);

typedef bool(__cdecl*upload_script)(char*name);
typedef bool(__cdecl*exec_script)(char*fname,DWORD* ret_val,DWORD size,...);
typedef void(__cdecl*unload_script)();


VM_API bool UploadScript(char*fn);
VM_API void InitVM(DWORD stack_size=1024*1024);
VM_API void ShutDownVM();
VM_API bool Exec(char* func,DWORD* ret_val,DWORD size,...);
VM_API void UnloadScript();

VM_API void Reg(char* funcname,...);
VM_API void Addlinkinfo(char* name,char* info);

typedef void(__cdecl*reg_func)(char* funcname,...);
typedef void(__cdecl*link_func)(char* name,char* info);

typedef void(__cdecl*vm_interface)(reg_func rf,link_func lf);
/*
a dll loaded by the script(using #bind "dllname.dll" directive) may add funcs to the registry so thay can be executed by script..
to do so it needs to have this function defined:

__cdecl void Vm_Interface(reg_func rf,link_func lf)
{
	//here inside the function it can register funcs/vars
	//where rf is a function pointer pointing to Reg();
	//and lf points to Addlinkinfo()

	rf("my_func",my_func);	//add an item to the registry(along with its adress)

	lf("my_func","__cdecl void my_func(*DWORD,**float,int)");//specify the type of an itam already in the registry

	rf(...);

	lf(...);

	...
}

*/

/*-------------------------------------------------------

to make the function :

float my_func(DWORD*d,float**f,int i);

callable by the script the exe has to notify the VM this way:

Reg("my_func",my_func);	//add an item to the registry(along with its adress)

Addlinkinfo("my_func","__cdecl void my_func(*DWORD,**float,int)");//specify the type of an itam already in the registry


...........................................................


code to call a script function:

InitVM();//called once at startup

if(UploadScript("scripts\\vm_init.vxe"))//try to load init script
{
	DWORD ret_val;
	//call "__script void Init(float f,char* c)"
	Exec("__script void Init(float,*char)",&ret_val,2,0.25f,"test");
	printf("Init() returned 0x%x",ret_val);//you have to interpret the return value
}

ShutDownVM();//called once when finished with any kinda script stuff

---------------------------------------------------------*/
#endif // !defined(AFX_GAMEDLL_H__1AAB2E75_866D_4AB0_9D56_E72A621B2A12__INCLUDED_)
