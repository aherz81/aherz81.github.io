/***********************************************************************
	Name: 			compiler.cpp
	Project:		ScriptC
	Description:	compiles a file 
	
� 1999 SoftCore/Alex Herz - All rights reserved

	Programmer:	Alex
	Current Version:	1.0

	Update History:
	Programmers Initials	Date	Change Made	Version
	
	Alex					12.4.99 Initial Revision
***********************************************************************/
#pragma optimize( "", on )
#pragma warning( disable : 4244 )


#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <commdlg.h>
#include <stdarg.h>

#include <winbase.h>
#include <winuser.h>

#include <mmsystem.h>
#include <math.h>

#include "symbols.h"
#include "compiler.h"

//C_globals

extern BYTE r,g,b;

Cmd* C_Commands[__MAX_COMMANDS];
int C_Num_Commands=-1;


int C_Output_Binary=-1;
int C_Output_DebugInfo=0;
int C_Output_Map=0;
int C_Output_Symbols=0;

FILE*CF_Source;
FILE*CF_Target;

int C_Result=0;
char *C_SrcText;
WORD C_Error=0;
int C_Num_Errors=0;
char C_ErrorMsg[MAX_CHAR_LEN]="";
char C_SrcName[MAX_CHAR_LEN]="";
bool C_Done=0;
DWORD strings=0;
fpos_t C_Init_FPOS;

DWORD ActLine=0;
long C_Level=0;
DWORD cmd_id=0xffff;
bool ForbidSymbols=0;
bool ext=0;
bool xInclude=0;

bool was_struct=0;
bool willbe_member=0;
DWORD mparent=0;
int next_type=0;
int next_ind=0;
bool C_inited;
//END C_globals

inline bool IsDef(DWORD id)
{
	return C_Commands[id]->define;
}

void C_CreateError(char*em)
{
	char str[255]="";
	sprintf(str,"DISABLE_ERROR_C%d",abs(((SHORT)em)**(em+strlen(em)/2)));
	if(IsDef(GetId(str)))
		return;

	C_Num_Errors++;
//	sprintf(str,"%s(%d)%s%s.",C_SrcName,ActLine,em,en);


	sprintf(C_ErrorMsg,"%s(%d) : error C%d :%s%c",C_SrcName,ActLine,abs(((SHORT)em)**(em+strlen(em)/2)),em,(char)0);
	r=255;
	SYS_TextOut(C_ErrorMsg);
	r=10;
	C_Error++;

	if(IsDef(GetId("HOLD_ON_ERROR")))
		SYS_Error("","");
}

bool C_GetNextString(char*get)
{
	int i=fscanf( CF_Source, "%s", get );
	if(i==-1||i==0)return 0;
	return 1;
}


void C_AddCommand(char * cn,char * fn,SHORT type)
{
	if(C_Num_Commands>__MAX_COMMANDS)
	{
		C_CreateError("Commands exceeded maximum");
		return;
	}
	//check if double def

	for(int i=0;i<=C_Num_Commands;i++)
	{
		if(strcmp(cn,C_Commands[i]->CName)==0)
		{
			char str[MAX_CHAR_LEN];
			sprintf(str,"Command '%s' already defined!",cn);
			C_CreateError(str);
			return;
		}
	}

	C_Num_Commands++;
	C_Commands[C_Num_Commands]=(Cmd*)malloc(sizeof(Cmd));
	C_Commands[C_Num_Commands]->CName=(char*)malloc(sizeof(char)*strlen(cn));
	for(i=0;i<=strlen(cn);i++)
	C_Commands[C_Num_Commands]->CName[i]=cn[i];
	C_Commands[C_Num_Commands]->ID=C_Num_Commands;
	C_Commands[C_Num_Commands]->Type=type;
	C_Commands[C_Num_Commands]->FPOS=0;
	C_Commands[C_Num_Commands]->define=0;
	if(type!=TYPE_DEF)
	{
		C_Commands[C_Num_Commands]->frame=0;
	}
	else
	{
		C_Commands[C_Num_Commands]->frame=C_Level;
		fpos_t mnp;
		fgetpos( CF_Target,  &mnp );
		C_Commands[C_Num_Commands]->FPOS=mnp;
	}
	C_Commands[C_Num_Commands]->def=0;
	C_Commands[C_Num_Commands]->args=0;
	C_Commands[C_Num_Commands]->nargs=0;
	C_Commands[C_Num_Commands]->parentf=cmd_id;
	C_Commands[C_Num_Commands]->incl=0;
	C_Commands[C_Num_Commands]->ext=ext;
	C_Commands[C_Num_Commands]->init=0;
	C_Commands[C_Num_Commands]->ind=0;
	C_Commands[C_Num_Commands]->argid=0;
	C_Commands[C_Num_Commands]->rtype=0;
	C_Commands[C_Num_Commands]->save_ind=0;
	C_Commands[C_Num_Commands]->created=0;
	C_Commands[C_Num_Commands]->true_args=0;
	C_Commands[C_Num_Commands]->array_depth=0;
	if(ext)
		ext=0;
	char str[255]="";
	if(C_Commands[C_Num_Commands]->ext)sprintf(str,"extern ");
	if(C_Output_Symbols)SYS_TextOut("Symbol(0x%x) '%s%s' ,level(%d) ,adress(0x%x) added .",C_Num_Commands,str,cn,C_Commands[C_Num_Commands]->frame,C_Commands[C_Num_Commands]->FPOS);

}

DWORD GetId(char* cn)
{
	for(int i=0;i<=C_Num_Commands;i++)
	{
		if(C_Commands[i]->CName&&strcmp(cn,C_Commands[i]->CName)==0)
		{
			return i;
		}
	}
	return 0xffff;
}

void C_ChangeCommand(char * cn,fpos_t fp)
{
	//check if double def
	for(int i=0;i<=C_Num_Commands;i++)
	{
		if(strcmp(cn,C_Commands[i]->CName)==0)
		{
			if(C_Commands[i]->FPOS==0||C_Commands[i]->incl)C_Commands[i]->FPOS=fp;
			else 
			{
				char str[255]="";
				sprintf(str,"Function '%s' has already got a body .",C_Commands[i]->CName);
				C_CreateError(str);
			}
			return;
		}
	}
}

void C_FreeCommands()
{
	return;
	for(int i=C_Num_Commands;i>=0;i++)
	{
		if(C_Commands[i]->def)
			free(C_Commands[i]->def);
		if(C_Commands[i]->args)
			free(C_Commands[i]->args);
		free((void*)C_Commands[i]->CName);
		free((void*)C_Commands[i]);
	}
}

bool C_TranslateCmd(char * cmd,DWORD*id,SHORT*tp)
{

	for(int i=0;i<=C_Num_Commands;i++)
	{
		if(strcmp(cmd,C_Commands[i]->CName)==0)
		{
			*id=C_Commands[i]->ID;
			*tp=C_Commands[i]->Type;
			return 1;
		}
	}
	return 0;

}

bool C_TranslateCmdCL(char * cmd,DWORD*id,SHORT*tp,WORD c,char* parent,bool global)
{
	for(int i=c;i>=0;i--)
	{
		if(!willbe_member)
		{
			char str[255]="";
			sprintf(str,"%s(%d)::%s",parent,i,cmd);
			for(int j=0;j<=C_Num_Commands;j++)
			{
				if(strcmp(str,C_Commands[j]->CName)==0)
				{
					*id=C_Commands[j]->ID;
					*tp=C_Commands[j]->Type;
					return 1;
				}
			}
			if(global&&!i)
			{
				sprintf(str,"%s(%d)::%s","global",i,cmd);
				for(j=0;j<=C_Num_Commands;j++)
				{
					if(strcmp(str,C_Commands[j]->CName)==0)
					{
						*id=C_Commands[j]->ID;
						*tp=C_Commands[j]->Type;
						return 1;
					}
				}
			}
		}
		else
		{
			if(!was_struct)
			{
				C_CreateError("Internal error no struct for member search.");
			}
				char str[255]="";
				DWORD rt=mparent;
				DWORD ll=0;
				while(C_Commands[rt]->rtype!=rt)
				{
					rt=C_Commands[rt]->rtype;
					ll++;
				}
				sprintf(str,"%s::%s",C_Commands[rt]->CName,cmd);
				for(int l=0;l<=C_Num_Commands;l++)
				{
					if(strcmp(str,C_Commands[l]->CName)==0)
					{
						DWORD mp=mparent;
						if(!ll)
							sprintf(str,"%s->%s%c",C_Commands[mp]->CName,C_Commands[l]->CName,0);
						else
							sprintf(str,"%s%c",C_Commands[l]->CName,0);
						for(int j=0;j<=C_Num_Commands;j++)
						{
							if(strcmp(str,C_Commands[j]->CName)==0)
							{
								*id=C_Commands[j]->ID;
								*tp=C_Commands[j]->Type;
								willbe_member=0;
								was_struct=0;
								return 1;
							}
						}
					}
				}
		}
	}
	return 0;
}


bool C_GetSub(char** s,char* get)
{
	DWORD c=0;
	DWORD id;
	SHORT tp;
	char buffer[MAX_CHAR_LEN];
	char b[2];
	b[1]=0;
	int i=0;
	DWORD strln=strlen(*s);
	memcpy(b,*s,1);
	*s+=1;
	while(c<strln)
	{
		buffer[c]=b[0];
		buffer[c+1]=0;
		c++;

		char mb[2];
		mb[1]=0;
		if(!strcmp(buffer,"//"))
		{
			do
			{
				memcpy(buffer,*s,1);
				*s+=1;
				c++;
				if(c>=strln)
					C_CreateError("Unexpected eof");
			}
			while(mb[0]!=10&&mb[0]!=13&&mb[0]!=9);
			ActLine++;
			buffer[0]=0;
			b[0]=0;
		}
		else
		{
			if(!strcmp(buffer,"/")||!strcmp(buffer,"*"))
			{
				memcpy(buffer,*s,1);
				*s+=1;
				sprintf(buffer,"%c%c%c",b[0],mb[0],0);
				if(!strcmp(buffer,"/*")||!strcmp(buffer,"*/"))
					sprintf(get,"%s%c",buffer,0);
				else
				{
					*s-=1;
					sprintf(get,"%s%c",b,0);
				}
				return 1;		
			}
		}
		if(C_TranslateCmd(buffer,&id,&tp))//found cmd
		{
			if(C_Commands[id]->Type!=TYPE_SGN||C_Commands[id]->def)
			{
				while(1)
				{
					memcpy(b,*s,1);
					*s+=1;
					if(C_TranslateCmd(b,&id,&tp)&&(!(b[0]>47&&b[0]<58)&&tp!=TYPE_DEF)
						||b[0]<=32)
					{
						if(b[0]==10||b[0]==13)
							ActLine++;
						*s-=1;
						break;
					}
					buffer[c]=b[0];
					buffer[c+1]=0;
					c++;
				}
			}
			sprintf(get,"%s%c",buffer,0);
			return 1;
		}
		if(C_TranslateCmd(b,&id,&tp))//found cmd
		{
			if(!(b[0]>47&&b[0]<58)&&tp!=TYPE_DEF)//allow numbers in names...
			{
				*s-=1;
				buffer[c-1]=0;
				sprintf(get,"%s%c",buffer,0);
				return 1;
			}
		}
		if(!strcmp(b," "))
		{
			buffer[c-1]=0;
			sprintf(get,"%s%c",buffer,0);
			return 1;		
		}
		if(!strcmp(b,"\""))
		{
			sprintf(get,"%s%c",b,0);
			return 1;		
		}
		memcpy(b,*s,1);
		*s+=1;
		if(i==-1)return 0;
	}
//	buffer[c-1]=0;
	sprintf(get,"%s%c",buffer,0);
	return 0;
}

bool C_GetNext(char*get)
{
	DWORD c=0;
	DWORD id;
	SHORT tp;
	char buffer[MAX_CHAR_LEN];
	char b[2];
	b[1]=0;
	int i=0;
	while(1)
	{
		i=fread((void*)b,1,1,CF_Source);
		if(i==-1||i==0)return 0;
		if(b[0]>32&&b[0]<128)
			break;
		if(b[0]==10)ActLine++;
	}

	while(c<MAX_CHAR_LEN)
	{
		buffer[c]=b[0];
		buffer[c+1]=0;
		c++;

		if(!strcmp(buffer,"/")||!strcmp(buffer,"*"))
		{
again:
			char mb[2];
			mb[1]=0;
			fpos_t mp;
			fgetpos( CF_Source,  &mp );
			i=fread((void*)mb,1,1,CF_Source);
			sprintf(buffer,"%c%c%c",b[0],mb[0],0);
			if(!strcmp(buffer,"//"))
			{
				do
				{
					i=fread((void*)mb,1,1,CF_Source);				
					if(!i)
						return 0;
				}
				while(mb[0]!=10&&mb[0]!=13);
				ActLine++;
				c=0;
				sprintf(buffer,"");
				sprintf(b,"");
//				b[0]=0;
				while(1)
				{
					if(b[0]>32&&b[0]<128)
						break;
					i=fread((void*)b,1,1,CF_Source);
					if(i==-1||i==0)return 0;
					if(b[0]==10)ActLine++;
				}
				buffer[c]=b[0];
				buffer[c+1]=0;
				c++;
				if(!strcmp(buffer,"/")||!strcmp(buffer,"*"))
					goto again;
			}
			else
			{
				if(!strcmp(buffer,"/*")||!strcmp(buffer,"*/"))
					sprintf(get,"%s%c",buffer,0);
				else
				{
					fsetpos( CF_Source,  &mp );
					sprintf(get,"%s%c",b,0);
				}
				return 1;		
			}
		}
		if(!strcmp(buffer,"&"))//search for &&
		{
			fpos_t fp;
			fgetpos( CF_Source,  &fp );
			char mb[2];
			mb[1]=0;
			i=fread((void*)mb,1,1,CF_Source);
			sprintf(buffer,"%c%c%c",b[0],mb[0],0);
			if(strcmp(buffer,"&&"))
			{
				fsetpos(CF_Source,&fp);
				buffer[1]=0;
			}
		}
		if(!strcmp(buffer,"|"))//search for &&
		{
			fpos_t fp;
			fgetpos( CF_Source,  &fp );
			char mb[2];
			mb[1]=0;
			i=fread((void*)mb,1,1,CF_Source);
			sprintf(buffer,"%c%c%c",b[0],mb[0],0);
			if(strcmp(buffer,"||"))
			{
				fsetpos(CF_Source,&fp);
				buffer[1]=0;
			}
		}
		if(!strcmp(buffer,"-"))//search for ->
		{
			fpos_t fp;
			fgetpos( CF_Source,  &fp );
			char mb[2];
			mb[1]=0;
			i=fread((void*)mb,1,1,CF_Source);
			sprintf(buffer,"%c%c%c",b[0],mb[0],0);
			if(strcmp(buffer,"->"))
			{
				fsetpos(CF_Source,&fp);
				buffer[1]=0;
			}
		}
		if(!strcmp(buffer,"="))//search for ==
		{
			fpos_t fp;
			fgetpos( CF_Source,  &fp );
			char mb[2];
			mb[1]=0;
			i=fread((void*)mb,1,1,CF_Source);
			sprintf(buffer,"%c%c%c",b[0],mb[0],0);
			if(strcmp(buffer,"=="))
			{
				fsetpos(CF_Source,&fp);
				buffer[1]=0;
			}
		}
		if(!strcmp(buffer,"+"))//search for ++
		{
			fpos_t fp;
			fgetpos( CF_Source,  &fp );
			char mb[2];
			mb[1]=0;
			i=fread((void*)mb,1,1,CF_Source);
			sprintf(buffer,"%c%c%c",b[0],mb[0],0);
			if(strcmp(buffer,"++"))
			{
				fsetpos(CF_Source,&fp);
				buffer[1]=0;
			}
		}
		if(!strcmp(buffer,"-"))//search for --
		{
			fpos_t fp;
			fgetpos( CF_Source,  &fp );
			char mb[2];
			mb[1]=0;
			i=fread((void*)mb,1,1,CF_Source);
			sprintf(buffer,"%c%c%c",b[0],mb[0],0);
			if(strcmp(buffer,"--"))
			{
				fsetpos(CF_Source,&fp);
				buffer[1]=0;
			}
		}
		if(C_TranslateCmd(buffer,&id,&tp))//found cmd
		{
			if(C_Commands[id]->Type!=TYPE_SGN||C_Commands[id]->def)
			{
				while(1)
				{
					i=fread((void*)b,1,1,CF_Source);
					if(C_TranslateCmd(b,&id,&tp)&&(!(b[0]>47&&b[0]<58)&&tp!=TYPE_DEF)
						||b[0]<=32)
					{
						if(b[0]==10||b[0]==13)
							ActLine++;
						fseek(CF_Source,-1,SEEK_CUR);
						break;
					}
					buffer[c]=b[0];
					buffer[c+1]=0;
					c++;
				}
			}
			sprintf(get,"%s%c",buffer,0);
			return 1;
		}
		if(C_TranslateCmd(b,&id,&tp))//found cmd
		{
			if(!(b[0]>47&&b[0]<58)&&tp!=TYPE_DEF)//allow numbers in names...
			{
				
				fseek(CF_Source,-1,SEEK_CUR);
				buffer[c-1]=0;
				sprintf(get,"%s%c",buffer,0);
				return 1;
			}
		}
		if(!strcmp(b," ")||b[0]==10||b[0]==13||b[0]==9)
		{
			if(b[0]==10)
				ActLine++;
			buffer[c-1]=0;
			sprintf(get,"%s%c",buffer,0);
			return 1;		
		}
		if(!strcmp(b,"\""))
		{
			sprintf(get,"%s%c",b,0);
			return 1;		
		}
		i=fread((void*)b,1,1,CF_Source);
		if(i<1)
		{
			sprintf(get,"%s%c",buffer,0);
			return 0;
		}
	}
	char str[255]="";
	sprintf(str,"Symbol '%s' exceedes 255 characters",buffer);
	C_CreateError(str);
}

void C_Write(void * data,WORD size)
{
	if(C_Output_Binary)fwrite(data,size,1,CF_Target);
	else fprintf(CF_Target,"%d",*((long*)data));
}

void C_WriteMapFile()
{
	for(int i=0;i<=C_Num_Commands;i++)
	{
			for(int j=0;j<=C_Num_Commands;j++)
			{
				if(i!=j&&!strcmp(C_Commands[i]->CName,C_Commands[j]->CName))
				{
					SYS_Error("Following command is doubled :",C_Commands[i]->CName);
				}
			}
			C_Write((void *) C_Commands[i]->CName,sizeof(char)*(strlen(C_Commands[i]->CName)+1));
			C_Write((void *) &C_Commands[i]->ID,sizeof(DWORD));
			C_Write((void *) &C_Commands[i]->CName,sizeof(Cmd));
	}	
}

float C_GetCompilerVer(){return __SOV_SCRIPT_COMPILER_VER;}

void C_SetScr_Trg(FILE*src,char*name,FILE*trg)
{
	CF_Source=src;
	CF_Target=trg;
	sprintf(C_SrcName,"%s",name);
}

void SYS_Error(char *em,char *en)
{
	C_Num_Errors++;
	char str[MAX_CHAR_LEN];
	sprintf(str,"%s%s",em,en);
	r=255;
	g=0;
	SYS_TextOut("%s",str);
	SYS_TextOut("\n%d error(s) occured",C_Error);
	SYS_TextOut("\ncompilation stoped...");
	extern HWND hwnd;
	C_FreeCommands();
	free((void*)C_SrcText);
	r=0;
	g=255;
	fclose(CF_Source);
	fclose(CF_Target);
	extern FILE* Log;

	exit(C_Error);
}

void C_Include(char*fn)
{
	FILE * Src=CF_Source;
	char C_SText[255]="";
	sprintf(C_SText,"%s",C_SrcName);
	DWORD ActLn=ActLine;
	char * C_ST=C_SrcText;

	char str[MAX_CHAR_LEN]="";
	FILE * Include_File;
	Include_File=fopen(fn,"r+b");
	if(!Include_File)
	{
		sprintf(str,"Couldn't open include file '%s'",fn);
		C_CreateError(str);
		exit(0);
		return;
	}
	else
	{
		CF_Source=Include_File;
		char I_SrcText[MAX_CHAR_LEN];
		C_SrcText=I_SrcText;
		sprintf(C_SrcName,"%s",fn);
		ActLine=1;
		char Type[MAX_CHAR_LEN];
		int I_Done=0;
		SHORT tp=0;
		do
		{
			do
			{
				C_SrcText[0]=0;
				C_Done=C_GetNext(C_SrcText);
			}
			while(C_CheckC_Option(C_SrcText));
			I_Done=C_Done;
			if(C_Done)
			{
				sprintf(Type,C_SrcText);
				I_Done=fscanf(Include_File,"%s",I_SrcText);

					if(strcmp(Type,C_TYPE_CMD)==0)tp=TYPE_CMD;
					else if(strcmp(Type,C_TYPE_VAR)==0)tp=TYPE_VAR;
					else if(strcmp(Type,C_TYPE_SGN)==0)tp=TYPE_SGN;
					else if(strcmp(Type,C_TYPE_EXT)==0)tp=TYPE_EXT;
					else if(strcmp(Type,C_TYPE_DEF)==0)tp=TYPE_DEF;
					else if(strcmp(Type,C_TYPE_STR)==0)tp=TYPE_STR;
					else if(strcmp(Type,C_TYPE_FNC)==0)tp=TYPE_FNC;
					else if(strcmp(Type,C_TYPE_ASM)==0)tp=TYPE_ASM;
					else if(strcmp(Type,C_INCLUDE)==0)tp=TYPE_INC;
					else 
					{
						sprintf(Type,"Unknown type '%s'",Type);
						C_CreateError(Type);
						return;
					}
					if(ForbidSymbols&&(tp!=TYPE_CMD&&tp!=TYPE_EXT))
					{
						char str[255]="";
						sprintf(str,"'%s' uses reserved type",I_SrcText);
						C_CreateError(str);			
					}

					if(I_Done>0)
					{
						if(tp!=TYPE_INC)
						{
							if(tp==TYPE_DEF||tp==TYPE_EXT)
							{
								char str[255]="";
								sprintf(str,"%s(%d)::%s",C_Commands[cmd_id]->CName,C_Level,I_SrcText);
								C_AddCommand(str,fn,tp);
							}
							else
							{
								C_AddCommand(I_SrcText,fn,tp);
								if(tp==TYPE_VAR)
								{
									C_Commands[GetId(I_SrcText)]->rtype=GetId(I_SrcText);
									C_Commands[GetId(I_SrcText)]->frame=sizeof(DWORD);
								}
							}
						}
						else
						{
							char* b=I_SrcText;
							b++;
							b[strlen(b)-1]=0;
							C_Include(b);
						}
					}
				
			}
		}
		while(I_Done>0);
		fclose(Include_File);
	}
	CF_Source=Src;
	C_SrcText=C_ST;
	ActLine=ActLn;
	sprintf(C_SrcName,"%s",C_SText);
	
}

bool C_CheckC_Option(char * co)
{
	if(strcmp(co,C_INCLUDE)==0)
	{

		C_GetNext(C_SrcText);
		if(C_SrcText[0]!='"')
			C_CreateError("Missing '\"' after #include");
		char name[255]="";
		BYTE c=0;
		C_Done=fread((void*)C_SrcText,1,1,CF_Source);
		while(C_Done)
		{
			C_SrcText[1]=0;
			if(C_SrcText[0]==10||C_SrcText[0]==13)
				ActLine++;
			if(!strcmp(C_SrcText,"\""))
			{
				break;
			}
			name[c]=C_SrcText[0];
			c++;
			C_Done=fread((void*)C_SrcText,1,1,CF_Source);
		}
		SYS_TextOut("#include '%s'",name);
		//C_Include(name);
		FILE *of=CF_Source;
		CF_Source=fopen(name,"rt");
		char str[255]="";
		if(!CF_Source)
		{
			sprintf(str,"couldn't open '%s'",name);
			C_CreateError(str);
		}

		sprintf(str,"%s",C_SrcName);
		sprintf(C_SrcName,"%s",name);
		DWORD ln=ActLine;
		if(!C_Error)
		C_CInclude(name);
		CF_Source=of;
		sprintf(C_SrcName,"%s",str);
		ActLine=ln;
		SYS_TextOut("'%s' done \n",name);
		return 1;
	}
	if(strcmp(co,C_COMPILE)==0)
	{

		C_GetNext(C_SrcText);
		if(C_SrcText[0]!='"')
			C_CreateError("Missing '\"' after #include");
		char name[255]="";
		BYTE c=0;
		C_Done=fread((void*)C_SrcText,1,1,CF_Source);
		while(C_Done)
		{
			C_SrcText[1]=0;
			if(C_SrcText[0]==10||C_SrcText[0]==13)
				ActLine++;
			if(!strcmp(C_SrcText,"\""))
			{
				break;
			}
			name[c]=C_SrcText[0];
			c++;
			C_Done=fread((void*)C_SrcText,1,1,CF_Source);
		}
		SYS_TextOut("#compile '%s'",name);
		//C_Include(name);
		FILE *of=CF_Source;
		CF_Source=fopen(name,"rt");
		char str[255]="";
		if(!CF_Source)
		{
			sprintf(str,"couldn't open '%s'",name);
			C_CreateError(str);
		}

		sprintf(str,"%s",C_SrcName);
		sprintf(C_SrcName,"%s",name);
		DWORD ln=ActLine;

		C_Compile(name);
		CF_Source=of;
		sprintf(C_SrcName,"%s",str);
		ActLine=ln;
		SYS_TextOut("'%s' done \n",name);
		return 1;
	}
	else if(strcmp(co,C_PRAGMA)==0)
	{
		int enable=-1;
		C_GetNext(C_SrcText);
		if(strcmp(C_SrcText,C_ENABLE)==0)enable=1;
		else if(strcmp(C_SrcText,C_DISABLE)==0)enable=0;
		else C_CreateError("#pragma found but not followed by 'enabled/disabled'");

		if(enable>-1)
		{
			C_GetNext(C_SrcText);
			if(strcmp(C_SrcText,C_BINARY)==0)C_Output_Binary=enable;
			else if(strcmp(C_SrcText,C_DEBUG_INFO)==0)C_Output_DebugInfo=enable;
			else if(strcmp(C_SrcText,C_MAP)==0)C_Output_Map=enable;
			else if(strcmp(C_SrcText,C_SYMBOLS)==0)C_Output_Symbols=enable;
			else C_CreateError("#pragma found but not followed by valid option");
		}
		return 1;
	}
	else if(strcmp(co,"/*")==0)
	{
		int P_Done=0;
		do
		{
			P_Done=C_GetNext(C_SrcText);
		}
		while(P_Done&&strcmp(C_SrcText,"*/")!=0);
		return 1;
	}
	else if(strcmp(co,C_DEFINE)==0)
	{
		DWORD al=ActLine;
		int P_Done=C_GetNext(C_SrcText);
		C_AddCommand(C_SrcText,"",TYPE_SGN);
		DWORD id=GetId(C_SrcText);
		C_Commands[id]->define=1;
		if(al==ActLine)
		{
			C_Done=fread((void*)C_SrcText,1,1,CF_Source);
			while(C_SrcText[0]==32||C_SrcText[0]==9)
			{
				C_Done=fread((void*)C_SrcText,1,1,CF_Source);
			}
			char name[255]="";
			BYTE c=0;
			while(C_Done)
			{
				C_SrcText[1]=0;
				if(C_SrcText[0]==32||C_SrcText[0]==10||C_SrcText[0]==13||C_SrcText[0]==9)
				{
					if(C_SrcText[0]==10||C_SrcText[0]==13)
						ActLine++;
					break;
				}
				name[c]=C_SrcText[0];
				c++;
				C_Done=fread((void*)C_SrcText,1,1,CF_Source);
			}
			C_Commands[id]->def=(char*)malloc(strlen(name));
			sprintf(C_Commands[id]->def,"%s%c",name,0);
		}
		return 1;
	}
	else if(strcmp(co,C_UNDEFINE)==0)
	{
		int P_Done=C_GetNext(C_SrcText);
		DWORD id=GetId(C_SrcText);
		if(!id)
		{
			char str[255]="";
			sprintf(str,"Cannot undefine symbol '%s' as it is not defined.",C_SrcText);
			C_CreateError(str);
		}
		C_Commands[id]->define=0;
		if(C_Commands[id]->def)
			free(C_Commands[id]->def);
		sprintf(C_Commands[id]->CName,"%c",0);
		return 1;
	}
	else if(strcmp(co,C_IFDEF)==0||strcmp(co,C_IFNDEF)==0)
	{
		char name[255]="";
		char b[2];
		BYTE c=0;
		C_Done=fread((void*)b,1,1,CF_Source);
		while(C_Done)
		{
			b[1]=0;
			if(b[0]==32||b[0]==10||b[0]==13||b[0]==9)
			{
				if(b[0]==10)
					ActLine++;
				break;
			}
			name[c]=b[0];
			c++;
			C_Done=fread((void*)b,1,1,CF_Source);
		}

		if((GetId(name)==0xffff&&!strcmp(co,C_IFDEF))||(GetId(name)!=0xffff&&!strcmp(co,C_IFNDEF)))
		{
			int P_Done=C_GetNext(C_SrcText);
			while(strcmp(co,C_ENDIF))
			{
				P_Done=C_GetNext(C_SrcText);
			}
		}
	return 1;
	}
	else if(strcmp(co,C_ENDIF)==0)
	{
		return 1;
		//nada
	}
	else return 0;
}

bool IsKeyDown(int virtKeyCode){if (GetAsyncKeyState(virtKeyCode) & 0x8000) return TRUE;return FALSE;}

void C_ProcessCmd(char*cmd)
{
	DWORD id;
	SHORT tp;
	static DWORD last_id=0xffff;
	static SHORT last_tp=0;
	static bool Func_Def=0;
	bool Created=0;
	bool LineInf=1;
	static fpos_t sfp;
	if(IsKeyDown(VK_ESCAPE))
	{
		C_CreateError("user termination");
		SYS_Error("user termination","");
	}
	
	if(!strcmp(cmd,"\""))//string handling
	{
		fpos_t strfp;
		fgetpos(CF_Source,&strfp);
		DWORD str_len=0;
		C_Done=fread((void*)C_SrcText,1,1,CF_Source);
		while(C_Done)
		{
			C_SrcText[1]=0;
			if(!strcmp(C_SrcText,"\""))
			{
				break;
			}
			C_Done=fread((void*)C_SrcText,1,1,CF_Source);
			str_len++;
		}
		char str[200]="";
		sprintf(str,"string%d",strings);
		strings++;
		C_AddCommand(str,"",TYPE_STR);
		C_TranslateCmd(str,&id,&tp);
		C_Commands[id]->def=(char*)malloc(sizeof(char)*(str_len+1));
		C_Commands[id]->true_args=str_len+1;
		C_Commands[id]->rtype=GetId("char");
		C_Commands[id]->ind=1;
		C_Commands[id]->parentf=0xffff;
		fsetpos(CF_Source,&strfp);
		str_len=0;
		C_Done=fread((void*)C_SrcText,1,1,CF_Source);
		while(C_Done)
		{
			C_SrcText[1]=0;
			if(!strcmp(C_SrcText,"\""))
			{
				break;
			}
			C_Commands[id]->def[str_len]=C_SrcText[0];
			C_Done=fread((void*)C_SrcText,1,1,CF_Source);
			str_len++;
		}
		C_Commands[id]->def[str_len]=0;

		last_id=id;
		last_tp=tp;

		if(C_Output_Binary)
		{
			C_Write((void *)&tp,sizeof(SHORT));
			C_Write((void *)&id,sizeof(DWORD));
		}
		else 
		{
			C_Output_Binary=1;
			C_Write((void*)C_Commands[id]->CName,strlen(C_Commands[id]->CName));
			C_Output_Binary=0;
		}
		if(C_Output_DebugInfo&&C_Output_Binary&&LineInf)
		{
			C_Write((void*)&ActLine,sizeof(DWORD));
		}
		return;
	}
	else if(!C_TranslateCmd(cmd,&id,&tp))
	{
		char str[MAX_CHAR_LEN];
		if(Func_Def)
		{
			if(!next_type)
			{
				char str[MAX_CHAR_LEN];
				sprintf(str,"no returntype specifyed for '%s'.",cmd);
				C_CreateError(str);
				if(C_Error)return;
			}
			char str[MAX_CHAR_LEN]="";
			sprintf(str,"%s(%d)::%s",C_Commands[cmd_id]->CName,C_Level,cmd);
			if(GetId(str)!=0xffff)
			{
				sprintf(str,"'%s' is already defined.",cmd);
				next_type=0;
				C_CreateError(str);
			}
			C_AddCommand(cmd,"",TYPE_CMD);
			C_Commands[GetId(cmd)]->rtype=next_type;
			C_Commands[GetId(cmd)]->ind=next_ind;
			next_type=0;
			next_ind=0;
		}
		else 
		{
			if(!C_TranslateCmdCL(cmd,&id,&tp,C_Level,C_Commands[cmd_id]->CName,1)||(C_Commands[id]->frame!=C_Level&&next_type))
			{
				if(!next_type)
				{
					char name[255]="";
					sprintf(name,cmd);
					C_GetNext(C_SrcText);
					if(!strcmp(C_SrcText,">"))
					{
						C_AddCommand(name,NULL,TYPE_LAB);
						C_TranslateCmd(name,&id,&tp);
						if(C_Output_Binary)
						{
							C_Write((void *)&tp,sizeof(SHORT));
							C_Write((void *)&id,sizeof(DWORD));
						}
						else 
						{
							C_Output_Binary=1;
							C_Write((void*)C_Commands[id]->CName,strlen(C_Commands[id]->CName));
							C_Output_Binary=0;
						}
						if(C_Output_DebugInfo&&C_Output_Binary&&LineInf)
						{
							C_Write((void*)&ActLine,sizeof(DWORD));
						}
						C_TranslateCmd(">",&id,&tp);
						if(C_Output_Binary)
						{
							C_Write((void *)&tp,sizeof(SHORT));
							C_Write((void *)&id,sizeof(DWORD));
						}
						else 
						{
							C_Output_Binary=1;
							C_Write((void*)C_Commands[id]->CName,strlen(C_Commands[id]->CName));
							C_Output_Binary=0;
						}
						if(C_Output_DebugInfo&&C_Output_Binary&&LineInf)
						{
							C_Write((void*)&ActLine,sizeof(DWORD));
						}
						return;
					}
					else
					{
						char str[MAX_CHAR_LEN];
						sprintf(str,"no type specifyed for '%s'.",name);
						C_CreateError(str);
						if(C_Error)return;
					}
				}
				char str[255]="";
				sprintf(str,"%s(%d)::%s",C_Commands[cmd_id]->CName,C_Level,cmd);
				if(GetId(cmd)!=0xffff)
				{
					sprintf(str,"'%s' is already defined.",cmd);
					next_type=0;
					next_ind=0;
					C_CreateError(str);
				}
				C_AddCommand(str,"",TYPE_DEF);
				C_Commands[GetId(str)]->rtype=next_type;
//				C_Commands[GetId(str)]->ind=next_ind;
				if(C_Output_Symbols)
					SYS_TextOut("Symbol(0x%x) type(%s).",GetId(str),C_Commands[next_type]->CName);
				sprintf(str,"%s(%d)::%s%c",C_Commands[cmd_id]->CName,C_Level,cmd,0);
				sprintf(cmd,"%s%c",str,0);
				next_type=0;
				next_ind=0;
			}
			else
			{
				sprintf(cmd,"%s%c",C_Commands[id]->CName,0);
				if((next_type&&C_Commands[id]->frame==C_Level))
				{
					char str[MAX_CHAR_LEN];
					sprintf(str,"'%s' is already defined.",cmd);
					next_type=0;
					next_ind=0;
					C_CreateError(str);
				}
				if(C_Commands[C_Commands[id]->rtype]->rtype>GetId("last"))
				{
					was_struct=1;
					mparent=id;
				}
			}
//			C_Commands[GetId(cmd)]->frame=C_level;
		}
		Created=1;
		
		if(!C_TranslateCmd(cmd,&id,&tp))
		{
			char str[MAX_CHAR_LEN];
			sprintf(str,"Internal error translating local var '%s'.",cmd);
			C_CreateError(str);
			if(C_Error)return;
		}
	}
	else
	{
		if(next_type&&C_Commands[id]->Type==TYPE_CMD&&!C_Commands[id]->incl)
		{
			char str[MAX_CHAR_LEN];
			sprintf(str,"'%s' is already defined.",cmd);
			next_type=0;
			next_ind=0;
			C_CreateError(str);
		}
	}

	if(id==GetId(";"))
	{
		was_struct=0;
		if(willbe_member)
		{
			char str[MAX_CHAR_LEN];
			sprintf(str,"member of struct awaited after '[struct]->' or '[struct].'.",cmd);
			C_CreateError(str);
		}
		willbe_member=0;
	}
	else if(was_struct&&(id==GetId(".")||(id==GetId("->"))))
	{
		willbe_member=1;
	}
	

	if(tp==TYPE_VAR)
	{
		next_type=id;
		next_ind=0;
	}
	else if(id!=GetId("*"))
	{
		next_type=0;
	}
	else next_ind++;

	if(id==GetId("struct"))
	{
		WORD size=0;
		bool wasext=ext;
		ext=0;
		C_GetNext(C_SrcText);
		C_AddCommand(C_SrcText,NULL,TYPE_VAR);
		DWORD st_id=GetId(C_SrcText);
		C_GetNext(C_SrcText);
		if(GetId(C_SrcText)!=GetId("{"))
			C_CreateError("'{' awaited after struct def.");
		fpos_t mfp;
		fgetpos(CF_Source,&mfp);
		DWORD sl=ActLine;
		DWORD num_members=0;
		do
		{
			C_Done=C_GetNext(C_SrcText);
			if(!C_TranslateCmd(cmd,&id,&tp)||tp!=TYPE_VAR)
			{
				if(GetId(C_SrcText)==GetId("}")&&C_Done)
					break;
				char str[MAX_CHAR_LEN];
				sprintf(str,"Unknown/invalid symbol '%s' in struct def found!",cmd);
				C_CreateError(str);
			}
			next_type=id;
			DWORD ptr=0;
			do
			{
				C_Done=C_GetNext(C_SrcText);
				if(GetId(C_SrcText)!=GetId("*"))
				{
					if(!C_TranslateCmd(cmd,&id,&tp))
					{
						char str[255]="";
						sprintf(str,"%s::%s",C_Commands[st_id]->CName,cmd);
						if(!C_TranslateCmd(str,&id,&tp))
						{
							C_AddCommand(str,"",TYPE_DEF);
							C_Commands[GetId(str)]->rtype=next_type;
							C_Commands[GetId(str)]->parentf=st_id;
							if(C_Output_Symbols)
								SYS_TextOut("Symbol(0x%x) type(%s).",GetId(str),C_Commands[next_type]->CName);
							sprintf(cmd,"%s%c",str,0);
							C_Commands[GetId(str)]->argid=size;
							if(!ptr)
								size+=C_Commands[next_type]->frame;
							else size+=sizeof(void*);
							C_Commands[GetId(str)]->ind=ptr;
							ptr=0;
						}
						else
						{
							char str[MAX_CHAR_LEN];
							sprintf(str,"Already defined symbol '%s' in struct def found!",cmd);
							C_CreateError(str);
						}
						num_members++;
					}
					else
					{
						char str[MAX_CHAR_LEN];
						sprintf(str,"Already defined symbol '%s' in struct def found!",cmd);
						C_CreateError(str);
					}
					C_Done=C_GetNext(C_SrcText);
					if(GetId(C_SrcText)!=GetId(",")&&GetId(C_SrcText)!=GetId(";"))
					{
						char str[MAX_CHAR_LEN];
						sprintf(str,"',' or ';' awaited but '%s' in struct def found!",cmd);
						C_CreateError(str);
					}
				}
				else 
				{
					num_members++;
					ptr++;
				}
								
			}
			while(C_Done&&GetId(";")!=GetId(C_SrcText));
			if(!C_Done)
				C_CreateError("Unexpected eof");
		}
		while(GetId(C_SrcText)!=GetId("}")&&C_Done);
		C_Done=C_GetNext(C_SrcText);
		if(!C_TranslateCmd(cmd,&id,&tp)||id!=GetId(";"))
		{
			char str[MAX_CHAR_LEN];
			sprintf(str,"';'awaited but '%s' found!",cmd);
			C_CreateError(str);
		}
		fsetpos(CF_Source,&mfp);
		ActLine=sl;

		C_Commands[st_id]->args=(DWORD*)malloc(num_members*sizeof(DWORD));
		C_Commands[st_id]->ext=0;
		C_Commands[st_id]->nargs=0;
		C_Commands[st_id]->rtype=st_id;
		
		BYTE al_size=4;

		if(!IsDef(GetId("_ALLIGN"))||C_Commands[GetId(C_Commands[GetId("_ALLIGN")]->def)]->Type!=TYPE_VAR)
		{
			g=155;
			r=155;

			SYS_TextOut("No allignment specifyed...assuming DWORD allignment.");

			g=10;
			r=10;
		}
		else if(C_Output_Symbols)
		{
			SYS_TextOut("Code is %s alligned.",C_Commands[GetId("_ALLIGN")]->def);
			al_size=C_Commands[GetId(C_Commands[GetId("_ALLIGN")]->def)]->frame;
		}

		DWORD as=0;
		while(abs((int)as-(int)size)>al_size/2)
			as+=al_size;
		if(as<size)as+=al_size;
		size=as;
		if(C_Output_Symbols)
			SYS_TextOut("Alligned size of struct is %d.",size);
		C_Commands[st_id]->frame=size;
		do
		{
			C_Done=C_GetNext(C_SrcText);
			if(!C_TranslateCmd(cmd,&id,&tp)||tp!=TYPE_VAR)
			{
				if(GetId(C_SrcText)==GetId("}")&&C_Done)
					break;
			}
			next_type=id;
			do
			{
				C_Done=C_GetNext(C_SrcText);
				if(GetId(C_SrcText)!=GetId("*"))
				{
					if(!C_TranslateCmd(cmd,&id,&tp))
					{
						char str[255]="";
						sprintf(str,"%s::%s",C_Commands[st_id]->CName,cmd);
						if(C_TranslateCmd(str,&id,&tp))
						{
							*(C_Commands[st_id]->args+C_Commands[st_id]->nargs)=id;
							C_Commands[st_id]->nargs++;
							sprintf(cmd,"%s%c",str,0);
						}
					}
					C_Done=C_GetNext(C_SrcText);
				}
				else 
				{
					C_TranslateCmd(cmd,&id,&tp);
					*(C_Commands[st_id]->args+C_Commands[st_id]->nargs)=id;
					C_Commands[st_id]->nargs++;
				}
								
			}
			while(C_Done&&GetId(";")!=GetId(C_SrcText));
			if(!C_Done)
				C_CreateError("Unexpected eof");
		}
		while(GetId(C_SrcText)!=GetId("}")&&C_Done);
		C_Done=C_GetNext(C_SrcText);

//		C_Done=C_GetNext(C_SrcText);
		if(!C_Done)
			C_CreateError("Unexpected eof");
		ext=wasext;
		if(C_Output_Symbols)
			SYS_TextOut("struct '%s' defined.",C_Commands[st_id]->CName);
		return;
	}
	
	if(id==GetId("{"))
	{
		C_Level++;
	}
	else if(id==GetId("}"))
	{
		C_Level--;
//		if(C_Level==1)
//			C_Level=0;
		if(C_Level<0)
			C_CreateError("'}' witout heading '{'.");
		if(!C_Level)
			cmd_id=0xffff;
	}
	else if(tp==TYPE_FNC)
	{
		fgetpos( CF_Target,  &sfp );
		if(!strcmp(cmd,"__cdecl"))
		{
			
			Func_Def=1;
			if(C_Level)
				C_CreateError("funcion def inside of function is not allowed");
		}
		else 
		{
			ext=1;
		}
	}

	if(xInclude&&!Func_Def)
	{
		char str[255]="";
		sprintf(str,"'%s' found, but only function defs are allowed in header files.",cmd);
		C_CreateError(str);
	}

//	if(tp==TYPE_VAR) //must write casts
//		return;

	if(C_Output_Binary)
	{
		C_Write((void *)&tp,sizeof(SHORT));
		C_Write((void *)&id,sizeof(DWORD));
	}
	else 
	{
		C_Output_Binary=1;
		C_Write((void*)C_Commands[id]->CName,strlen(C_Commands[id]->CName));
		C_Output_Binary=0;
	}

	if(tp==TYPE_CMD&&Func_Def)
	{
		Func_Def=0;
		fpos_t mp;
		DWORD cid=id;
		DWORD lcid=cmd_id;
		cmd_id=cid;
//		C_Level++;

		fpos_t mnp;
		fgetpos( CF_Target,  &mnp );
		mnp-=sizeof(DWORD)+sizeof(SHORT);

		if(!Created&&!C_Commands[id]->def)C_Commands[id]->frame=1;
		if(C_Commands[id]->args&&!C_Commands[id]->def)
		{
			char str[255]="";
			sprintf(str,"function '%s' is already defined.",cmd);
			C_CreateError(str);
		}
		if(C_Commands[id]->args)
		{
			C_Commands[id]->def=(char*)1;
			if(!C_Commands[id]->frame)Created=1;
		}
		C_GetNext(cmd);
		C_TranslateCmd(cmd,&id,&tp);
		if(id!=GetId("("))
			C_CreateError("'(' awaited after function definition.");
		fgetpos( CF_Source,  &mp );
		WORD num_args=0;
		next_type=0;
		WORD argid=0;
		while(id!=GetId(")"))
		{
			if(!C_GetNext(cmd))
			{
				C_CreateError("unexpected EOF");
				break;
			}

			if(!C_TranslateCmd(cmd,&id,&tp))
			{
				char str[255]="";
				sprintf(str,"%s(%d)::%s",C_Commands[cmd_id]->CName,C_Level,cmd);
				if(!C_TranslateCmdCL(cmd,&id,&tp,C_Level,C_Commands[cmd_id]->CName,0))
				{
					if(!next_type)
					{
						char str[255]="";
						sprintf(str,"no type for '%s' defined",C_Commands[id]->CName);
						C_CreateError(str);					
					}
					C_AddCommand(str,"",TYPE_DEF);
					C_TranslateCmd(str,&id,&tp);
					C_Commands[id]->FPOS=mnp;
					C_Commands[id]->rtype=next_type;
					C_Commands[id]->argid=argid;
					argid++;
					if(C_Output_Symbols)
						SYS_TextOut("Symbol(0x%x) type(%s).",id,C_Commands[next_type]->CName);
					next_type=0;
				}
			}
			else if(tp==TYPE_VAR)
			{
				if(id==GetId("?"))
				{
					char str[255]="";
					char name[255]="";
					sprintf(name,"?CompilerGeneratedID%d",timeGetTime());
					sprintf(str,"%s(%d)::%s",C_Commands[cmd_id]->CName,C_Level,name);
					C_AddCommand(str,"",TYPE_DEF);
					C_TranslateCmd(str,&id,&tp);
					C_Commands[id]->FPOS=mnp;
					C_Commands[id]->rtype=id;
					C_Commands[id]->argid=argid;
					argid++;
//					num_args++;
					next_type=0;
				}
				else
					next_type=id;
			}


			if(tp==TYPE_DEF||id==GetId("*"))
				num_args++;
			else if(id!=GetId(",")&&id!=GetId(")")&&tp!=TYPE_VAR)
				C_CreateError("Invalid function header");
		}
		C_Commands[cid]->true_args=argid+1;
		fsetpos(CF_Source,&mp);
		if(!C_Commands[cid]->def)
		{
			C_Commands[cid]->args=(DWORD*)malloc((num_args)*sizeof(DWORD));
			C_Commands[cid]->nargs=num_args;
		}
		int i=0;
		while(i<num_args)
		{
			C_GetNext(cmd);
			if(!C_TranslateCmd(cmd,&id,&tp))
			{
				C_TranslateCmdCL(cmd,&id,&tp,C_Level,C_Commands[cmd_id]->CName,0);
			}
			if(id==GetId("?"))
			{
				num_args--;
				*(C_Commands[cid]->args+i)=GetId("?");
			}
			if(tp==TYPE_DEF||id==GetId("*"))
			{
				if(!C_Commands[cid]->def)
				{
					*(C_Commands[cid]->args+i)=id;
				}
				else if(*(C_Commands[cid]->args+i)!=id)
				{
					char str[255]="";
					sprintf(str,"'%s':function decleation differs from function header.",C_Commands[cid]->CName);
					C_CreateError(str);					
				}
				i++;
			}
		}
		C_GetNext(cmd);
		fgetpos( CF_Source,  &mp );
		if(!C_GetNext(cmd))
			C_CreateError("unexpected EOF");
		C_TranslateCmd(cmd,&id,&tp);
		if(id!=GetId(";"))
		{
			if(xInclude)
				C_CreateError("function bodys are not allowed in header files");
			if(id!=GetId("{"))
				C_CreateError("function body '{' awaited after function def.");
			else if(!Created)
			{
				char str[255]="";
				sprintf(str,"function '%s' has already got a body as it is already defined.",C_Commands[cid]->CName);
				C_CreateError(str);
			}
			fsetpos(CF_Source,&mp);
			C_ChangeCommand(C_Commands[cmd_id]->CName,mnp);
			C_Commands[cmd_id]->ext=0;
			if(C_Output_Symbols)
			{
				char str[255]="";
				if(C_Commands[cmd_id]->ext)sprintf(str,"extern ");
				SYS_TextOut("Symbol(0x%x) '%s%s' real adress 0x%x.",C_Commands[cmd_id]->ID,str,C_Commands[cmd_id]->CName,mnp);
			}
			//C_Level++;
			//C_Commands[id]->Type=TYPE_CMD;
		}
		else
		{
			if(xInclude)C_Commands[cid]->incl=1;
			if(C_Commands[cid]->ext)C_ChangeCommand(C_Commands[cmd_id]->CName,mnp);

			cmd_id=lcid;
			if(!C_Commands[cid]->def)
				C_Commands[cid]->def=(char*)1;
			else
			{
				char str[255]="";
				sprintf(str,"function '%s' is already defined.",C_Commands[cid]->CName);
				C_CreateError(str);
			}
			LineInf=0;
			WORD id;
			fsetpos(CF_Target,&sfp);
		}
//		C_Level--;
	}
	

	if(C_Output_DebugInfo&&C_Output_Binary&&LineInf)
	{
		C_Write((void*)&ActLine,sizeof(DWORD));
	}

	last_id=id;
	last_tp=tp;
}

void SubDef(char*c)
{
	char* mc=(char*)malloc(strlen(c));
	memcpy(mc,c,strlen(c));
	mc[strlen(c)]=0;
	char* def=C_Commands[GetId(mc)]->def;
	while(C_GetSub(&C_Commands[GetId(mc)]->def,C_SrcText))
	{
		if(IsDef(GetId(C_SrcText)))
			SubDef(C_SrcText);
		else C_ProcessCmd(C_SrcText);
	}
	C_Commands[GetId(mc)]->def=def;
	free(mc);
}

bool C_CInclude(char* sn)
{
	xInclude=1;
	do
	{
		C_Done=C_GetNext(C_SrcText);
	}
	while(C_Done&&C_CheckC_Option(C_SrcText));

	while(C_Done)
	{
		ext=1;
		if(IsDef(GetId(C_SrcText)))
		{
			SubDef(C_SrcText);
			C_Done=C_GetNext(C_SrcText);
		}
		else
		{
			if(!C_CheckC_Option(C_SrcText))
				C_ProcessCmd(C_SrcText);
			C_Done=C_GetNext(C_SrcText);
		}
	}
	ext=0;
	xInclude=0;
	return 0;
}

bool C_Compile(char* sn)
{

	if(!C_inited&&!C_Commands[0xffff])
	{
		char none[7]="global";
		C_Commands[0xffff]=(Cmd*)malloc(sizeof(Cmd));
		C_Commands[0xffff]->CName=(char*)malloc(sizeof(char)*strlen(none));
		for(int i=0;i<=strlen(none);i++)
		C_Commands[0xffff]->CName[i]=none[i];
		C_Commands[0xffff]->ID=0xffff;
		C_Commands[0xffff]->Type=0;
		C_Commands[0xffff]->FPOS=0;
		C_Commands[0xffff]->define=0;
		C_Commands[0xffff]->frame=0;
		C_Commands[0xffff]->def=0;
		
		SYS_TextOut("Compiler Version: %f",C_GetCompilerVer());
		SYS_TextOut("Loading symbols from std.def..");
		C_Include("std.def");
		g=155;
		SYS_TextOut(C_Commands[GetId("BUILD")]->def);
		g=10;
/*
		C_Commands[GetId("float")]->rtype=GetId("float");
		C_Commands[GetId("float")]->frame=sizeof(DWORD);
		C_Commands[GetId("WORD")]->rtype=GetId("WORD");
		C_Commands[GetId("WORD")]->frame=sizeof(DWORD);
		C_Commands[GetId("DWORD")]->rtype=GetId("DWORD");
		C_Commands[GetId("DWORD")]->frame=sizeof(DWORD);
		C_Commands[GetId("int")]->rtype=GetId("int");
		C_Commands[GetId("int")]->frame=sizeof(DWORD);
		C_Commands[GetId("char")]->rtype=GetId("char");
		C_Commands[GetId("char")]->frame=sizeof(DWORD);
		C_Commands[GetId("bool")]->rtype=GetId("bool");
		C_Commands[GetId("bool")]->frame=sizeof(DWORD);
		C_Commands[GetId("BYTE")]->rtype=GetId("BYTE");
		C_Commands[GetId("BYTE")]->frame=sizeof(DWORD);
		C_Commands[GetId("SHORT")]->rtype=GetId("SHORT");
		C_Commands[GetId("SHORT")]->frame=sizeof(DWORD);
		C_Commands[GetId("void")]->rtype=GetId("void");
		C_Commands[GetId("void")]->frame=sizeof(DWORD);
*/		SYS_TextOut("");
		ForbidSymbols=1;
		C_SrcText=(char*)malloc(sizeof(char)*MAX_CHAR_LEN);
	}

	do
	{
		C_Done=C_GetNext(C_SrcText);
	}
	while(C_CheckC_Option(C_SrcText));

	if(C_Output_Binary==-1)
		C_CreateError("'#pragma binary' not found; '#pragma binary'must be set!");
	if(!C_inited)
	{
		//save settings for later use
		bool CB=C_Output_Binary;
		C_Output_Binary=1;//always write begin info as binary...
		float f=C_GetCompilerVer();
		C_Write((void *)&f,sizeof(float));//firstly version number
		C_Write((void *)&CB,sizeof(BYTE));//secondly if we do it binary or not
		C_Write((void *)&C_Output_DebugInfo,sizeof(BYTE));//thirdly if we have debuginfo(srccode)
		if(C_Output_DebugInfo)
		{
			C_Write((void *)sn,strlen(sn));//4. if we have debuginfo(srccode)
			sn[0]=0;
			C_Write((void *)sn,1);//4. if we have debuginfo(srccode)
		}
		C_Output_Binary=CB;
		fgetpos(CF_Target,&C_Init_FPOS);
		C_inited=1;
	}

	while(C_Done)
	{
		if(IsDef(GetId(C_SrcText)))
		{
			SubDef(C_SrcText);
			C_Done=C_GetNext(C_SrcText);
		}
		else
		{
			if(!C_CheckC_Option(C_SrcText))
				C_ProcessCmd(C_SrcText);
			C_Done=0;
			C_Done=C_GetNext(C_SrcText);
		}
	}

	if(!IsDef(GetId("NO_SYMBOL_CHECK")))
	{
		for(int i=0;i<=C_Num_Commands;i++)
		{
			if(C_Commands[i]->Type==TYPE_CMD&&!C_Commands[i]->args)
			{
				char str[255]="";
				sprintf(str,"missing function header for function '%s'",C_Commands[i]->CName);
				C_CreateError(str);
			}
			else if(C_Commands[i]->Type==TYPE_CMD&&!C_Commands[i]->FPOS)
			{
				char str[255]="";
				sprintf(str,"missing function body for function '%s'",C_Commands[i]->CName);
				C_CreateError(str);
			}
			else if(C_Commands[i]->Type==TYPE_EXT&&!C_Commands[i]->FPOS)
			{
				char str[255]="";
				sprintf(str,"missing decleration of external var '%s'.",C_Commands[i]->CName);
				C_CreateError(str);
			}
		}
	}
	if(C_Error)
	{
		SYS_Error("","");
	}
	
	return C_Error;

}