/*
	softcore(TM) virtual c translator
	(c) Alex Herz 1999-2000
*/

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <commdlg.h>
#include <stdarg.h>

#include <winbase.h>
#include <winuser.h>

#include <mmsystem.h>
#include <math.h>

#include "symbols.h"
#include "compiler.h"

#include "vm_asm.h"
//#include "fifo.h"

extern int C_Output_Binary;
extern int C_Output_DebugInfo;
extern int C_Output_Map;

extern Cmd* C_Commands[__MAX_COMMANDS];
extern int C_Num_Commands;
extern fpos_t C_Init_FPOS;
extern char C_SrcName[MAX_CHAR_LEN];
#define DEF_LINE_MAX 5000
bool ext_flag=0;

bool Warn_Conv=1;

struct LL
{
	fpos_t pos;
	DWORD id;
	LL*next;
};

struct LL2
{
	fpos_t pos;
	DWORD Level;
	LL2*next;
};

struct Lev
{
	fpos_t pos;
	DWORD Level;
	Lev*next;
};

WORD C_Warnings=0;

DWORD DATASEG=0;

FILE* sourcef=0;
FILE* targetf=0;

BYTE Regs=0;
BYTE Ebp=0;
DWORD RegStart=0;
DWORD RegEnd=0;
//EventHandler CmdStack;

struct CCmd
{
	SHORT tp;
	DWORD id;
};

CCmd *CCMD;
CCmd* Line=NULL;
DWORD LineLen=0;
CCmd *FL;
DWORD *uni=0;

DWORD FuncCall(CCmd* db,WORD len,DWORD fid);
DWORD BuildLine(CCmd* db,WORD len);
void CompileBody(DWORD Level,DWORD abbort,DWORD func);

LL ml;
LL locl;
LL2 mll;
Lev mlev;
LL ml2;
void AddList(fpos_t pos,DWORD id)
{
	LL* ll=&ml;
	while(ll->next)ll=ll->next;
	ll->next=(LL*)malloc(sizeof(LL));
	ll=ll->next;
	ll->next=NULL;
	ll->pos=pos;
	ll->id=id;
}

void AddListLoc(fpos_t pos,DWORD id)
{
	LL* ll=&locl;
	while(ll->next)ll=ll->next;
	ll->next=(LL*)malloc(sizeof(LL));
	ll=ll->next;
	ll->next=NULL;
	ll->pos=pos;
	ll->id=id;
}

void AddListLL(fpos_t pos,DWORD id)
{
	LL* ll=&ml2;
	while(ll->next)ll=ll->next;
	ll->next=(LL*)malloc(sizeof(LL));
	ll=ll->next;
	ll->next=NULL;
	ll->pos=pos;
	ll->id=id;
}

void AddListL(fpos_t pos,DWORD Level)
{
	LL2* ll=&mll;
	while(ll->next)ll=ll->next;
	ll->next=(LL2*)malloc(sizeof(LL2));
	ll=ll->next;
	ll->next=NULL;
	ll->pos=pos;
	ll->Level=Level;
}

void AddListLev(fpos_t pos,DWORD Level)
{
	Lev* ll=&mlev;
	while(ll->next)ll=ll->next;
	ll->next=(Lev*)malloc(sizeof(Lev));
	ll=ll->next;
	ll->next=NULL;
	ll->pos=pos;
	ll->Level=Level;
}

void FreeList()
{
	LL* ll=&ml;
	while(ll->next)
	{
		ll=ll->next;	
		free(ll);
	}
}

DWORD FtoD(float f)
{
	DWORD d;
	memcpy(&d,&f,sizeof(DWORD));
	return d;
}

bool P_FetchInstruction(SHORT* tp,DWORD* id)
{

	if(!fread((void*)tp,sizeof(SHORT),1,sourcef))
		return 0;
	if(!fread((void*)id,sizeof(DWORD),1,sourcef))
		return 0;

	if(C_Output_DebugInfo)
	{
		extern DWORD ActLine;
		if(!fread((void*)&ActLine,sizeof(DWORD),1,sourcef))
			return 0;
		
	}


	return 1;
} 

void P_UndoFetch()
{

	fseek(sourcef,-(sizeof(SHORT)+sizeof(DWORD)),SEEK_CUR);
	if(C_Output_DebugInfo)
	{
		fseek(sourcef,-(sizeof(DWORD)),SEEK_CUR);	
	}
} 

char* P_SymbolName(DWORD id)
{
	return C_Commands[id]->CName;
}

DWORD P_FindFunc()
{
	for(int i=0;i<=C_Num_Commands;i++)
	{
		if(C_Commands[i]->FPOS)
			return i;
	}
	return 0xffff;
}

void P_Write(WORD size,...)
{
    va_list argptr;

	va_start( argptr, size );
	DWORD dw=0;
	for(int i=0;i<size;i++)
	{
		dw=va_arg( argptr , DWORD );
		fwrite((void*)&dw,sizeof(DWORD),1,targetf);
	}
	dw=vend;
	fwrite((void*)&dw,sizeof(DWORD),1,targetf);
		
    va_end( argptr );
}

void FillIn(fpos_t pos,DWORD Level)
{
	LL2* ll=&mll;
	while(1)
	{
		if(ll->Level==Level)
		{
			fsetpos(targetf,&ll->pos);
			P_Write(1,pos);
			ll->Level=0;
		}
		if(!ll->next)break;
		ll=ll->next;
	}
}

void FillInCmdList(DWORD id)
{
	fpos_t mfp;
	fgetpos(targetf,&mfp);
	LL* ll=&ml;
	while(1)
	{
		if(ll->id==id)
		{
			fsetpos(targetf,&ll->pos);
			P_Write(1,C_Commands[id]->FPOS);
			ll->id=0;
		}
		if(!ll->next)break;
		ll=ll->next;
	}
	fsetpos(targetf,&mfp);
}

void FillInLL(DWORD id)
{
	fpos_t mfp;
	fgetpos(targetf,&mfp);
	LL* ll=&ml2;
	while(1)
	{
		if(ll->id==id)
		{
			fsetpos(targetf,&ll->pos);
			P_Write(1,C_Commands[id]->FPOS);
			ll->id=0;
		}
		if(!ll->next)break;
		ll=ll->next;
	}
	fsetpos(targetf,&mfp);
}

void ExtFlag(DWORD reg)
{
	bool ef=C_Commands[reg]->ext;
	if(ext_flag!=ef)
	{
		if(ef)
		{
			P_Write(1,vext);	
			ext_flag=ef;
		}
		else
		{
			P_Write(1,vnext);	
			ext_flag=ef;
		}
	}
}

void SolveSaveInd(DWORD reg)
{
	if(C_Commands[reg]->save_ind)
	{
//		ExtFlag(reg);
		P_Write(6,vmov,reg-RegStart,rsep,iopen,reg-RegStart,iclose);
		C_Commands[reg]->save_ind=0;
	}
}

double GetNumber(bool f,bool gn,WORD* len)//read in a number..error if invalid
{
	SHORT tp;
	DWORD id;
	WORD base=1;
	WORD n=0;
	WORD k=0;
	double res=0;
	fpos_t ap;
	bool min=0;
	fgetpos(sourcef,&ap);
	P_FetchInstruction(&tp,&id);
	if(id==GetId("-"))
	{
		min=1;
		P_FetchInstruction(&tp,&id);
	}
	while(id==GetId(".")||(id>=GetId("0")&&id<=GetId("9")))
	{
		if(id==GetId("."))
		{
			if(!f)SYS_Error("syntax error : no broken value allowed here.","");
			if(k)SYS_Error("syntax error : several '.' in number.","");
			k=n;
		}
		n++;
		P_FetchInstruction(&tp,&id);
	}
	if(!n)
		SYS_Error("invalid number","");
	if(gn)
		*len=n+min;
	fsetpos(sourcef,&ap);
	if(!k)k=n;
	WORD num=0;
	while(n)
	{
		P_FetchInstruction(&tp,&id);
		if(num<k)
		{
			DWORD base=1;
			for(int i=1;i<k-num;i++)
			{
				base*=10;
			}

			res+=base*(id-GetId("0"));
			//10^(k-num)
		}
		else if(num>k)//after '.'
		{
			if((id-GetId("0")))
			{
				DWORD base=1;
				for(int i=1;i<num-k+1;i++)
				{
					base*=10;
				}
				res+=(((float)(id-GetId("0"))/(float)base));			
			}
		}
		num++;
		n--;
	}
	if(min)res=-res;
	return res;
}

void P_Fetchfl(SHORT* tp,DWORD *id)
{
	*tp=FL->tp;
	*id=FL->id;
	FL++;
}

DWORD P_RegLoadAdress(DWORD id)
{
	if(Regs+RegStart>=RegEnd)return RegEnd;
	C_Commands[Regs+RegStart]->ext=C_Commands[id]->ext;
	if(C_Commands[id]->frame==0&&C_Commands[id]->parentf!=0xffff&&!C_Commands[id]->ext)
	{
		Regs++;
		P_Write(4,vmov,Regs-1,rsep,Ebp-RegStart);
		P_Write(5,vsub,Regs-1,rsep,cst,((C_Commands[C_Commands[id]->parentf]->true_args-C_Commands[id]->argid)*4));
		return Regs-1+RegStart;
	}
	else if(!C_Commands[id]->frame||C_Commands[id]->ext)
	{
		Regs++;
		P_Write(5,vmov,Regs-1,rsep,cst,(C_Commands[id]->FPOS));
		if(C_Commands[id]->ext)
		{
			fpos_t fp;
			fgetpos(targetf,&fp);
			fp-=8;
			AddList(fp,id);
		}
		else
		{
			fpos_t fp;
			fgetpos(targetf,&fp);
			fp-=8;
			AddListLoc(fp,C_Commands[id]->FPOS);
		}
		return Regs-1+RegStart;
	}
	else
	{
		Regs++;
		P_Write(7,vmov,Regs-1,rsep,Ebp-RegStart,radd,cst,(C_Commands[id]->FPOS));
		return Regs-1+RegStart;
	}
}

double GetNumberfl(bool f,WORD *gn,WORD* len)//read in a number..error if invalid
{
	SHORT tp;
	DWORD id;
	WORD base=1;
	WORD n=0;
	WORD k=0;
	double res=0;
	bool min=0;
	CCmd* fpos=FL;
	P_Fetchfl(&tp,&id);
	if(id==GetId("-"))
	{
		min=1;
		P_Fetchfl(&tp,&id);
	}
	while(n<*len&&(id==GetId(".")||(id>=GetId("0")&&id<=GetId("9"))))
	{
		if(id==GetId("."))
		{
			if(!f)SYS_Error("syntax error : no broken value allowed here.","");
			if(k)SYS_Error("syntax error : several '.' in number.","");
			k=n;
			if(gn)
				*gn=k;
		}
		n++;
		P_Fetchfl(&tp,&id);
	}
	if(!n)
		SYS_Error("invalid number","");
	FL=fpos;
	if(gn)
		*len=n;
	if(!k)k=n;
	WORD num=0;
	while(n)
	{
		P_Fetchfl(&tp,&id);
		if(num<k)
		{
			DWORD base=1;
			for(int i=1;i<k-num;i++)
			{
				base*=10;
			}

			res+=base*(id-GetId("0"));
			//10^(k-num)
		}
		else if(num>k)//after '.'
		{
			if((id-GetId("0")))
			{
				DWORD base=1;
				for(int i=1;i<num-k+1;i++)
				{
					base*=10;
				}
				res+=(((float)(id-GetId("0"))/(float)base));			
			}
		}
		num++;
		n--;
	}
	if(min)res=-res;
	return res;
}

void Unify(DWORD **w,float *f)
{
	*w=(DWORD*)f;
}

void Unify(DWORD **w,long *f)
{
	*w=(DWORD*)f;
}

bool GetLine(DWORD mid)
{
	LineLen=0;
	SHORT tp;
	DWORD id;
	if(!P_FetchInstruction(&tp,&id))
		return 0;
	if(mid!=GetId(")"))
	{
		while(strcmp(P_SymbolName(mid),P_SymbolName(id)))//while not ';'
		{
			if(LineLen>=DEF_LINE_MAX)
				SYS_Error("Symbols in line exceed max ammount","");
			(Line+LineLen)->tp=tp;
			(Line+LineLen)->id=id;
			LineLen++;
			if(!P_FetchInstruction(&tp,&id))
				return 0;
		}
	}
	else
	{
		DWORD Level=1;
		while(1)//while not ';'
		{
			if(id==GetId("("))
				Level++;
			if(id==GetId(")"))
				Level--;
			if(!Level)break;
			if(LineLen>=DEF_LINE_MAX)
				SYS_Error("Symbols in line exceed max ammount","");
			(Line+LineLen)->tp=tp;
			(Line+LineLen)->id=id;
			LineLen++;
			if(!P_FetchInstruction(&tp,&id))
				return 0;
		}
	}
	return 1;
}

CCmd* GetLeft(CCmd* buf)
{
	while(!buf->id)buf--;
	return buf;
}

CCmd* GetRight(CCmd* buf)
{
	while(!buf->id)buf++;
	return buf;
}

void C_CreateASMError(char*c,DWORD id)
{
	char str[255]="";
	char ci[255]="";
	char ext_flag[255]="";
	DWORD reg=id;
	if(C_Commands[id]->parentf&&C_Commands[id]->parentf>RegEnd&&C_Commands[id]->parentf!=0xffff)
		id=C_Commands[id]->parentf;
	if(C_Commands[id]->ext)
		sprintf(ext_flag,"extern%c",0);
	for(int i=0;i<C_Commands[id]->ind+C_Commands[id]->save_ind;i++)
		ci[i]='*';
	sprintf(str,"%s , Item: '%s  %s %s%s [%d] @ %d%c' ",c,ext_flag,C_Commands[C_Commands[id]->rtype]->CName,ci,C_Commands[id]->CName,C_Commands[id]->dim,C_Commands[id]->FPOS,0);
	C_CreateError(str);
}

void C_CreateASMWarning(char*c,DWORD id)
{
	char str[255]="";
	char ci[255]="";
	char ext_flag[255]="";
	DWORD reg=id;
	if(C_Commands[id]->parentf&&C_Commands[id]->parentf>RegEnd)
		id=C_Commands[id]->parentf;
	if(C_Commands[id]->ext)
		sprintf(ext_flag,"extern%c",0);
	for(int i=0;i<C_Commands[id]->ind+C_Commands[id]->save_ind;i++)
		ci[i]='*';
	extern DWORD ActLine;
	sprintf(str,"%s(%d) : warning :%s , Item: '%s  %s %s%s [%d] @ %d%c' ",C_SrcName,ActLine,c,ext_flag,C_Commands[C_Commands[id]->rtype]->CName,ci,C_Commands[id]->CName,C_Commands[id]->dim,C_Commands[id]->FPOS,0);
	extern BYTE r,g,b;
	g=125;
	SYS_TextOut(str);
	g=10;
	C_Warnings++;
}

void ConvToFloat(DWORD reg,DWORD rtype)
{
	SolveSaveInd(reg);
	if(Warn_Conv&&rtype!=GetId("?"))
	{
		char str[255]="";
		sprintf(str,"Auto-Converting %s to float.",C_Commands[rtype]->CName);
		C_CreateASMWarning(str,reg);
	}
	if(rtype==GetId("bool"))
		P_Write(2,bltof,reg-RegStart);
	else if(rtype==GetId("WORD"))
		P_Write(2,wtof,reg-RegStart);
	else if(rtype==GetId("int"))
		P_Write(2,itof,reg-RegStart);
	else if(rtype==GetId("BYTE"))
		P_Write(2,bytof,reg-RegStart);
	else if(rtype==GetId("DWORD"))
		P_Write(2,dwtof,reg-RegStart);
	else if(rtype==GetId("char"))
		P_Write(2,ctof,reg-RegStart);
	else if(rtype==GetId("SHORT"))
		P_Write(2,stof,reg-RegStart);
	else if(rtype==GetId("float")||rtype==GetId("?"))
		return;
	else if(rtype==GetId("void"))
		C_CreateASMError("cannot convert void to float",reg);
	else
	{
		char str[255]="";
		sprintf(str,"cannot convert %s to float",C_Commands[rtype]->CName);
		C_CreateASMError(str,reg);
	}
	C_Commands[reg]->rtype=GetId("float");
//	C_Commands[reg]->ind=0;
}

void FloatToType(DWORD reg,DWORD rtype)
{
	SolveSaveInd(reg);
	if(Warn_Conv&&rtype!=GetId("?"))
	{
		char str[255]="";
		sprintf(str,"Auto-Converting float to %s.",C_Commands[rtype]->CName);
		C_CreateASMWarning(str,reg);
	}
	if(rtype==GetId("bool"))
		P_Write(2,ftobl,reg-RegStart);
	else if(rtype==GetId("WORD"))
		P_Write(2,ftow,reg-RegStart);
	else if(rtype==GetId("int"))
		P_Write(2,ftoi,reg-RegStart);
	else if(rtype==GetId("BYTE"))
		P_Write(2,ftoby,reg-RegStart);
	else if(rtype==GetId("DWORD"))
		P_Write(2,ftodw,reg-RegStart);
	else if(rtype==GetId("char"))
		P_Write(2,ftoc,reg-RegStart);
	else if(rtype==GetId("SHORT"))
		P_Write(2,ftos,reg-RegStart);
	else if(rtype==GetId("float")||rtype==GetId("?")||C_Commands[reg]->rtype==GetId("?"))
		return;
	else if(rtype==GetId("void"))
		C_CreateASMError("cannot convert float to void",reg);
	else
	{
		char str[255]="";
		sprintf(str,"cannot convert float to %s",C_Commands[rtype]->CName);
		C_CreateASMError(str,reg);
	}
	C_Commands[reg]->rtype=rtype;
//	C_Commands[reg]->ind=0;
}

bool LeadingOP(CCmd* db)
{
	if(db->id==GetId("<"))
		return 1;
	if(db->id==GetId(">"))
		return 1;
	if(db->id==GetId(","))
		return 1;
	if(db->id==GetId("="))
		return 1;
	if(db->id==GetId("*"))
		return 1;
	if(db->id==GetId("/"))
		return 1;
	if(db->id==GetId("+"))
		return 1;
	if(db->id==GetId("-"))
		return 1;
	if(db->id==GetId("&"))
		return 1;
	if(db->id==GetId("|"))
		return 1;
	if(db->id==GetId("!"))
		return 1;
	return 0;
}

void ConvRegFromTo(DWORD reg,DWORD type1,DWORD type2)
{
	if(type1==type2)return;
	if(type1==GetId("float"))
		FloatToType(reg,type2);
	else if(type2==GetId("float"))
		ConvToFloat(reg,type1);
	else
	{
		ConvToFloat(reg,type1);
		FloatToType(reg,type2);		
	}
}

DWORD FindLogic(CCmd* buf,WORD len,char* symb)
{
	Warn_Conv=0;
	DWORD op=vcmp;
	DWORD jmpt;
	DWORD LastReg=0;
	if(!strcmp(symb,"=="))
		jmpt=jne;
	if(!strcmp(symb,"!="))
		jmpt=je;
	if(!strcmp(symb,">="))
		jmpt=jl;
	if(!strcmp(symb,"<="))
		jmpt=jg;
	if(!strcmp(symb,">"))
		jmpt=jle;
	if(!strcmp(symb,"<"))
		jmpt=jge;
	bool fl=0;
	bool lconv=0;
	bool rconv=0;
	for(WORD w=0;w<len;w++)
	{
		if((buf+w)->id==GetId(symb))
		{
			if(GetId(symb)!=GetId("&"))//sort out '&'
			{
				if(C_Commands[GetLeft(buf+w-1)->id]->rtype==GetId("float")
					||C_Commands[GetRight(buf+w+1)->id]->rtype==GetId("float"))fl=1;
				if(fl)
				{
					if(C_Commands[GetLeft(buf+w-1)->id]->rtype!=GetId("float"))lconv=1;
					if(C_Commands[GetRight(buf+w+1)->id]->rtype!=GetId("float"))rconv=1;
					op=fcmp;
				}
				else
				{
					if(C_Commands[GetLeft(buf+w-1)->id]->rtype==GetId("float"))lconv=1;
					if(C_Commands[GetRight(buf+w+1)->id]->rtype==GetId("float"))rconv=1;
					op=vcmp;
				}
				if(C_Commands[GetLeft(buf+w-1)->id]->rtype==GetId("void"))
					C_CreateASMError("cannot combine void types",GetLeft(buf+w-1)->id);
				if(C_Commands[GetRight(buf+w+1)->id]->rtype==GetId("void"))
					C_CreateASMError("cannot combine void types",GetRight(buf+w+1)->id);
				bool fr=0;
				bool sr=0;
				if(!w)
				{
					C_CreateASMError("'symb' without lvalue found (a symb b is correct but 'a' was missing)",GetId("NULL"));
					SYS_Error("Fatal error.","");
				}
				
				if(GetLeft(buf+w-1)->id>=RegStart&&GetLeft(buf+w-1)->id<=RegEnd)
					fr=1;
				if(GetRight(buf+w+1)->id>=RegStart&&GetRight(buf+w+1)->id<=RegEnd)
					sr=1;

				DWORD fvr=GetLeft(buf+w-1)->id;

				if(!fr)
				{
					if(C_Commands[GetLeft(buf+w-1)->id]->Type!=TYPE_DEF)
						C_CreateASMError("arg1 of binary operation is no var",GetLeft(buf+w-1)->id);
					fvr=Regs+RegStart;
					P_RegLoadAdress(GetLeft(buf+w-1)->id);
					C_Commands[fvr]->rtype=C_Commands[GetLeft(buf+w-1)->id]->rtype;
					C_Commands[fvr]->ind=C_Commands[GetLeft(buf+w-1)->id]->ind;
					C_Commands[fvr]->parentf=GetLeft(buf+w-1)->id;
				}
				SolveSaveInd(fvr);
				if(lconv)
				{
					if(fl)
						ConvRegFromTo(fvr,C_Commands[fvr]->rtype,GetId("float"));
					else
						ConvRegFromTo(fvr,GetId("float"),C_Commands[fvr]->rtype);
				}
				if(sr)
				{
					SolveSaveInd(GetRight(buf+w+1)->id);
					if(rconv)
					{
						if(fl)
							ConvRegFromTo(GetRight(buf+w+1)->id,C_Commands[GetRight(buf+w+1)->id]->rtype,GetId("float"));
						else
							ConvRegFromTo(GetRight(buf+w+1)->id,GetId("float"),C_Commands[GetRight(buf+w+1)->id]->rtype);
					}
					P_Write(4,op,fvr-RegStart,rsep,GetRight(buf+w+1)->id-RegStart);
				}
				else 
				{
					if(C_Commands[GetRight(buf+w+1)->id]->Type!=TYPE_DEF)
						C_CreateASMError("arg2 of binary opertaion is no var",GetRight(buf+w+1)->id);
					if(!rconv)
					{
						DWORD d=GetRight(buf+w+1)->id;
						P_RegLoadAdress(d);
//						ExtFlag(Regs-1+RegStart);
						P_Write(6,op,fvr-RegStart,rsep,iopen,Regs-1,iclose);
						Regs--;
					}
					else
					{
						P_RegLoadAdress(GetLeft(buf+w-1)->id);
//						ExtFlag(Regs-1+RegStart);
						P_Write(6,vmov,Regs-1,rsep,iopen,Regs-1,iclose);
						C_Commands[Regs-1+RegStart]->parentf=GetLeft(buf+w-1)->id;
						C_Commands[Regs-1+RegStart]->rtype=C_Commands[GetLeft(buf+w-1)->id]->rtype;
						C_Commands[Regs-1+RegStart]->ind=C_Commands[GetLeft(buf+w-1)->id]->ind;
						if(rconv)
						{
							if(fl)
								ConvRegFromTo(Regs-1+RegStart,C_Commands[Regs-1+RegStart]->rtype,GetId("float"));
							else
								ConvRegFromTo(Regs-1+RegStart,GetId("float"),C_Commands[Regs-1+RegStart]->rtype);
						}
						P_Write(4,op,fvr-RegStart,rsep,Regs-1);					
						Regs--;
					}
				}
				GetLeft(buf+w-1)->tp=0;
				GetLeft(buf+w-1)->id=0;
				(buf+w)->id=fvr;
				(buf+w)->tp=TYPE_SGN;
				GetRight(buf+w+1)->tp=0;
				GetRight(buf+w+1)->id=0;
				w=0;
				LastReg=fvr;
				fpos_t mfp;
				fgetpos(targetf,&mfp);
				DWORD fp=mfp;
				P_Write(3,jmpt,cst,(fp+14*4));
				P_Write(5,vmov,fvr-RegStart,rsep,cst,(1));
				fgetpos(targetf,&mfp);
				fp=mfp;
				P_Write(3,vjmp,cst,(fp+10*4));
				P_Write(5,vmov,fvr-RegStart,rsep,cst,(0));
				C_Commands[fvr]->rtype=GetId("bool");
			}
		}
	}
	Warn_Conv=1;
	return LastReg;
} 

DWORD FindLogical(CCmd* buf,WORD len,char* symb)
{
	Warn_Conv=0;
	DWORD op;
	DWORD LastReg=0;
	if(!strcmp(symb,"&&"))
		op=vand;
	else if(!strcmp(symb,"||"))
		op=vor;
	for(WORD w=0;w<len;w++)
	{
		if((buf+w)->id==GetId(symb))
		{
			if(GetId(symb)!=GetId("&")||(w&&!LeadingOP(GetLeft(buf+w-1))))//sort out '&'
			{
				if(C_Commands[GetLeft(buf+w-1)->id]->rtype==GetId("void"))
					C_CreateASMError("cannot combine void types",GetLeft(buf+w-1)->id);
				if(C_Commands[GetRight(buf+w+1)->id]->rtype==GetId("void"))
					C_CreateASMError("cannot combine void types",GetRight(buf+w+1)->id);
				bool fr=0;
				bool sr=0;
				if(!w)
				{
					C_CreateASMError("'symb' without lvalue found (a symb b is correct but 'a' was missing)",GetId("NULL"));
					SYS_Error("Fatal error.","");
				}
				
				if(GetLeft(buf+w-1)->id>=RegStart&&GetLeft(buf+w-1)->id<=RegEnd)
					fr=1;
				if(GetRight(buf+w+1)->id>=RegStart&&GetRight(buf+w+1)->id<=RegEnd)
					sr=1;

				DWORD fvr=GetLeft(buf+w-1)->id;

				if(!fr)
				{
					if(C_Commands[GetLeft(buf+w-1)->id]->Type!=TYPE_DEF)
						C_CreateASMError("arg1 of binary operation is no var",GetLeft(buf+w-1)->id);
					fvr=Regs+RegStart;
					P_RegLoadAdress(GetLeft(buf+w-1)->id);
//					ExtFlag(fvr);
					P_Write(6,vmov,Regs-1,rsep,iopen,Regs-1,iclose);
					C_Commands[fvr]->rtype=C_Commands[GetLeft(buf+w-1)->id]->rtype;
					C_Commands[fvr]->ind=C_Commands[GetLeft(buf+w-1)->id]->ind;
					C_Commands[fvr]->parentf=GetLeft(buf+w-1)->id;
				}
				SolveSaveInd(fvr);
				if(C_Commands[fvr]->rtype!=GetId("bool"))
					ConvRegFromTo(fvr,C_Commands[fvr]->rtype,GetId("bool"));

				if(sr)
				{
					SolveSaveInd(GetRight(buf+w+1)->id);
					if(C_Commands[GetRight(buf+w+1)->id]->rtype!=GetId("bool"))
						ConvRegFromTo(GetRight(buf+w+1)->id,C_Commands[GetRight(buf+w+1)->id]->rtype,GetId("bool"));
					P_Write(4,op,fvr-RegStart,rsep,GetRight(buf+w+1)->id-RegStart);
				}
				else 
				{
					if(C_Commands[GetRight(buf+w+1)->id]->Type!=TYPE_DEF)
						C_CreateASMError("arg2 of binary opertaion is no var",GetRight(buf+w+1)->id);
					if(C_Commands[GetRight(buf+w+1)->id]->rtype==GetId("bool"))
					{
						DWORD d=GetRight(buf+w+1)->id;
						P_RegLoadAdress(d);
//						ExtFlag(Regs-1+RegStart);
						P_Write(6,op,fvr-RegStart,rsep,iopen,Regs-1,iclose);
						Regs--;
					}
					else
					{
						P_RegLoadAdress(GetLeft(buf+w-1)->id);
//						ExtFlag(Regs-1+RegStart);
						P_Write(6,vmov,Regs-1,rsep,iopen,Regs-1,iclose);
						C_Commands[Regs-1+RegStart]->parentf=GetLeft(buf+w-1)->id;
						C_Commands[Regs-1+RegStart]->rtype=C_Commands[GetLeft(buf+w-1)->id]->rtype;
						C_Commands[Regs-1+RegStart]->ind=C_Commands[GetLeft(buf+w-1)->id]->ind;
						ConvRegFromTo(Regs-1+RegStart,C_Commands[Regs-1+RegStart]->rtype,GetId("bool"));
						P_Write(4,op,fvr-RegStart,rsep,Regs-1);					
						Regs--;
					}
				}
				GetLeft(buf+w-1)->tp=0;
				GetLeft(buf+w-1)->id=0;
				(buf+w)->id=fvr;
				(buf+w)->tp=TYPE_SGN;
				GetRight(buf+w+1)->tp=0;
				GetRight(buf+w+1)->id=0;
				w=0;
				LastReg=fvr;
			}
		}
	}
	Warn_Conv=1;
	return LastReg;
} 

DWORD FindBinary(CCmd* buf,WORD len,char* symb)
{
	DWORD op;
	DWORD LastReg=0;
	if(!strcmp(symb,"&"))
		op=vand;
	else if(!strcmp(symb,"|"))
		op=vor;
	for(WORD w=0;w<len;w++)
	{
		if((buf+w)->id==GetId(symb))
		{
			if(GetId(symb)!=GetId("&")||(w&&!LeadingOP(GetLeft(buf+w-1))))//sort out '&'
			{
				if(C_Commands[GetLeft(buf+w-1)->id]->rtype==GetId("void"))
					C_CreateASMError("cannot combine void types",GetLeft(buf+w-1)->id);
				if(C_Commands[GetRight(buf+w+1)->id]->rtype==GetId("void"))
					C_CreateASMError("cannot combine void types",GetRight(buf+w+1)->id);
				bool fr=0;
				bool sr=0;
				if(!w)
				{
					C_CreateASMError("'symb' without lvalue found (a symb b is correct but 'a' was missing)",GetId("NULL"));
					SYS_Error("Fatal error.","");
				}
				
				if(GetLeft(buf+w-1)->id>=RegStart&&GetLeft(buf+w-1)->id<=RegEnd)
					fr=1;
				if(GetRight(buf+w+1)->id>=RegStart&&GetRight(buf+w+1)->id<=RegEnd)
					sr=1;

				DWORD fvr=GetLeft(buf+w-1)->id;

				if(!fr)
				{
					if(C_Commands[GetLeft(buf+w-1)->id]->Type!=TYPE_DEF)
						C_CreateASMError("arg1 of binary operation is no var",GetLeft(buf+w-1)->id);
					fvr=Regs+RegStart;
					P_RegLoadAdress(GetLeft(buf+w-1)->id);
//					ExtFlag(Regs-1+RegStart);
					P_Write(6,vmov,Regs-1,rsep,iopen,Regs-1,iclose);
					C_Commands[fvr]->rtype=C_Commands[GetLeft(buf+w-1)->id]->rtype;
					C_Commands[fvr]->ind=C_Commands[GetLeft(buf+w-1)->id]->ind;
					C_Commands[fvr]->parentf=GetLeft(buf+w-1)->id;
				}
				SolveSaveInd(fvr);
				if(C_Commands[fvr]->rtype==GetId("float"))
					FloatToType(fvr,GetId("DWORD"));
				
				if(sr)
				{
					SolveSaveInd(GetRight(buf+w+1)->id);
					if(C_Commands[GetRight(buf+w+1)->id]->rtype==GetId("float"))
						FloatToType(GetRight(buf+w+1)->id,C_Commands[GetRight(buf+w+1)->id]->rtype);
					P_Write(4,op,fvr-RegStart,rsep,GetRight(buf+w+1)->id-RegStart);
				}
				else 
				{
					if(C_Commands[GetRight(buf+w+1)->id]->Type!=TYPE_DEF)
						C_CreateASMError("arg2 of binary opertaion is no var",GetRight(buf+w+1)->id);
					if(C_Commands[GetRight(buf+w+1)->id]->rtype!=GetId("float"))
					{
						DWORD d=GetRight(buf+w+1)->id;
						P_RegLoadAdress(d);
//						ExtFlag(Regs-1+RegStart);
						P_Write(6,op,fvr-RegStart,rsep,iopen,Regs-1,iclose);
						Regs--;
					}
					else
					{
						P_RegLoadAdress(GetLeft(buf+w-1)->id);
//						ExtFlag(Regs-1+RegStart);
						P_Write(6,vmov,Regs-1,rsep,iopen,Regs-1,iclose);
						C_Commands[Regs-1+RegStart]->parentf=GetLeft(buf+w-1)->id;
						C_Commands[Regs-1+RegStart]->rtype=C_Commands[GetLeft(buf+w-1)->id]->rtype;
						C_Commands[Regs-1+RegStart]->ind=C_Commands[GetLeft(buf+w-1)->id]->ind;
						FloatToType(Regs-1+RegStart,GetId("DWORD"));
						P_Write(4,op,fvr-RegStart,rsep,Regs-1);					
						Regs--;
					}
				}
				GetLeft(buf+w-1)->tp=0;
				GetLeft(buf+w-1)->id=0;
				(buf+w)->id=fvr;
				(buf+w)->tp=TYPE_SGN;
				GetRight(buf+w+1)->tp=0;
				GetRight(buf+w+1)->id=0;
				w=0;
				LastReg=fvr;
			}
		}
	}
	return LastReg;
} 


DWORD Find(CCmd* buf,WORD len,char* symb)
{
	DWORD op;
	DWORD LastReg=0;
	bool conv=0;
	for(WORD w=0;w<len;w++)
	{
		if((buf+w)->id==GetId(symb))
		{
			if(GetId(symb)!=GetId("*")||(w&&!LeadingOP(GetLeft(buf+w-1))))//sort out indirection
			{
				if((C_Commands[GetLeft(buf+w-1)->id]->rtype!=GetId("float")
					&&C_Commands[GetRight(buf+w+1)->id]->rtype!=GetId("float"))
					||(C_Commands[GetRight(buf+w+1)->id]->ind
					||C_Commands[GetLeft(buf+w-1)->id]->ind))
				{
					if(!strcmp(symb,"*"))
						op=vmul;
					else if(!strcmp(symb,"/"))
						op=vdiv;
					else if(!strcmp(symb,"+"))
						op=vadd;
					else if(!strcmp(symb,"-"))
						op=vsub;
				}
				else
				{
					if(!strcmp(symb,"*"))
						op=fmul;
					else if(!strcmp(symb,"/"))
						op=fdiv;
					else if(!strcmp(symb,"+"))
						op=fadd;
					else if(!strcmp(symb,"-"))
						op=fsub;
					conv=1;
				}
				if(C_Commands[GetLeft(buf+w-1)->id]->rtype==GetId("void"))
					C_CreateASMError("cannot combine void types",GetLeft(buf+w-1)->id);
				if(C_Commands[GetRight(buf+w+1)->id]->rtype==GetId("void"))
					C_CreateASMError("cannot combine void types",GetRight(buf+w+1)->id);
				bool fr=0;
				bool sr=0;
				if(!w)
				{
					C_CreateASMError("'symb' without lvalue found (a symb b is correct but 'a' was missing)",GetId("NULL"));
					SYS_Error("Fatal error.","");
				}
				
				if(GetLeft(buf+w-1)->id>=RegStart&&GetLeft(buf+w-1)->id<=RegEnd)
					fr=1;
				if(GetRight(buf+w+1)->id>=RegStart&&GetRight(buf+w+1)->id<=RegEnd)
					sr=1;

				DWORD fvr=GetLeft(buf+w-1)->id;

				if(!fr)
				{
					if(C_Commands[GetLeft(buf+w-1)->id]->Type!=TYPE_DEF)
						C_CreateASMError("arg1 of operation is no var",GetLeft(buf+w-1)->id);
					fvr=Regs+RegStart;
					P_RegLoadAdress(GetLeft(buf+w-1)->id);
					P_Write(6,vmov,Regs-1,rsep,iopen,Regs-1,iclose);
					C_Commands[fvr]->rtype=C_Commands[GetLeft(buf+w-1)->id]->rtype;
					C_Commands[fvr]->ind=C_Commands[GetLeft(buf+w-1)->id]->ind;
					C_Commands[fvr]->parentf=GetLeft(buf+w-1)->id;
				}
				SolveSaveInd(fvr);
				if(C_Commands[fvr]->rtype!=GetId("float")&&conv)
					ConvToFloat(fvr,C_Commands[fvr]->rtype);
				if(sr)
				{
					SolveSaveInd(GetRight(buf+w+1)->id);
					if(C_Commands[GetRight(buf+w+1)->id]->rtype!=GetId("float")&&conv)
						ConvToFloat(GetRight(buf+w+1)->id,C_Commands[GetRight(buf+w+1)->id]->rtype);
					if(C_Commands[fvr]->ind&&C_Commands[GetRight(buf+w+1)->id]->parentf==GetId("const"))
						P_Write(5,vmul,GetRight(buf+w+1)->id-RegStart,rsep,cst,C_Commands[C_Commands[fvr]->rtype]->frame);
					if(C_Commands[GetRight(buf+w+1)->id]->ind&&C_Commands[fvr]->parentf==GetId("const"))
						P_Write(5,vmul,fvr-RegStart,rsep,cst,C_Commands[C_Commands[GetRight(buf+w+1)->id]->rtype]->frame);
					P_Write(4,op,fvr-RegStart,rsep,GetRight(buf+w+1)->id-RegStart);
				}
				else 
				{
					if(C_Commands[GetRight(buf+w+1)->id]->Type!=TYPE_DEF)
						C_CreateASMError("arg2 of operation is no var",GetRight(buf+w+1)->id);
					if(C_Commands[GetRight(buf+w+1)->id]->rtype==GetId("float")&&!C_Commands[GetRight(buf+w+1)->id]->ind)
					{
						DWORD d=GetRight(buf+w+1)->id;
						P_RegLoadAdress(d);
						if(C_Commands[fvr]->ind&&C_Commands[GetRight(buf+w+1)->id]->parentf==GetId("const"))
							P_Write(5,vmul,GetRight(buf+w+1)->id-RegStart,rsep,cst,C_Commands[C_Commands[fvr]->rtype]->frame);
//						ExtFlag(Regs-1+RegStart);
						P_Write(6,op,fvr-RegStart,rsep,iopen,Regs-1,iclose);
						Regs--;
					}
					else
					{
						P_RegLoadAdress(GetLeft(buf+w-1)->id);
//						ExtFlag(Regs-1+RegStart);
						P_Write(6,vmov,Regs-1,rsep,iopen,Regs-1,iclose);
						C_Commands[Regs-1+RegStart]->parentf=GetLeft(buf+w-1)->id;
						C_Commands[Regs-1+RegStart]->rtype=C_Commands[GetLeft(buf+w-1)->id]->rtype;
						C_Commands[Regs-1+RegStart]->ind=C_Commands[GetLeft(buf+w-1)->id]->ind;
						if(C_Commands[fvr]->ind&&C_Commands[Regs-1+RegStart]->parentf==GetId("const"))
							P_Write(5,vmul,Regs-1,rsep,cst,C_Commands[C_Commands[fvr]->rtype]->frame);
						if(C_Commands[Regs-1+RegStart]->ind&&C_Commands[fvr]->parentf==GetId("const"))
							P_Write(5,vmul,fvr-RegStart,rsep,cst,C_Commands[C_Commands[Regs-1+RegStart]->rtype]->frame);
						if(conv)ConvToFloat(Regs-1+RegStart,C_Commands[GetRight(buf+w+1)->id]->rtype);
						P_Write(4,op,fvr-RegStart,rsep,Regs-1);
						Regs--;
					}
				}
				GetLeft(buf+w-1)->tp=0;
				GetLeft(buf+w-1)->id=0;
				(buf+w)->id=fvr;
				(buf+w)->tp=TYPE_SGN;
				GetRight(buf+w+1)->tp=0;
				GetRight(buf+w+1)->id=0;
				w=0;
				LastReg=fvr;
			}
		}
	}
	return LastReg;
} 

DWORD FindCast(CCmd* buf,WORD len)
{
	Warn_Conv=0;
	DWORD LastReg=0;
	for(WORD w=0;w<len-1;w++)
	{
		if((buf+w)->id==GetId("}")&&
			(GetRight(buf+w+1)->tp==TYPE_DEF||(GetRight(buf+w+1)->id>=RegStart&&GetRight(buf+w+1)->id<=RegEnd)))
		{
			DWORD id=GetRight(buf+w+1)->id;
			LastReg=id;
			//solveable cast
			SolveSaveInd(id);
			if(GetRight(buf+w+1)->tp==TYPE_DEF)
			{
				P_RegLoadAdress(id);
				P_Write(6,vmov,Regs-1,rsep,iopen,Regs-1,iclose);
				C_Commands[Regs-1+RegStart]->rtype=C_Commands[id]->rtype;
				C_Commands[Regs-1+RegStart]->ind=C_Commands[id]->ind;
				C_Commands[Regs-1+RegStart]->parentf=id;
				id=Regs-1+RegStart;
				GetRight(buf+w+1)->id=id;
				GetRight(buf+w+1)->tp=TYPE_SGN;
				LastReg=id;
			}
				CCmd* mb=(buf+w);
				WORD ind=0;
				while(mb->tp!=TYPE_VAR)
				{
					mb--;
					ind++;
					if(mb<buf)
					{
						C_CreateError("Syntax error");
						return 0;
					}
				}
				ind--;
				if(!ind&&C_Commands[id]->rtype!=mb->id)
				{
					if(C_Commands[id]->rtype==GetId("float"))
						FloatToType(id,mb->id);
					else if(mb->id==GetId("float"))
						ConvToFloat(id,C_Commands[id]->rtype);
					else
					{
						ConvToFloat(id,C_Commands[id]->rtype);
						FloatToType(id,mb->id);
					}
				}
				C_Commands[id]->ind=ind;
				C_Commands[id]->rtype=mb->id;
				mb--;
				CCmd* mmb=mb;
				WORD len=0;
				while(mb->id!=GetId("}"))
				{
					mb++;
					len++;
				}
				memset(mmb,0,sizeof(CCmd)*(len+1));
		}
	}
	if((buf+len-1)->id==GetId("}"))
		C_CreateASMError("cast not followed by castable expression",GetId("NULL"));
	Warn_Conv=1;
	return LastReg;
}

DWORD FindUnary(CCmd* buf,WORD len,char* symb)
{
	DWORD LastReg=0;
	for(WORD w=0;w<len;w++)
	{
		if((buf+w)->id==GetId(symb)&&
			(GetRight(buf+w+1)->tp==TYPE_DEF||(GetRight(buf+w+1)->id>=RegStart&&GetRight(buf+w+1)->id<=RegEnd)))
		{
			if((GetId(symb)!=GetId("*")&&GetId(symb)!=GetId("&"))||(!w||LeadingOP(GetLeft(buf+w-1))))
			{
				if(C_Commands[GetRight(buf+w+1)->id]->rtype==GetId("void"))
					C_CreateASMError("cannot combine void types",GetRight(buf+w+1)->id);
				DWORD id=GetRight(buf+w+1)->id;
				LastReg=id;
				//solveable cast
				SolveSaveInd(id);
				if(GetRight(buf+w+1)->tp==TYPE_DEF)
				{
					if(GetId(symb)!=GetId("&"))
					{
						P_RegLoadAdress(id);
						P_Write(6,vmov,Regs-1,rsep,iopen,Regs-1,iclose);
					}
					else
					{
						P_RegLoadAdress(id);
						C_Commands[id]->save_ind=0;
					}

					C_Commands[Regs-1+RegStart]->rtype=C_Commands[id]->rtype;
					C_Commands[Regs-1+RegStart]->parentf=id;
					C_Commands[Regs-1+RegStart]->ind=C_Commands[id]->ind;
					id=Regs-1+RegStart;
					GetRight(buf+w+1)->id=id;
					GetRight(buf+w+1)->tp=TYPE_SGN;
					LastReg=id;
				}
				if(GetId(symb)==GetId("*"))
				{
					if(!C_Commands[id]->ind)
						C_CreateASMError("invalid indirection",id);
//					if(C_Commands[id]->rtype!=GetId("float"))
//						ConvToFloat(id,C_Commands[id]->rtype);
					C_Commands[id]->ind--;
				//	P_Write(6,vmov,id-RegStart,rsep,iopen,id-RegStart,iclose);
					C_Commands[id]->save_ind=1;
				}
				else if(GetId(symb)==GetId("!"))
				{
					if(C_Commands[id]->rtype==GetId("float"))
						FloatToType(id,GetId("DWORD"));
					P_Write(2,vnot,id-RegStart);
				}
				else if(GetId(symb)==GetId("&"))
				{
					C_Commands[id]->ind++;
				}
				(buf+w)->id=0;
				(buf+w)->tp=0;
			}
		}
	}
	if((buf+len-1)->id==GetId(symb))
		C_CreateASMError("cast not followed by castable expression",GetId("NULL"));
	return LastReg;
}

DWORD FindRUnary(CCmd* buf,WORD len,char* symb)
{
	DWORD op;
	DWORD LastReg=0;
	bool conv=0;
	for(WORD w=0;w<len;w++)
	{
		if((buf+w)->id==GetId(symb))
		{
				if(C_Commands[GetLeft(buf+w-1)->id]->rtype!=GetId("float"))
				{
					if(!strcmp(symb,"++"))
						op=inc;
					else if(!strcmp(symb,"--"))
						op=dec;
				}
				else
				{
					if(!strcmp(symb,"++"))
						op=finc;
					else if(!strcmp(symb,"--"))
						op=fdec;
					conv=1;
				}
				if(C_Commands[GetLeft(buf+w-1)->id]->rtype==GetId("void"))
					C_CreateASMError("cannot combine void types",GetLeft(buf+w-1)->id);
				bool fr=0;
				if(!w)
				{
					C_CreateASMError("'symb' without lvalue found (a symb b is correct but 'a' was missing)",GetId("NULL"));
					SYS_Error("Fatal error.","");
				}
				
				if(GetLeft(buf+w-1)->id>=RegStart&&GetLeft(buf+w-1)->id<=RegEnd)
					fr=1;

				DWORD fvr=GetLeft(buf+w-1)->id;

				if(!fr)
				{
					if(C_Commands[GetLeft(buf+w-1)->id]->Type!=TYPE_DEF)
						C_CreateASMError("arg1 of operation is no var",GetLeft(buf+w-1)->id);
					fvr=Regs+RegStart;
					P_RegLoadAdress(GetLeft(buf+w-1)->id);
//					ExtFlag(Regs-1+RegStart);
//					P_Write(6,vmov,Regs-1,rsep,iopen,Regs-1,iclose);
					C_Commands[fvr]->rtype=C_Commands[GetLeft(buf+w-1)->id]->rtype;
					C_Commands[fvr]->ind=C_Commands[GetLeft(buf+w-1)->id]->ind+1;
					C_Commands[fvr]->parentf=GetLeft(buf+w-1)->id;
				}
				if(C_Commands[fvr]->rtype!=GetId("float")&&conv)
					ConvToFloat(fvr,C_Commands[fvr]->rtype);
//				ExtFlag(fvr);
				P_Write(4,op,iopen,fvr-RegStart,iclose);

				GetLeft(buf+w-1)->tp=0;
				GetLeft(buf+w-1)->id=0;
				(buf+w)->id=fvr;
				(buf+w)->tp=TYPE_SGN;
				w=0;
				LastReg=fvr;
			
		}
	}
	return LastReg;
} 

DWORD BackMul(DWORD* array,DWORD len,DWORD id)
{
	Regs+=3;
//	len--;
	if(len>1)
		P_Write(5,vmov,Regs-1,rsep,cst,1);
	P_Write(4,vmov,Regs-3,rsep,(*array)-RegStart);
	for(long d=1;d<len;d++)
	{
		P_Write(5,vmul,Regs-1,rsep,cst,*(C_Commands[id]->args+d-1));
		P_Write(4,vmov,Regs-2,rsep,*(array+d)-RegStart);
		P_Write(4,vmul,Regs-2,rsep,Regs-1);
		P_Write(4,vadd,Regs-3,rsep,Regs-2);
	}
	Regs-=2;
	return Regs-1+RegStart;
}

DWORD FindArray(CCmd* buf,WORD len)
{
	DWORD LastReg=0;
	for(WORD w=0;w<len;w++)
	{
		if((buf+w)->id==GetId("["))
		{
			CCmd* mb=(buf+w);
			DWORD id=GetLeft(buf+w-1)->id;
			if(!C_Commands[id]->Type==TYPE_DEF)
				C_CreateASMError("no var for indexing '[]'",id);
			DWORD dims=C_Commands[id]->nargs;
			DWORD* regs=(DWORD*)malloc(sizeof(DWORD)*C_Commands[id]->array_depth);
			DWORD signs=0;
			CCmd* ob=(buf+w);
			while(ob->id==GetId("["))//gather indexes
			{
				ob=GetRight(ob+1);
				if(!(ob->id>=RegStart&&ob->id<=RegEnd))
					C_CreateASMError("invalid index",(buf+w)->id);
				SolveSaveInd(ob->id);
				if(signs>=C_Commands[id]->array_depth)
				{
					C_CreateError("invalid index (too many dimensions)");
					break;
				}
				*(regs+signs)=ob->id;
				ob=GetRight(ob+1);
				if(ob->id!=GetId("]"))
					C_CreateError("missing ']'");
				ob=GetRight(ob+1);
				signs++;
			}
			ob=GetLeft(ob-1);
			w=ob-buf+1;
			DWORD reg=BackMul(regs,signs,id);
			memset(mb,0,sizeof(CCmd)*((buf+w)-mb));
			if(C_Commands[C_Commands[id]->rtype]->frame>1)
				P_Write(5,vmul,reg-RegStart,rsep,cst,C_Commands[C_Commands[id]->rtype]->frame);
			P_RegLoadAdress(id);
			P_Write(4,vadd,reg-RegStart,rsep,Regs-1);
			Regs--;
			C_Commands[reg]->rtype=C_Commands[id]->rtype;
			C_Commands[reg]->ind=C_Commands[id]->ind;
			C_Commands[reg]->parentf=id;
//			if(signs=C_Commands[id]->ind)
				C_Commands[reg]->save_ind=1;
//			else
//				C_Commands[reg]->save_ind=0;
			mb=GetLeft(mb-1);
			mb->id=reg;
			mb->tp=TYPE_SGN;
			free(regs);
			LastReg=reg;
		}
	}
	return LastReg;
}

void FindBraket(CCmd* db,WORD len,CCmd** mb,WORD *mlen)
{
	for(WORD w=0;w<len;w++)
	{
		if((db+w)->id==GetId("("))
		{
			*mb=(db+w+1);
			WORD actb=1;
			*mlen=0;
			while(w<len)
			{
				w++;
				if((db+w)->id==GetId("("))
					actb++;
				else if((db+w)->id==GetId(")"))
					actb--;
				if(!actb)
					return;
				(*mlen)++;
			}
			C_CreateASMError("Missing ')'",GetId("NULL"));
		}
	}
	*mb=db;
	*mlen=0;
}

DWORD FindStruct(CCmd* buf,WORD len)
{
	DWORD LastReg=0;
	for(WORD w=0;w<len;w++)
	{
		if((buf+w)->id==GetId(".")||(buf+w)->id==GetId("->"))
		{
			if(GetLeft(buf+w-1)->tp==TYPE_DEF)
			{
				if(C_Commands[GetRight(buf+w+1)->id]->parentf!=C_Commands[GetLeft(buf+w-1)->id]->rtype)
				{
					C_CreateASMError("Identifer is no member of struct",GetRight(buf+w+1)->id);
					break;
				}
				P_RegLoadAdress(GetLeft(buf+w-1)->id);
				C_Commands[Regs-1+RegStart]->ind=C_Commands[GetRight(buf+w+1)->id]->ind;
				C_Commands[Regs-1+RegStart]->rtype=C_Commands[GetRight(buf+w+1)->id]->rtype;
				C_Commands[Regs-1+RegStart]->parentf=GetRight(buf+w+1)->id;
				C_Commands[Regs-1+RegStart]->save_ind=1;
			}
			if(C_Commands[GetLeft(buf+w-1)->id]->ind)
			{
				if((buf+w)->id==GetId("."))
					C_CreateError("use '->' to access stuct members when using pointers");
				SolveSaveInd(GetLeft(buf+w-1)->id);
			}
			else if((buf+w)->id==GetId("->"))
				C_CreateError("use '.' to access stuct members when not using pointers");
			C_Commands[Regs-1+RegStart]->ind=C_Commands[GetRight(buf+w+1)->id]->ind;
			C_Commands[Regs-1+RegStart]->rtype=C_Commands[GetRight(buf+w+1)->id]->rtype;
			C_Commands[Regs-1+RegStart]->parentf=GetRight(buf+w+1)->id;
			C_Commands[Regs-1+RegStart]->save_ind=1;

			P_Write(5,vadd,Regs-1,rsep,cst,C_Commands[GetRight(buf+w+1)->id]->argid);
			LastReg=Regs-1+RegStart;			
			GetLeft(buf+w-1)->tp=0;
			GetLeft(buf+w-1)->id=0;
			GetRight(buf+w+1)->tp=0;
			GetRight(buf+w+1)->id=0;
			(buf+w)->id=LastReg;
			(buf+w)->tp=TYPE_SGN;
		}
	}
	return LastReg;
}

void FreeRegs(CCmd* db,WORD len)//free unused regs
{
	DWORD max_reg=0;
	for(WORD w=0;w<len;w++)
	{
		if((db+w)->id>=RegStart&&(db+w)->id<=RegEnd&&(db+w)->id>max_reg)
			max_reg=(db+w)->id;
	}
	if(Regs<=RegEnd&&max_reg)
	{
		for(w=max_reg+1;w<Regs+RegStart;w++)
		{
			C_Commands[w]->ind=0;
			C_Commands[w]->rtype=0;
			C_Commands[w]->parentf=0;
			C_Commands[w]->save_ind=0;
			C_Commands[w]->ext=0;
		}
		Regs-=Regs+RegStart-(max_reg+1);
	}
}

void ClearRegs()
{
	for(int i=RegStart;i<=RegEnd;i++)
	{
		C_Commands[i]->ind=0;
		C_Commands[i]->rtype=0;
		C_Commands[i]->parentf=0;
		C_Commands[i]->save_ind=0;
		C_Commands[i]->ext=0;
	}
}

DWORD SolveExpression(CCmd* db,WORD len)
{
	CCmd* mb;
	WORD mlen=1;
	DWORD LastReg=0;
	DWORD ret=0;
	while(mlen)
	{
		if(Regs>num_regs-1)
			C_CreateASMError("Not enough registers to solve problem",GetId("NULL"));
		FindBraket(db,len,&mb,&mlen);
		if(mlen)
		{
			ret=SolveExpression(mb,mlen);
			if(ret)LastReg=ret;
			(mb-1)->id=0;
			(mb-1)->tp=0;
			(mb+mlen)->id=0;
			(mb+mlen)->tp=0;
		}
		FreeRegs(Line,LineLen);
	}

	ret=FindArray(db,len);
	if(ret)LastReg=ret;
	ret=FindStruct(db,len);
	if(ret)LastReg=ret;
	FreeRegs(Line,LineLen);
	ret=FindUnary(db,len,"&");
	if(ret)LastReg=ret;
	ret=FindCast(db,len);
	if(ret)LastReg=ret;
	ret=FindUnary(db,len,"*");
	if(ret)LastReg=ret;
	ret=FindUnary(db,len,"!");
	if(ret)LastReg=ret;
	ret=FindBinary(db,len,"&");
	if(ret)LastReg=ret;
	ret=FindBinary(db,len,"|");
	if(ret)LastReg=ret;
	ret=Find(db,len,"*");
	if(ret)LastReg=ret;
	ret=Find(db,len,"/");
	if(ret)LastReg=ret;
	ret=Find(db,len,"+");
	if(ret)LastReg=ret;
	ret=Find(db,len,"-");
	if(ret)LastReg=ret;
	ret=FindRUnary(db,len,"++");
	if(ret)LastReg=ret;
	ret=FindRUnary(db,len,"--");
	if(ret)LastReg=ret;
	ret=FindLogic(db,len,"==");
	if(ret)LastReg=ret;
	ret=FindLogic(db,len,"!=");
	if(ret)LastReg=ret;
	ret=FindLogic(db,len,">=");
	if(ret)LastReg=ret;
	ret=FindLogic(db,len,"<=");
	if(ret)LastReg=ret;
	ret=FindLogic(db,len,">");
	if(ret)LastReg=ret;
	ret=FindLogic(db,len,"<");
	if(ret)LastReg=ret;
	ret=FindLogical(db,len,"&&");
	if(ret)LastReg=ret;
	ret=FindLogical(db,len,"||");
	if(ret)LastReg=ret;
	return LastReg;
}

void FindArg(CCmd* db,WORD len,CCmd** mb,WORD *mlen)
{
	*mb=db;
	*(mlen)=0;
	for(WORD w=0;w<len;w++)
	{
		if((db+w)->id==GetId(",")||w>=len)
			return;
		(*mlen)++;
	}
	(*mlen)=len;
}

DWORD CompressLine(CCmd* Line,WORD LineLen)//remove constants
{
	DWORD LastReg=0;
	float mynumber=0;
	for(WORD w=0;w<LineLen;w++)
	{
		if(Regs>num_regs-1)
			C_CreateASMError("Not enough registers to solve problem",GetId("NULL"));
		//eliminate numbers(constants)
		if((Line+w)->id>=GetId("0")&&(Line+w)->id<=GetId("9"))
		{
			FL=Line+w;
			WORD len=LineLen-w;
			mynumber=GetNumberfl(1,0,&len);
			Regs++;
			(Line+w)->id=RegStart+Regs-1;
			(Line+w)->tp=TYPE_SGN;
			DWORD mw=w;
			w++;
			bool broken=0;
			while(w<LineLen&&((Line+w)->id>=GetId("0")&&(Line+w)->id<=GetId("9"))||(Line+w)->id==GetId("."))
			{
				if((Line+w)->id==GetId("."))
					broken=1;
				(Line+w)->id=0;
				(Line+w)->tp=0;
				w++;
			}
			if(broken)
			{
				P_Write(5,vmov,Regs-1,rsep,cst,FtoD(mynumber));
				C_Commands[(Line+mw)->id]->rtype=GetId("float");
			}
			else
			{
				DWORD mn=mynumber;
				P_Write(5,vmov,Regs-1,rsep,cst,mn);
				C_Commands[(Line+mw)->id]->rtype=GetId("DWORD");
			}
			C_Commands[(Line+mw)->id]->ind=0;
			C_Commands[(Line+mw)->id]->parentf=GetId("const");
			C_Commands[(Line+mw)->id]->save_ind=0;
			C_Commands[(Line+mw)->id]->ext=0;

			w=0;
			LastReg=RegStart+Regs-1;
		}
		else if((Line+w)->tp==TYPE_CMD)//call func and replace in line
		{
			CCmd* mb=NULL;
			WORD len=0;
			bool noclear=0;
			if(GetRight(Line+w+1)->id==GetId("("))
				FindBraket((Line+w),LineLen-w,&mb,&len);
			else noclear=1;
			DWORD reg=FuncCall(mb,len,(Line+w)->id);

			if(!reg)
				C_CreateASMError("failed to solve expression",GetId("NULL"));
			if(!noclear)
				memset(mb-2,0,sizeof(CCmd)*(len+3));//clear;
			(Line+w)->id=reg;
			(Line+w)->tp=TYPE_SGN;
			LastReg=reg;
		}
		else if((Line+w)->id==GetId("sizeof"))//replace sizeof
		{
			if((Line+w+1)->id!=GetId("(")
				||(Line+w+2)->tp!=TYPE_VAR
				||(Line+w+3)->id!=GetId(")"))
			{
				C_CreateError("syntax error in sizeof function");
			}
			else
			{
				DWORD id=(Line+w+2)->id;
				Regs++;
				P_Write(5,vmov,Regs-1,rsep,cst,(C_Commands[id]->frame));
				(Line+w)->id=RegStart+Regs-1;
				(Line+w)->tp=TYPE_SGN;
				C_Commands[(Line+w)->id]->rtype=GetId("DWORD");
				C_Commands[(Line+w)->id]->ind=0;
				C_Commands[(Line+w)->id]->ext=0;
				C_Commands[(Line+w)->id]->parentf=GetId("const");
				LastReg=RegStart+Regs-1;
				(Line+w+1)->id=0;
				(Line+w+1)->tp=0;
				(Line+w+2)->id=0;
				(Line+w+2)->tp=0;
				(Line+w+3)->id=0;
				(Line+w+3)->tp=0;
			}
		}
		else if((Line+w)->tp==TYPE_VAR)//replace (cast**) with {cast@@}
		{
			if(GetLeft(Line+w-1)->id==GetId("("))
			{
				GetLeft(Line+w-1)->id=GetId("{");
				while(w<LineLen)
				{
					w++;
					if((Line+w)->id==GetId(")"))
					{
						(Line+w)->id=GetId("}");
						break;
					}
					if((Line+w)->id!=GetId("*"))
						C_CreateASMError("syntax error in cast",(Line+w)->id);
					(Line+w)->id=GetId("@");
				}
			}
			else if(GetLeft(Line+w-1)->id!=GetId("{"))
				C_CreateASMError("missing '(' before cast '(cast)' is correct",GetId("NULL"));
		}
		else if((Line+w)->id==GetId("["))//solve [x]
		{
			DWORD len=0;
			w++;
			CCmd* mb=(Line+w);
			while((Line+w)->id!=GetId("]"))
			{
				w++;
				len++;
				if(w>LineLen)
				{
					C_CreateError("missing ']'");
					break;
				}
			}
			DWORD reg=BuildLine(mb,len);
			memset(mb,0,sizeof(CCmd)*len);
			mb->id=reg;
			mb->tp=TYPE_SGN;
			if(C_Commands[reg]->rtype==GetId("float"))
				FloatToType(reg,GetId("DWORD"));
		}
	}
	return LastReg;
}

DWORD BuildLine(CCmd* db,WORD len)
{
	DWORD regs=Regs;
	DWORD ret=CompressLine(db,len);
	DWORD mret=SolveExpression(db,len);
	if(mret)ret=mret;
	Regs=regs;
	if(ret)
	{
		Regs++;
		if(ret!=Regs-1+RegStart)
		{
			P_Write(4,vmov,Regs-1,rsep,ret-RegStart);
			C_Commands[Regs-1+RegStart]->ind=C_Commands[ret]->ind;
			C_Commands[Regs-1+RegStart]->rtype=C_Commands[ret]->rtype;
			C_Commands[Regs-1+RegStart]->parentf=C_Commands[ret]->parentf;
			C_Commands[Regs-1+RegStart]->save_ind=C_Commands[ret]->save_ind;
			C_Commands[Regs-1+RegStart]->ext=C_Commands[ret]->ext;
			ret=Regs-1+RegStart;
		}
	}
	WORD num_left=0;
	DWORD last_id=0;
	for(DWORD d=0;d<len;d++)
	{
		if((db+d)->id)
		{
			num_left++;
			last_id=(db+d)->id;
		}
	}
	if((num_left&&!(last_id>=RegStart&&last_id<=RegEnd)))
	{
		if(C_Commands[last_id]->Type!=TYPE_DEF||num_left>1||ret||num_left>1)
			C_CreateASMError("syntax error",last_id);
		else 
		{
			P_RegLoadAdress(last_id);
//			if(!C_Commands[last_id]->nargs)
			C_Commands[Regs-1+RegStart]->save_ind=1;
//			else
//				C_Commands[Regs-1+RegStart]->save_ind=0;
			C_Commands[Regs-1+RegStart]->rtype=C_Commands[last_id]->rtype;
			C_Commands[Regs-1+RegStart]->ind=C_Commands[last_id]->ind;
			C_Commands[Regs-1+RegStart]->parentf=last_id;			
			ret=Regs-1+RegStart;
		}
	}
	else if(num_left>1)
		C_CreateASMError("syntax error",last_id);
	else if(!ret)ret=last_id;

	return ret;
}

struct tp_ind
{
	SHORT tp;
	WORD ind;
};

struct saverstr
{
	WORD ind;
	int rtype;
	DWORD parentf;
	bool save_ind;
	bool ext;
};

saverstr SavedRegs[28];

DWORD RegsSaved=0;
void SaveRegs()
{
	P_Write(5,pushn,0,rsep,cst,(Regs+1));
	RegsSaved=Regs;
	for(DWORD d=0;d<Regs+1;d++)
	{
		SavedRegs[d].ext=C_Commands[RegStart+d]->ext;
		SavedRegs[d].ind=C_Commands[RegStart+d]->ind;
		SavedRegs[d].save_ind=C_Commands[RegStart+d]->save_ind;
		SavedRegs[d].parentf=C_Commands[RegStart+d]->parentf;
		SavedRegs[d].rtype=C_Commands[RegStart+d]->rtype;
	}
	Regs=1;
}

void RestoreRegs()
{
	P_Write(5,vpop,0,rsep,cst,(RegsSaved+1));
	Regs=RegsSaved;
	for(DWORD d=0;d<RegsSaved+1;d++)
	{
		C_Commands[RegStart+d]->ext=SavedRegs[d].ext;
		C_Commands[RegStart+d]->ind=SavedRegs[d].ind;
		C_Commands[RegStart+d]->save_ind=SavedRegs[d].save_ind;
		C_Commands[RegStart+d]->parentf=SavedRegs[d].parentf;
		C_Commands[RegStart+d]->rtype=SavedRegs[d].rtype;
	}
	RegsSaved=0;
}

DWORD FuncCall(CCmd* db,WORD len,DWORD fid)
{
	if(db)
	{
		SaveRegs();
		DWORD rsaved=RegsSaved+1;
		DWORD nargs=0;
		char stuff[255]="";
		for(DWORD d=0;d<C_Commands[fid]->nargs;d++)
		{
			if(*(C_Commands[fid]->args+d)!=GetId("*"))
			{
				sprintf(stuff,"%s%s",stuff,C_Commands[C_Commands[*(C_Commands[fid]->args+d)]->rtype]->CName);
				sprintf(stuff,"%s,",stuff);
				nargs++;
			}
			else sprintf(stuff,"%s*",stuff);
		}
		stuff[strlen(stuff)-1]=0;
		tp_ind *ti=(tp_ind*)malloc(sizeof(tp_ind)*nargs);
		int ind=0;
		DWORD na2=0;
		for(d=0;d<C_Commands[fid]->nargs;d++)
		{
			if(*(C_Commands[fid]->args+d)!=GetId("*"))
			{
				ti[na2].ind=ind;
				ti[na2].tp=C_Commands[*(C_Commands[fid]->args+d)]->rtype;
				na2++;
				ind=-1;
			}
			ind++;			
		}
		DWORD r_args=0;
//		for(d=0;d<nargs;d++)
		DWORD loc_d=0;
		if(C_Commands[fid]->nargs)
		{
			while(len!=65535)
			{
				CCmd* mb=NULL;
				WORD mlen=0;
				FindArg(db,len,&mb,&mlen);
				r_args++;
				if(!mlen)
				{
					C_CreateError("missing argument");
					return 0;
				}
				db+=mlen+1;
				len-=mlen+1;
				DWORD reg=BuildLine(mb,mlen);
				SolveSaveInd(reg);
				if(!reg)
					C_CreateASMError("failed to solve expression",GetId("NULL"));
				if(loc_d<nargs)
				{
					if((C_Commands[reg]->rtype!=ti[loc_d].tp&&ti[loc_d].tp!=GetId("?"))||(C_Commands[reg]->ind!=ti[loc_d].ind&&ti[loc_d].tp!=GetId("?")))
					{
						char ind1[255]="";
						for(DWORD i=0;i<ti[loc_d].ind;i++)
							ind1[i]='*';
						char ind2[255]="";
						for(i=0;i<C_Commands[reg]->ind;i++)
							ind2[i]='*';
						char str[255]="";
						sprintf(str,"Function %s(%s); \n Cannot cast argument #%d from (%s%s) to (%s%s). Explicit cast needed."
							,C_Commands[fid]->CName,stuff,loc_d,
							ind2,C_Commands[C_Commands[reg]->rtype]->CName,
							ind1,C_Commands[ti[loc_d].tp]->CName);
						C_CreateASMError(str,reg);
					}
				}
		//indirection check!!
				P_Write(2,vpush,reg-RegStart);//push one reg
				Regs--;
				loc_d++;
			}
			Regs++;
			if(r_args!=nargs&&ti[nargs-1].tp!=GetId("?"))
				C_CreateError("too many arguments");
		}
//		P_Write(5,pushn,vvip,rsep,cst,(1));
		ExtFlag(fid);
		P_Write(3,vcall,cst,C_Commands[fid]->FPOS);
		if(!C_Commands[fid]->init)
		{
			fpos_t fp;
			fgetpos(targetf,&fp);
			fp-=8;
			AddList(fp,fid);//fill in later
		}
		if(!C_Commands[fid]->ext||C_Commands[fid]->rtype!=GetId("float"))
			P_Write(4,vmov,rsaved,rsep,0);
		else
			P_Write(4,vmov,rsaved,rsep,1);
		C_Commands[rsaved+RegStart]->rtype=C_Commands[fid]->rtype;
		C_Commands[rsaved+RegStart]->ind=C_Commands[fid]->ind;
		C_Commands[rsaved+RegStart]->parentf=fid;			
		C_Commands[rsaved+RegStart]->save_ind=0;			
		C_Commands[rsaved+RegStart]->ext=0;			
		free(ti);
		if(loc_d)P_Write(5,vsub,vdata,rsep,cst,(loc_d*4));
		RestoreRegs();
		Regs=rsaved+1;//our return value
		return rsaved+RegStart;
	}
	else
	{
		Regs++;
		P_Write(5,vmov,Regs-1,rsep,cst,(C_Commands[fid]->FPOS));
		C_Commands[Regs-1+RegStart]->rtype=C_Commands[fid]->rtype;
		C_Commands[Regs-1+RegStart]->ind=C_Commands[fid]->ind;
		C_Commands[Regs-1+RegStart]->parentf=fid;			
		C_Commands[Regs-1+RegStart]->save_ind=0;			
		C_Commands[Regs-1+RegStart]->ext=0;			
		if(!C_Commands[fid]->init)
		{
			fpos_t fp;
			fgetpos(targetf,&fp);
			fp-=8;
			AddList(fp,fid);//fill in later
		}
		return Regs-1+RegStart;
	}
}

DWORD Transl(DWORD id)
{
	if(id>=GetId("reg1")&&id<=GetId("reg26"))
		return id-RegStart;
	else if(id==GetId("data"))
		return vdata;
	else if(id==GetId("vip"))
		return vvip;
	else if(id==GetId("and"))
		return vand;
	else if(id==GetId("call"))
		return vcall;
	else if(id==GetId("cmp"))
		return vcmp;
	else if(id==GetId("div"))
		return vdiv;
	else if(id==GetId("jmp"))
		return vjmp;
	else if(id==GetId("mov"))
		return vmov;
	else if(id==GetId("mul"))
		return vmul;
	else if(id==GetId("neg"))
		return vneg;
	else if(id==GetId("not"))
		return vnot;
	else if(id==GetId("or"))
		return vor;
	else if(id==GetId("pop"))
		return vpop;
	else if(id==GetId("push"))
		return vpush;
	else if(id==GetId("pushn"))
		return pushn;
	else if(id==GetId("ret"))
		return vret;
	else if(id==GetId("se"))
		return vext;
	else if(id==GetId("sne"))
		return vnext;
	else if(id==GetId("sub"))
		return vsub;
	else if(id==GetId("fadd"))
		return fadd;
	else if(id==GetId("fsub"))
		return fsub;
	else if(id==GetId("fdiv"))
		return fdiv;
	else if(id==GetId("fmul"))
		return fmul;
	else if(id==GetId("fcmp"))
		return fcmp;
	else if(id==GetId("je"))
		return je;
	else if(id==GetId("jg"))
		return jg;
	else if(id==GetId("jnle"))
		return jnle;
	else if(id==GetId("jge"))
		return jge;
	else if(id==GetId("jnl"))
		return jnl;
	else if(id==GetId("jl"))
		return jl;
	else if(id==GetId("jnge"))
		return jnge;
	else if(id==GetId("jle"))
		return jle;
	else if(id==GetId("jng"))
		return jng;
	else if(id==GetId("+"))
		return radd;
	else if(id==GetId("*"))
		return rmul;
	else if(id==GetId("-"))
		return rsub;
	else if(id==GetId("["))
		return iopen;
	else if(id==GetId("]"))
		return iclose;
	else if(id==GetId(","))
		return rsep;
	else if(id==GetId("bltof"))
		return bltof;
	else if(id==GetId("itof"))
		return itof;
	else if(id==GetId("wtof"))
		return wtof;
	else if(id==GetId("bytof"))
		return bytof;
	else if(id==GetId("dwtof"))
		return dwtof;
	else if(id==GetId("ctof"))
		return ctof;
	else if(id==GetId("stof"))
		return stof;
	else if(id==GetId("ftobl"))
		return ftobl;
	else if(id==GetId("ftoi"))
		return ftoi;
	else if(id==GetId("ftow"))
		return ftow;
	else if(id==GetId("ftoby"))
		return ftoby;
	else if(id==GetId("ftodw"))
		return ftodw;
	else if(id==GetId("ftoc"))
		return ftoc;
	else if(id==GetId("ftos"))
		return ftos;
	else if(id==GetId("inc"))
		return inc;
	else if(id==GetId("dec"))
		return dec;
	else if(id==GetId("finc"))
		return finc;
	else if(id==GetId("fdec"))
		return fdec;
	else if(id==GetId("add"))
		return vadd;
	else if(id==GetId("sub"))
		return vsub;
	else if(id==GetId("mul"))
		return vmul;
	else if(id==GetId("div"))
		return vdiv;
	else C_CreateASMError("error in asm code",id);
	return 0;
}

DWORD ContainsItem(CCmd* buf,WORD len,WORD offs)
{
	DWORD item=0;
	BYTE n_items=0;
	while((buf+offs)->tp!=TYPE_ASM&&offs<len)
	{
		if((buf+offs)->tp==TYPE_DEF)
		{
			item=(buf+offs)->id;
			n_items++;
		}
		offs++;
	}
	if(n_items>1)
		C_CreateError("max one mem access per asm command");
	return item;
}

void TranslateAsm(CCmd* buf,WORD len)
{
	DWORD item=0;
	item=ContainsItem(buf,len,1);
//	if(item)
//		P_RegLoadAdress(item);
	for(DWORD d=0;d<len;d++)
	{
start:
		if(((buf+d)->tp==TYPE_DEF||(buf+d)->tp==TYPE_CMD))
		{
			if((buf+d)->tp==TYPE_CMD)
			{
				DWORD mdw=cst;
				fwrite(&mdw,sizeof(DWORD),1,targetf);
				fpos_t fp;
				fgetpos(targetf,&fp);
				fwrite(&C_Commands[(buf+d)->id]->FPOS,sizeof(DWORD),1,targetf);
				if((buf+d)->tp==TYPE_CMD&&!C_Commands[(buf+d)->id]->init)
					AddList(fp,(buf+d)->id);
			}
			else 
			{
				DWORD mdw=cst;
				fwrite(&mdw,sizeof(DWORD),1,targetf);
				mdw=0;
				fwrite(&mdw,sizeof(DWORD),1,targetf);
				if(C_Commands[item]->ext)
				{
					fpos_t fp;
					fgetpos(targetf,&fp);
					fp-=4;
					AddList(fp,item);
				}
				else
				{
					fpos_t fp;
					fgetpos(targetf,&fp);
					fp-=4;
					AddListLoc(fp,C_Commands[item]->FPOS);
				}
			}
		}
		else if((buf+d)->tp==TYPE_LAB)
		{
			if((buf+d-1)->tp==TYPE_ASM&&((buf+d-1)->id>=GetId("je")&&(buf+d-1)->id<=GetId("jng")))
			{
				DWORD cnst=cst;
				fwrite(&cnst,sizeof(DWORD),1,targetf);
				DWORD mdw=C_Commands[(buf+d)->id]->FPOS;
				fpos_t mfp;
				fgetpos(targetf,&mfp);
				fwrite(&mdw,sizeof(DWORD),1,targetf);
				if(!C_Commands[(buf+d)->id]->init)
					AddListLL(mfp,(buf+d)->id);
				d++;
				if((buf+d)->id!=GetId(">"))
					C_CreateError("'>' awaited after label");
			}
			else 
			{
				fgetpos(targetf,&C_Commands[(buf+d)->id]->FPOS);
				if(d)C_Commands[(buf+d)->id]->FPOS+=4;
				if(!C_Commands[(buf+d)->id]->init)
				{
					C_Commands[(buf+d)->id]->init=1;
					C_Commands[(buf+d)->id]->parentf=0;
				}
				else
					C_CreateASMError("label already defined",(buf+d)->id);
				FillInLL((buf+d)->id);
				d++;
				if((buf+d)->id!=GetId(">"))
					C_CreateError("'>' awaited after label");
				if(d==1)
				{
					item=ContainsItem(buf,len,d+2);
//					if(item)
//						P_RegLoadAdress(item);
					d++;
					goto start;
				}
			}
		}
		else if(((buf+d)->id>=GetId("0")&&(buf+d)->id<=GetId("9")))
		{
			FL=buf+d;
			WORD mlen=len-d;
			WORD point=0;
			float mynumber=GetNumberfl(1,&point,&mlen);
			DWORD mdw=cst;
			fwrite(&mdw,sizeof(DWORD),1,targetf);
			if(point)
				fwrite(&mynumber,sizeof(DWORD),1,targetf);
			else
			{
				DWORD dw=mynumber;
				fwrite(&dw,sizeof(DWORD),1,targetf);
			}
			d+=mlen-1;
		}
		else
		{
			DWORD dw=Transl((buf+d)->id);
			fwrite(&dw,sizeof(DWORD),1,targetf);
		}
		if((d+1<len)&&(buf+d+1)->tp==TYPE_ASM)
		{
			DWORD dw=vend;
			fwrite(&dw,sizeof(DWORD),1,targetf);
			DWORD last_item=item;
			item=ContainsItem(buf,len,d+2);
/*			if(item&&item!=last_item)
			{
				Regs--;
				P_RegLoadAdress(item);
			}
*/		}
	}
}

bool returned=0;

void SolveIf(DWORD Level,DWORD abbort,DWORD func)
{
	DWORD id;
	SHORT tp;
			P_FetchInstruction(&tp,&id);
			if(id!=GetId("("))
				C_CreateError("'(' awaited after if");
			GetLine(GetId(")"));
			DWORD reg=BuildLine(Line,LineLen);
			if(!reg)
				C_CreateError("failed to solve expression");
			else
			{
				SolveSaveInd(reg);
				ConvRegFromTo(reg,C_Commands[reg]->rtype,GetId("bool"));
				P_Write(5,vcmp,reg-RegStart,rsep,cst,0);
				P_Write(3,je,cst,0);
				fpos_t mfp;
				fgetpos(targetf,&mfp);
				mfp-=8;
				AddListL(mfp,Level);
				P_FetchInstruction(&tp,&id);
				if(id==GetId("{"))
					CompileBody(Level+1,GetId("}"),func);
				else 
				{
					P_UndoFetch();
					CompileBody(Level+1,GetId(";"),func);
				}
				//level up
				fgetpos(targetf,&mfp);
				P_FetchInstruction(&tp,&id);
				if(id==GetId("else"))
				{
					FillIn(mfp+16,Level);
					fsetpos(targetf,&mfp);
					P_Write(3,vjmp,cst,0);
					fgetpos(targetf,&mfp);
					mfp-=8;
					AddListL(mfp,Level);
					P_FetchInstruction(&tp,&id);
					if(id==GetId("{"))
					{
						CompileBody(Level+1,GetId("}"),func);
						fgetpos(targetf,&mfp);
						FillIn(mfp,Level);
					}
					else if(id!=GetId("if"))
					{
						P_UndoFetch();
						CompileBody(Level+1,GetId(";"),func);
						fgetpos(targetf,&mfp);
						FillIn(mfp,Level);
					}
					else
					{
						SolveIf(Level,abbort,func);
						fgetpos(targetf,&mfp);
						FillIn(mfp,Level);
					}
				}
				else
				{
					P_UndoFetch();
					FillIn(mfp,Level);
					fsetpos(targetf,&mfp);
				}
			}
}

void SolveRest(fpos_t mfp,DWORD end)
{
			bool equal=0;
			for(DWORD d=0;d<LineLen;d++)
				if((Line+d)->id==GetId("="))
					equal=1;
			if(equal)
			{
				fsetpos(sourcef,&mfp);	
				GetLine(GetId("="));
				DWORD reg=BuildLine(Line,LineLen);
				if(!reg)
					C_CreateASMError("failed to solve expression",GetId("NULL"));
				if(!C_Commands[reg]->save_ind)
					C_CreateASMError("no lvalue",reg);
				GetLine(end);
				DWORD reg2=BuildLine(Line,LineLen);
				SolveSaveInd(reg2);
				if(!reg2)
					C_CreateASMError("failed to solve expression",GetId("NULL"));
				if(C_Commands[reg]->rtype!=C_Commands[reg2]->rtype)
					ConvRegFromTo(reg2,C_Commands[reg2]->rtype,C_Commands[reg]->rtype);
//				ExtFlag(reg);
				P_Write(6,vmov,iopen,reg-RegStart,iclose,rsep,reg2-RegStart);
				Regs-=2;
			}
			else
			{
				DWORD reg=BuildLine(Line,LineLen);
				if(!reg)
					C_CreateASMError("failed to solve expression",GetId("NULL"));
				Regs--;
			}
}

void CompileBody(DWORD Level,DWORD abbort,DWORD func)
{
	DWORD id;
	SHORT tp;
	while(1)
	{
		P_FetchInstruction(&tp,&id);
		if(id==GetId("if"))
		{
			SolveIf(Level,abbort,func);
		}
		else if(id==GetId("do"))
		{
			fpos_t wfp;
			fgetpos(targetf,&wfp);
			P_FetchInstruction(&tp,&id);
			if(id==GetId("{"))
				CompileBody(Level+1,GetId("}"),func);
			else 
			{
				P_UndoFetch();
				CompileBody(Level+1,GetId(";"),func);
			}
			P_FetchInstruction(&tp,&id);
			if(id!=GetId("while"))
				C_CreateError("'while' awaited after do-block");					
			P_FetchInstruction(&tp,&id);
			if(id!=GetId("("))
				C_CreateError("'(' awaited after while");
			fpos_t tfp;
			fgetpos(targetf,&tfp);
			GetLine(GetId(")"));
			DWORD reg=BuildLine(Line,LineLen);
			if(!reg)
				C_CreateError("failed to solve expression");
			else
			{
				SolveSaveInd(reg);
				ConvRegFromTo(reg,C_Commands[reg]->rtype,GetId("bool"));
				P_Write(5,vcmp,reg-RegStart,rsep,cst,0);
				P_Write(3,jne,cst,wfp);
			}
			P_FetchInstruction(&tp,&id);
			if(id!=GetId(";"))
				C_CreateError("';' awaited after do-while statement");
		}
		else if(id==GetId("while"))
		{
			P_FetchInstruction(&tp,&id);
			if(id!=GetId("("))
				C_CreateError("'(' awaited after while");
			fpos_t tfp;
			fgetpos(targetf,&tfp);
			GetLine(GetId(")"));
			DWORD reg=BuildLine(Line,LineLen);
			if(!reg)
				C_CreateError("failed to solve expression");
			else
			{
				SolveSaveInd(reg);
				ConvRegFromTo(reg,C_Commands[reg]->rtype,GetId("bool"));
				P_Write(5,vcmp,reg-RegStart,rsep,cst,0);
				P_Write(3,je,cst,0);
				fpos_t mfp;
				fgetpos(targetf,&mfp);
				mfp-=8;
				AddListL(mfp,Level);
				P_FetchInstruction(&tp,&id);
				if(id==GetId("{"))
					CompileBody(Level+1,GetId("}"),func);
				else 
				{
					P_UndoFetch();
					CompileBody(Level+1,GetId(";"),func);
				}
				P_Write(3,vjmp,cst,tfp);
				//level up
				fgetpos(targetf,&mfp);
				FillIn(mfp,Level);
				fsetpos(targetf,&mfp);
			}
		}
		else if(tp==TYPE_VAR)//var def
		{
			GetLine(GetId(";"));
			if(abbort==GetId(";"))
				return;
		}
		else if(id==abbort)
			return;
		else if(id==GetId("for"))
		{
			P_FetchInstruction(&tp,&id);
			if(id!=GetId("("))
				C_CreateASMError("'(' awaited after for",id);
			
			fpos_t mfp;
			P_FetchInstruction(&tp,&id);
			if(C_Commands[id]->Type==TYPE_VAR)
			{
				while(id!=GetId(";"))
				P_FetchInstruction(&tp,&id);
			}
			else 
			{
				P_UndoFetch();
				fgetpos(sourcef,&mfp);
				GetLine(GetId(";"));
				SolveRest(mfp,GetId(";"));
			}
			fpos_t fp;
			fgetpos(targetf,&fp);
			GetLine(GetId(";"));
			DWORD reg=BuildLine(Line,LineLen);
			if(!reg)
				C_CreateError("failed to solve expression");
			P_Write(5,vcmp,reg-RegStart,rsep,cst,0);
			P_Write(3,je,cst,0);
			fpos_t fp2;
			fgetpos(targetf,&fp2);
			fp2-=8;
			AddListL(fp2,Level);
			fgetpos(sourcef,&mfp);
			GetLine(GetId(")"));
			SolveRest(mfp,GetId(")"));
			P_FetchInstruction(&tp,&id);
			if(id==GetId("{"))
				CompileBody(Level+1,GetId("}"),func);
			else 
			{
				P_UndoFetch();
				CompileBody(Level+1,GetId(";"),func);
			}
			P_Write(3,vjmp,cst,fp);
			fgetpos(targetf,&fp2);
			FillIn(fp2,Level);
			fsetpos(targetf,&fp2);
		}
		else if(id==GetId("break"))
		{
			P_Write(3,vjmp,cst,0);
			fpos_t fp;
			fgetpos(targetf,&fp);
			fp-=8;
			AddListL(fp,Level-1);
			if(Level==1)
				C_CreateError("break outside for/while block");
			P_FetchInstruction(&tp,&id);
			if(id!=GetId(";"))
				C_CreateASMError("';' awaited after break",id);
		}
		else if(id==GetId("return"))
		{
			GetLine(GetId(";"));
			ext_flag=0;
			P_Write(1,vnext);
			P_Write(4,vmov,vdata,rsep,Ebp-RegStart);
			Regs=0;//return in reg1
			DWORD reg=BuildLine(Line,LineLen);
			SolveSaveInd(reg);
			if(C_Commands[func]->rtype!=GetId("void"))
			{
				if(!reg)C_CreateASMError("Function must return a value",func);
				else ConvRegFromTo(reg,C_Commands[reg]->rtype,C_Commands[func]->rtype);
			}
			else 
			{
				if(reg)C_CreateASMError("Function dos not return a value",func);
				else Regs++;
			}
			P_Write(1,vret);	
			if(Level==1)returned=1;
		}
		else if(id==GetId("__asm"))
		{
			P_FetchInstruction(&tp,&id);
			if(id!=GetId("{"))
				C_CreateError("'{' awaited after __asm");
			GetLine(GetId("}"));
			TranslateAsm(Line,LineLen);
			P_Write(0);
		}
		else
		{
			P_UndoFetch();
			fpos_t mfp;
			fgetpos(sourcef,&mfp);
			GetLine(GetId(";"));
			SolveRest(mfp,GetId(";"));
			if(abbort==GetId(";"))
				return;
		}
	}
}

void CompileFunc(DWORD d)
{
	DWORD rr=Regs;
	fpos_t func_start;
	fgetpos(targetf,&func_start);
	SYS_TextOut("compiling %s...",C_Commands[d]->CName);
	DWORD ind=0;
	for(DWORD dw=0;dw<C_Commands[d]->nargs;dw++)
	{
		if(*(C_Commands[d]->args+dw)!=GetId("*"))
		{
			C_Commands[*(C_Commands[d]->args+dw)]->ind=ind;
			ind=-1;
		}
		ind++;			
	}
	
	fsetpos(sourcef,&C_Commands[d]->FPOS);
	DWORD id;
	SHORT tp;
	P_FetchInstruction(&tp,&id);
	while(id!=GetId("{"))
		if(!P_FetchInstruction(&tp,&id))
		{
			C_CreateError("unexspectd eof");
			SYS_Error("Fatal error.","");
		}
	
	DWORD Level=1;
	DWORD ebp=Regs+RegStart;
	Ebp=ebp;
	C_Commands[ebp]->ext=0;
	Regs++;
	DWORD datas=DATASEG;
	P_Write(4,vmov,ebp-RegStart,rsep,vdata);
	ext_flag=0;
	P_Write(1,vnext);
	DWORD LocVars=0;
	while(Level)
	{
		P_FetchInstruction(&tp,&id);
		if(id==GetId("{"))
			Level++;
		else if(id==GetId("}"))
			Level--;
		if(C_Commands[id]->frame>=1&&C_Commands[id]->Type==TYPE_DEF&&C_Commands[id]->parentf==d&&!C_Commands[id]->created)
		{
			DWORD mid=id;
			P_UndoFetch();
			P_UndoFetch();
			P_FetchInstruction(&tp,&id);
			while(id==GetId("*"))
			{
				P_UndoFetch();
				P_UndoFetch();
				P_FetchInstruction(&tp,&id);
				C_Commands[mid]->ind++;			
			}
			while(id!=mid)
				P_FetchInstruction(&tp,&id);
			P_FetchInstruction(&tp,&id);
			DWORD size=1;
			DWORD dims=0;
			fpos_t fp;
			fgetpos(sourcef,&fp);
			while(id==GetId("["))//handle array
			{
				dims++;
				WORD len;
				size*=GetNumber(0,0,&len);
				P_FetchInstruction(&tp,&id);
				if(id!=GetId("]"))
					C_CreateASMError("']' awaited",GetId("NULL"));
				P_FetchInstruction(&tp,&id);
			}
			C_Commands[mid]->dim=size*C_Commands[C_Commands[mid]->rtype]->frame;
			if(dims)
			{
				C_Commands[mid]->nargs=dims;
				C_Commands[mid]->array_depth=dims;
				C_Commands[mid]->args=(DWORD*)malloc(sizeof(DWORD)*dims);
				fsetpos(sourcef,&fp);
				dims=0;
				id=GetId("[");
				while(id==GetId("["))//handle array
				{
					WORD len;
					*(C_Commands[mid]->args+dims)=(DWORD)GetNumber(0,0,&len);
					P_FetchInstruction(&tp,&id);
					P_FetchInstruction(&tp,&id);
					dims++;
				}
			}
			double assign;
			if(id==GetId("="))//handle assignments
			{
				C_Commands[mid]->init=1;
				GetLine(GetId(";"));
///solving!!
				id=GetId(";");
				if(size>1)
					C_CreateASMError("Arrays cannot be initialized!",mid);
				if(C_Commands[mid]->ext)
					C_CreateASMError("external variables cannot be initialized!",mid);
			}
			if(id!=GetId(";"))
				C_CreateASMError("';' missing at end of line",GetId("NULL"));
			C_Commands[mid]->FPOS=DATASEG-datas;
			C_Commands[mid]->created=1;
			LocVars+=C_Commands[mid]->dim;
			DATASEG+=C_Commands[mid]->dim;
				
		}
	}
	if(LocVars)
		P_Write(5,vadd,vdata,rsep,cst,LocVars);
	if(fsetpos(sourcef,&C_Commands[d]->FPOS))
	{
		C_CreateASMError("entrypoint not found!",GetId("NULL"));
		SYS_Error("Fatal error.","");
	}

	for(DWORD mdw=0;mdw<=C_Num_Commands;mdw++)
	{
		if(C_Commands[mdw]->init&&C_Commands[mdw]->parentf==d)
		{
			while(id!=mdw)P_FetchInstruction(&tp,&id);
			P_FetchInstruction(&tp,&id);//"="
			GetLine(GetId(";"));
			ClearRegs();
			DWORD reg=BuildLine(Line,LineLen);
			SolveSaveInd(reg);
			if(!reg)
				C_CreateASMError("failed to solve expression",GetId("NULL"));
			else
			{
				if(C_Commands[C_Commands[reg]->rtype]->ID!=GetId("?")&&(C_Commands[reg]->ind!=C_Commands[mdw]->ind))
				{
					char ind1[255]="";
					for(DWORD i=0;i<C_Commands[mdw]->ind;i++)
						ind1[i]='*';
					char ind2[255]="";
					for(i=0;i<C_Commands[reg]->ind;i++)
						ind2[i]='*';
					char str[255]="";
					sprintf(str,"cannot cast argument from (%s%s) to (%s%s). Explicit cast needed."
						,ind2,C_Commands[C_Commands[reg]->rtype]->CName
						,ind1,C_Commands[C_Commands[mdw]->rtype]->CName);
					C_CreateASMError(str,mdw);
				}
				else
				{
					if(C_Commands[reg]->rtype!=C_Commands[mdw]->rtype)
						ConvRegFromTo(reg,C_Commands[reg]->rtype,C_Commands[mdw]->rtype);
					P_RegLoadAdress(mdw);
//					ExtFlag(Regs-1+RegStart);
					P_Write(6,vmov,iopen,Regs-1,iclose,rsep,reg-RegStart);
					Regs--;
				}
			}
			Regs--;
		}
	}
	if(fsetpos(sourcef,&C_Commands[d]->FPOS))
	{
		C_CreateASMError("entrypoint not found!",d);
		SYS_Error("Fatal error.","");
	}
	while(id!=GetId("{"))
		if(!P_FetchInstruction(&tp,&id))
		{
			C_CreateError("unexspectd eof");
			SYS_Error("Fatal error.","");
		}
	returned=0;
	CompileBody(1,GetId("}"),d);	
	if(C_Commands[d]->rtype!=GetId("void"))
	{
		if(!returned)C_CreateASMError("Function must return a value",d);
	}
	//end
	Regs=rr;
	DATASEG=datas;
	if(!returned)
	{
		ext_flag=0;
		P_Write(1,vnext);
		P_Write(4,vmov,vdata,rsep,Ebp-RegStart);
		P_Write(1,vret);
	}
	C_Commands[d]->init=1;
	C_Commands[d]->FPOS=func_start;
	FillInCmdList(d);
}

void P_TranslateBES(FILE* bes,char* sn,FILE* out)
{
//	DWORD ght=num_opcodes;
	sourcef=bes;
	targetf=out;
	RegStart=GetId("reg1");
	RegEnd=GetId("reg26");
	P_Write(3,vjmp,cst,0);
	ml.next=NULL;
	ml.pos=0;
	C_Commands[GetId("const")]->rtype=GetId("float");
	C_Commands[GetId("const")]->dim=C_Commands[GetId("float")]->frame;
//	SYS_TextOut("-opened \n");
	CCMD=(CCmd*)malloc(sizeof(CCmd));
	Line=(CCmd*)malloc(sizeof(CCmd)*DEF_LINE_MAX);
	FL=Line;
//	SYS_TextOut("Translating to asm");

	SYS_TextOut("2nd pass -> allocating vars\n");
	if(fsetpos( bes, &C_Init_FPOS ))
	{
		C_CreateASMError("entrypoint not found!",GetId("NULL"));
		SYS_Error("Fatal error.","");
	}
//search global vars+alloc
	SHORT tp;
	DWORD id;

	for(DWORD d=0;d<=C_Num_Commands;d++)
	{
		if(C_Commands[d]->Type==TYPE_DEF&&C_Commands[C_Commands[d]->rtype]->ID==C_Commands[d]->rtype
		&&C_Commands[d]->frame==0&&C_Commands[d]->parentf==0xffff)
		{
			while(id!=d)
			{
				if(!P_FetchInstruction(&tp,&id))
				{
					C_CreateASMError("var def not found",GetId("NULL"));
					SYS_Error("Fatal error.","");
				}
			}
			P_UndoFetch();
			P_UndoFetch();
			P_FetchInstruction(&tp,&id);
			while(id==GetId("*"))
			{
				P_UndoFetch();
				P_UndoFetch();
				P_FetchInstruction(&tp,&id);
				C_Commands[d]->ind++;			
			}
			while(id!=d)
				P_FetchInstruction(&tp,&id);
			P_FetchInstruction(&tp,&id);
			DWORD size=1;
			DWORD dims=0;
			fpos_t fp;
			fgetpos(sourcef,&fp);
			while(id==GetId("["))//handle array
			{
				dims++;
				WORD len;
				size*=GetNumber(0,0,&len);
				P_FetchInstruction(&tp,&id);
				if(id!=GetId("]"))
					C_CreateASMError("']' awaited",GetId("NULL"));
				P_FetchInstruction(&tp,&id);
			}
			C_Commands[d]->dim=size*C_Commands[C_Commands[d]->rtype]->frame;
			if(dims)
			{
				C_Commands[d]->nargs=dims;
				C_Commands[d]->array_depth=dims;
				C_Commands[d]->args=(DWORD*)malloc(sizeof(DWORD)*dims);
				fsetpos(sourcef,&fp);
				dims=0;
				id=GetId("[");
				while(id==GetId("["))//handle array
				{
					WORD len;
					*(C_Commands[d]->args+dims)=(DWORD)GetNumber(0,0,&len);
					P_FetchInstruction(&tp,&id);
					P_FetchInstruction(&tp,&id);
					dims++;
				}
			}
			double assign;
			if(id==GetId("="))//handle assignments
			{
				C_Commands[d]->init=1;
				GetLine(GetId(";"));
///solving!!
				id=GetId(";");
				if(size>1)
					C_CreateASMError("Arrays cannot be initialized!",d);
				if(C_Commands[d]->ext)
					C_CreateASMError("external variables cannot be initialized!",d);
			}
			if(id!=GetId(";"))
				C_CreateASMError("';' missing at end of line",GetId("NULL"));
			C_Commands[d]->FPOS=DATASEG;
			C_Commands[d]->created=1;
			DATASEG+=C_Commands[d]->dim;
			if(fsetpos( bes, &C_Init_FPOS ))
			{
				C_CreateASMError("entrypoint not found!",GetId("NULL"));
				SYS_Error("Fatal error.","");
			}
		}
	}
	DWORD seg=DATASEG;
	for(d=0;d<=C_Num_Commands;d++)
	{
		if(C_Commands[d]->Type==TYPE_STR)
		{
			C_Commands[d]->FPOS=DATASEG;
			DWORD x=C_Commands[d]->true_args/4;
			x+=2;
			x*=4;
			DATASEG+=x;
		}
	}

	SYS_TextOut("DATASEG %d byte (%dkb), %d byte strings",DATASEG,DATASEG/1024,DATASEG-seg);
	P_Write(5,vmov,vdata,rsep,cst,(DATASEG));

	SYS_TextOut("3rd pass -> initialize data\n");
	ext_flag=0;
	P_Write(1,vnext);

	for(d=0;d<=C_Num_Commands;d++)
	{
		if(C_Commands[d]->init)
		{
			while(id!=d)P_FetchInstruction(&tp,&id);
			P_FetchInstruction(&tp,&id);//"="
			GetLine(GetId(";"));
			ClearRegs();
			DWORD reg=BuildLine(Line,LineLen);
			SolveSaveInd(reg);
			if(!reg)
				C_CreateASMError("failed to solve expression",GetId("NULL"));
			else
			{
				if(C_Commands[C_Commands[reg]->rtype]->ID!=GetId("?")&&(C_Commands[reg]->ind!=C_Commands[d]->ind))
				{
					char ind1[255]="";
					for(DWORD i=0;i<C_Commands[d]->ind;i++)
						ind1[i]='*';
					char ind2[255]="";
					for(i=0;i<C_Commands[reg]->ind;i++)
						ind2[i]='*';
					char str[255]="";
					sprintf(str,"cannot cast argument from (%s%s) to (%s%s). Explicit cast needed."
						,ind2,C_Commands[C_Commands[reg]->rtype]->CName
						,ind1,C_Commands[C_Commands[d]->rtype]->CName);
					C_CreateASMError(str,d);
				}
				else
				{
					if(C_Commands[reg]->rtype!=C_Commands[d]->rtype)
						ConvRegFromTo(reg,C_Commands[reg]->rtype,C_Commands[d]->rtype);
					P_RegLoadAdress(d);
//					ExtFlag(Regs-1+RegStart);
					P_Write(6,vmov,iopen,Regs-1,iclose,rsep,reg-RegStart);
					Regs--;//preg and buildline
				}
			}
			Regs--;
		}
	}
	for(d=0;d<=C_Num_Commands;d++)
	{
		if(C_Commands[d]->Type==TYPE_STR)
		{
			C_Commands[d]->Type=TYPE_DEF;
			for(DWORD d2=0;d2<C_Commands[d]->true_args/4;d2++)
			{
				DWORD buf;
				memcpy(&buf,(C_Commands[d]->def+d2*4),sizeof(char)*4);
				P_Write(5,vmov,0,rsep,cst,buf);
				DWORD add=(C_Commands[d]->FPOS+d2*4);
				P_Write(7,vmov,iopen,cst,add,iclose,rsep,0);
				fpos_t fp;
				fgetpos(targetf,&fp);
				fp-=20;
				AddListLoc(fp,add);
			}
			DWORD buf;
			memcpy(&buf,(C_Commands[d]->def+d2*4),sizeof(char)*(C_Commands[d]->true_args-d2*4));
			P_Write(5,vmov,0,rsep,cst,buf);
			DWORD add=(C_Commands[d]->FPOS+d2*4);
			P_Write(7,vmov,iopen,cst,add,iclose,rsep,0);
			fpos_t fp;
			fgetpos(targetf,&fp);
			fp-=20;
			AddListLoc(fp,add);

			P_Write(5,vmov,0,rsep,cst,C_Commands[d]->FPOS);
			fgetpos(targetf,&fp);
			fp-=8;
			AddListLoc(fp,C_Commands[d]->FPOS);
			add=(C_Commands[d]->FPOS+(d2+1)*4);
			P_Write(7,vmov,iopen,cst,add,iclose,rsep,0);
			fgetpos(targetf,&fp);
			fp-=20;
			AddListLoc(fp,add);
			C_Commands[d]->FPOS=add;
		}
	}
	P_Write(1,vret);//global init done...
//	Regs=0;

	SYS_TextOut("4th pass -> compiling funcs\n");

	for(d=0;d<=C_Num_Commands;d++)
	{
		if(C_Commands[d]->Type==TYPE_CMD&&!C_Commands[d]->ext)
		{
			CompileFunc(d);
		}
	}
	//write offset of link info into file
	fpos_t lfp;
	fgetpos(targetf,&lfp);
	SYS_TextOut("\nCODESEG %d byte (%dkb)",(DWORD)lfp,((DWORD)lfp)/1024);
	SYS_TextOut("\nwriting linker info...");
	extern WORD C_Error;
	if(C_Error)
	{
		fpos_t nfp=0;
		fsetpos(targetf,&nfp);
		P_Write(3,nfp,nfp,nfp);
		return;
	}
	fpos_t nfp=0;
	fsetpos(targetf,&nfp);
	P_Write(3,vjmp,cst,lfp);
	fsetpos(targetf,&lfp);
	
	LL* ll=&ml;
	DWORD size=0;
	DWORD buffer=0;
	while(1)
	{
		if(ll->id)
		{
			char* buf=NULL;
			if(C_Commands[ll->id]->Type==TYPE_DEF)
			{
				buf=strstr(C_Commands[ll->id]->CName,"::");
				buf+=2;
			}
			else buf=C_Commands[ll->id]->CName;
			buffer=strlen(buf);
			size+=8+buffer;
			fwrite(&buffer,1,4,targetf);
			fprintf(targetf,"%s",buf);
			buffer=ll->pos;
			fwrite(&buffer,1,4,targetf);
		}
		if(!ll->next)break;
		ll=ll->next;
	}
	buffer=0xffff;
	fwrite(&buffer,1,4,targetf);

	ll=&locl;
	while(1)
	{
		if(ll->pos!=0||ll->id!=0)
		{
			buffer=ll->pos;
			fwrite(&buffer,1,4,targetf);
			buffer=ll->id;
			fwrite(&buffer,1,4,targetf);
			size+=4;
		}
		if(!ll->next)break;
		ll=ll->next;
	}
	buffer=0xffff;
	fwrite(&buffer,1,4,targetf);
	for(d=0;d<=C_Num_Commands;d++)
	{
		if(C_Commands[d]->Type==TYPE_CMD&&!C_Commands[d]->ext)
		{
			char* buf=NULL;
			if(C_Commands[d]->Type==TYPE_DEF)
			{
				buf=strstr(C_Commands[d]->CName,"::");
				buf+=2;
			}
			else buf=C_Commands[d]->CName;
			buffer=strlen(buf);
			size+=8+buffer;
			fwrite(&buffer,1,4,targetf);
			fprintf(targetf,"%s",buf);
			buffer=C_Commands[d]->FPOS;
			fwrite(&buffer,1,4,targetf);
		}
	}
	buffer=0xffff;
	fwrite(&buffer,1,4,targetf);
	size+=8;
	SYS_TextOut("LINK %d byte (%dkb)",size,size/1024);

	FreeList();
//	free(CCMD);
}