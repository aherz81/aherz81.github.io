#pragma optimize( "", on )//bypass bug of compiler
#pragma warning( disable : 4244 )

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <commdlg.h>
#include <stdarg.h>

#include <winbase.h>
#include <winuser.h>

#include <mmsystem.h>
#include <math.h>

#include <process.h> 
#include "resource.h"

#include "..\vm_asm.h"

FILE * fbuf=NULL;
void * buf=NULL;

WORD Line=0;

char BLine[255]="";
bool error=0;

char* GetCmd(DWORD id)
{
	switch(id)
	{
	case vand:
		return "and";
	case vdata:
		return "data";
	case vvip:
		return "eip";
	case vadd:
		return "add";
	case vcall:
		return "call";
	case vcmp:
		return "cmp";
	case vdiv:
		return "div";
	case vjmp:
		return "jmp";
	case vmov:
		return "mov";
	case vmul:
		return "mul";
	case vneg:
		return "neg";
	case vnot:
		return "not";
	case vor:
		return "or";
	case vpop:
		return "pop";
	case vpush:
		return "push";
	case vret:
		return "ret";
	case vext:
		return "se";
	case vnext:
		return "sne";
	case vsub:
		return "sub";
	case fadd:
		return "fadd";
	case fsub:
		return "fsub";
	case fdiv:
		return "fdiv";
	case fmul:
		return "fmul";
	case fcmp:
		return "fcmp";
	case je:
		return "je";
	case jne:
		return "jne";
	case jg:
		return "jg";
	case jnle:
		return "jnle";
	case jge:
		return "jge";
	case jnl:
		return "jnl";
	case jl:
		return "jl";
	case jnge:
		return "jnge";
	case jle:
		return "jle";
	case jng:
		return "jng";
	case bltof:
		return "bltof";
	case bytof:
		return "bytof";
	case ctof:
		return "ctof";
	case stof:
		return "stof";
	case wtof:
		return "wtof";
	case dwtof:
		return "dwtof";
	case itof:
		return "itof";
	case ftobl:
		return "ftobl";
	case ftoby:
		return "ftoby";
	case ftoc:
		return "ftoc";
	case ftos:
		return "ftos";
	case ftow:
		return "ftow";
	case ftodw:
		return "ftodw";
	case ftoi:
		return "ftoi";
	case inc:
		return "inc";
	case dec:
		return "dec";
	case finc:
		return "finc";
	case fdec:
		return "fdec";
	case texbegin:
		return "texbegin";
	case blend:
		return "blend";
	case tcmod:
		return "tcmod";
	case texend:
		return "texend";
	case flush:
		return "flush";
	case cull:
		return "cull";
	case depth:
		return "depth";
	case tcgen:
		return "tcgen";
	case pushn:
		return "pushn";
	default:
		error=1;
		return "unknown command";
		break;
	}
	return "translator error";
}

DWORD GetCmds(char*c)
{
	if(!strcmp(c,"and"))return vand;
	if(!strcmp(c,"add"))return vadd;
	if(!strcmp(c,"call"))return vcall;
	if(!strcmp(c,"cmp"))return vcmp;
	if(!strcmp(c,"div"))return vdiv;
	if(!strcmp(c,"jmp"))return vjmp;
	if(!strcmp(c,"mov"))return vmov;
	if(!strcmp(c,"mul"))return vmul;
	if(!strcmp(c,"neg"))return vneg;
	if(!strcmp(c,"not"))return vnot;
	if(!strcmp(c,"or"))return vor;
	if(!strcmp(c,"pop"))return vpop;
	if(!strcmp(c,"push"))return vpush;
	if(!strcmp(c,"ret"))return vret;
	if(!strcmp(c,"se"))return vext;
	if(!strcmp(c,"sne"))return vnext;
	if(!strcmp(c,"sub"))return vsub;
	if(!strcmp(c,"fadd"))return fadd;
	if(!strcmp(c,"fsub"))return fsub;
	if(!strcmp(c,"fdiv"))return fdiv;
	if(!strcmp(c,"fmul"))return fmul;
	if(!strcmp(c,"fcmp"))return fcmp;
	if(!strcmp(c,"je"))return je;
	if(!strcmp(c,"jne"))return jne;
	if(!strcmp(c,"jg"))return jg;
	if(!strcmp(c,"jnle"))return jnle;
	if(!strcmp(c,"jge"))return jge;
	if(!strcmp(c,"jnl"))return jnl;
	if(!strcmp(c,"jl"))return jl;
	if(!strcmp(c,"jnge"))return jnge;
	if(!strcmp(c,"jle"))return jle;
	if(!strcmp(c,"jng"))return jng;
	if(!strcmp(c,"bltof"))return bltof;
	if(!strcmp(c,"bytof"))return bytof;
	if(!strcmp(c,"wtof"))return wtof;
	if(!strcmp(c,"dwtof"))return dwtof;
	if(!strcmp(c,"ctof"))return ctof;
	if(!strcmp(c,"stof"))return stof;
	if(!strcmp(c,"itof"))return itof;
	if(!strcmp(c,"ftobl"))return ftobl;
	if(!strcmp(c,"ftoby"))return ftoby;
	if(!strcmp(c,"ftow"))return ftow;
	if(!strcmp(c,"ftodw"))return ftodw;
	if(!strcmp(c,"ftoc"))return ftoc;
	if(!strcmp(c,"ftos"))return ftos;
	if(!strcmp(c,"ftoi"))return ftoi;
	if(!strcmp(c,"inc"))return inc;
	if(!strcmp(c,"dec"))return dec;
	if(!strcmp(c,"finc"))return finc;
	if(!strcmp(c,"fdec"))return fdec;
	if(!strcmp(c,"texbegin"))return texbegin;
	if(!strcmp(c,"blend"))return blend;
	if(!strcmp(c,"tcmod"))return tcmod;
	if(!strcmp(c,"texend"))return texend;
	if(!strcmp(c,"tcgen"))return tcgen;
	if(!strcmp(c,"flush"))return flush;
	if(!strcmp(c,"cull"))return cull;
	if(!strcmp(c,"depth"))return depth;
	if(!strcmp(c,"pushn"))return pushn;
	char str[255]="";
	sprintf(str,"syntax error '%s' line %d\n%s",c,Line,BLine);
	exit(0);
}


char* GetArgs(DWORD id)
{
	char str[20]="";

	switch(id)
	{
	case vend:
		return "\n";
	case radd:
		return "+";
	case rsub:
		return "-";
	case rsep:
		return ",";
	case rmul:
		return "*";
	case iopen:
		return "[";
	case iclose:
		return "]";
	case cst:
		return "const";
	case val:
		return "reg1";
	case vah:
		return "reg2";
	case vax:
		return "reg3";
	case veax:
		return "reg4";
	case vbl:
		return "reg5";
	case vbh:
		return "reg6";
	case vbx:
		return "reg7";
	case vebx:
		return "reg8";
	case vcl:
		return "reg9";
	case vch:
		return "reg10";
	case vcx:
		return "reg11";
	case vecx:
		return "reg12";
	case vdl:
		return "reg13";
	case vdh:
		return "reg14";
	case vdx:
		return "reg15";
	case vedx:
		return "reg16";
	case vbp:
		return "reg17";
	case vebp:
		return "reg18";
	case vsi:
		return "reg19";
	case vesi:
		return "reg20";
	case vdi:
		return "reg21";
	case vedi:
		return "reg22";
	case vip:
		return "reg23";
	case veip:
		return "reg24";
	case vsp:
		return "reg25";
	case vesp:
		return "reg26";
	case vdata:
		return "data";
	case vvip:
		return "eip";
	default:
		error=1;
		return "unknown command";
		break;
	}
	return "translator error";

}

DWORD GetArgs(char*c)
{
	if(!strcmp(c,"reg1"))return val;
	if(!strcmp(c,"reg2"))return vah;
	if(!strcmp(c,"reg3"))return vax;
	if(!strcmp(c,"reg4"))return veax;
	if(!strcmp(c,"reg5"))return vbl;
	if(!strcmp(c,"reg6"))return vbh;
	if(!strcmp(c,"reg7"))return vbx;
	if(!strcmp(c,"reg8"))return vebx;
	if(!strcmp(c,"reg9"))return vcl;
	if(!strcmp(c,"reg10"))return vch;
	if(!strcmp(c,"reg11"))return vcx;
	if(!strcmp(c,"reg12"))return vecx;
	if(!strcmp(c,"reg13"))return vdl;
	if(!strcmp(c,"reg14"))return vdh;
	if(!strcmp(c,"reg15"))return vdx;
	if(!strcmp(c,"reg16"))return vedx;
	if(!strcmp(c,"reg17"))return vbp;
	if(!strcmp(c,"reg18"))return vebp;
	if(!strcmp(c,"reg19"))return vsi;
	if(!strcmp(c,"reg20"))return vesi;
	if(!strcmp(c,"reg21"))return vdi;
	if(!strcmp(c,"reg22"))return vedi;
	if(!strcmp(c,"reg23"))return vip;
	if(!strcmp(c,"reg24"))return veip;
	if(!strcmp(c,"reg25"))return vsp;
	if(!strcmp(c,"reg26"))return vesp;
	if(!strcmp(c,"data"))return vdata;
	if(!strcmp(c,"eip"))return vvip;

	if(!strcmp(c,"+"))return radd;
	if(!strcmp(c,"-"))return rsub;
	if(!strcmp(c,","))return rsep;
	if(!strcmp(c,"*"))return rmul;
	if(!strcmp(c,"["))return iopen;
	if(!strcmp(c,"]"))return iclose;
	if(!strcmp(c,"const"))return cst;
	return 0xffff;
}

void translate(FILE*f,bool k)
{
	fpos_t offset=0;
	if(!k)
	{
		bool constant=0;
		DWORD in;
		bool space=0;
		while(fread((void*)&in,sizeof(DWORD),1,f))
		{
			fprintf(fbuf,"%d: ",offset);
			fprintf(fbuf,"%s ",GetCmd(in));
			if(error)break;
			while(in!=vend||constant)
			{
				fread((void*)&in,sizeof(DWORD),1,f);
				if(in==vend)
					space=0;
				else space=1;
				if(in!=rmul&&in!=radd&&in!=rsub&&in!=cst)
				{
					if(constant)
					{
						if(space)fprintf(fbuf,"%d ",in);
						else fprintf(fbuf,"%d",in);
						constant=0;
					}
					else
						if(space)fprintf(fbuf,"%s ",GetArgs(in));
						else fprintf(fbuf,"%s",GetArgs(in));
					if(error)break;
				}
				else
				{
					constant=1;
					if(space)fprintf(fbuf,"%s ",GetArgs(in));
					else fprintf(fbuf,"%s",GetArgs(in));
					if(error)break;
				}
			}
			fgetpos(f,&offset);
			Line++;
		}
	}
	else 
	{
		char buf[20]="";
		char in=0;
		int c=0;
		DWORD id=0;
		bool cmd=1;
		bool constant=0;
		Line=0;
		while(fread((void*)&in,sizeof(char),1,f))
		{
			if(in==32)
			{
				buf[c]=NULL;	
				c=0;
				if(cmd)
				{
					BLine[0]=NULL;
					Line++;
					id=GetCmds(buf);
					cmd=0;
					fwrite((void*)&id,sizeof(DWORD),1,fbuf);
				}
				else
				{
					id=GetArgs(buf);
					if(id==radd||id==rmul||id==cst||in==rsub)
						constant=1;
					if(id==0xffff)
					{
						if(!constant)
						{
							char str[255]="";
							sprintf(str,"syntax error '%s' line %d\n%s",c,Line,BLine);
							MessageBox(NULL,str,"error",MB_OK);
							exit(0);
						}
						else
						{
							id=atoi(buf);
							fwrite((void*)&id,sizeof(DWORD),1,fbuf);
							id=0xffff;
							constant=0;
						}
					}
					if(id!=0xffff)fwrite((void*)&id,sizeof(DWORD),1,fbuf);
				}
				sprintf(BLine,"%s %s",BLine,buf);
				char bb=10;
				bool next=0;
				id=10;
				while((bb==13||bb==10||bb==32)&&id)
				{
					id=fread((void*)&bb,sizeof(char),1,f);
					if((bb==13||bb==10))next=1;
				}
				if(id)fseek(f,-1,SEEK_CUR);
				if(next)
				{
					cmd=1;
					id=vend;
					fwrite((void*)&id,sizeof(DWORD),1,fbuf);
				}
			}
			else if(in==10||in==13)
			{
				buf[c]=NULL;	
				c=0;
				bool nend=1;
				in=13;
				while((in==13||in==10||in==32)&&nend)
				{
					nend=fread((void*)&in,sizeof(char),1,f);
				}
				if(nend)fseek(f,-1,SEEK_CUR);
				id=GetArgs(buf);
				cmd=1;
				sprintf(BLine,"%s %s",BLine,buf);
				if(id==0xffff)
				{
					char str[255]="";
					sprintf(str,"syntax error '%s' line %d\n%s",buf,Line,BLine);
					MessageBox(NULL,str,"error",MB_OK);
					exit(0);
				}
				if(id!=0xffff)fwrite((void*)&id,sizeof(DWORD),1,fbuf);
				id=vend;
				fwrite((void*)&id,sizeof(DWORD),1,fbuf);
			}
			else
			{
				buf[c]=in;
				c++;
			}
		}
	}
}

int main (int argc, char **argv)
{
	if(argc<3)
	{
		printf("invalid argument count");
		exit(0);	
	}

	bool krp=0;

start:

	buf=malloc(8);
	char str2[255]="";
	sprintf(str2,"%s",argv[2]);
	str2[strlen(str2)-3]=0;
	if(krp)
		sprintf(str2,"%sbin",str2);
	else 
		sprintf(str2,"%sasm",str2);
	fbuf=fopen(str2,"wb");
	if(!strcmp(argv[1],"k"))
		krp=1;
	else krp=0;
	FILE* f=fopen(argv[2],"rb");
	printf("opening '%s'...\n",argv[2]);
	if(!f)
	{
		printf("couldn't find '%s'!\n",argv[2]);
		exit(0);
	}

	if(krp)
		printf("writing '%s'...\n",argv[2]);
	else
		printf("reading '%s'...\n",argv[2]);
	DWORD kk=0;

	translate(f,krp);

	fclose(fbuf);
	fclose(f);
	if(!error)
	{
		CopyFile(str2,argv[2],0);
	}
	if(krp)
		DeleteFile(str2);
	else error=0;
	printf("processing '%s' done\n",argv[2]);
	printf("\nthx for using this tool..(c) by alex\n",argv[2]);
	free(buf);
	if(!krp)
	{	
		char sys[255]="";
		sprintf(sys,"c:\\wordpad %s%c",str2,0);
		system(sys);
		char str[255]="";
		sprintf(str,"%s%c",argv[2],0);
		sprintf(argv[1],"k%c",0);
		sprintf(argv[2],"%s%c",str,0);
		krp=1;
//		goto start;
	}
	exit(0);
}