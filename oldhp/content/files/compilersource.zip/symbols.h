#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <commdlg.h>
#include <stdarg.h>

#include <winbase.h>
#include <winuser.h>

#include <mmsystem.h>
#include <math.h>

#ifndef __SCRIPT
#define __SCRIPT

#define TYPE_VAR -1
#define TYPE_CMD -2
#define TYPE_SGN -3
#define TYPE_EXT -4
#define TYPE_DEF -5
#define TYPE_STR -6
#define TYPE_FNC -7
#define TYPE_ASM -8
#define TYPE_LAB -9

#define TYPE_INC -10


struct Cmd
{
	char* CName;
	DWORD ID;
	SHORT Type;
	fpos_t FPOS;
	char* def;
	WORD frame;
	bool define;
	DWORD* args;
	WORD nargs;
	DWORD parentf;
	bool ext;
	bool incl;
	int rtype;
	WORD ind;
	DWORD dim;
	bool init;
	WORD argid;
	bool save_ind;
	bool created;
	WORD true_args;
	WORD array_depth;
};

#define C_INCLUDE "#include"
#define C_PRAGMA "#pragma"
#define C_COMPILE "#compile"

#define C_DEBUG_INFO "debug_info"
#define C_BINARY "binary"
#define C_MAP "map_file"
#define C_SYMBOLS "symbols"

#define C_ENABLE "enable"
#define C_DISABLE "disable"

#define C_START_COMMENT "/*"
#define C_END_COMMENT "*/"
#define C_DEFINE "#define"
#define C_UNDEFINE "#undef"
#define C_IFDEF "#ifdef"
#define C_IFNDEF "#ifndef"
#define C_ENDIF "#endif"

#define C_TYPE_VAR "VAR"
#define C_TYPE_CMD "CMD"
#define C_TYPE_SGN "SGN"
#define C_TYPE_EXT "EXT"
#define C_TYPE_DEF "DEF"
#define C_TYPE_STR "STR"
#define C_TYPE_FNC "FNC"
#define C_TYPE_ASM "ASM"

#endif //__SCRIPT

void SYS_Error(char *em,char *en);
