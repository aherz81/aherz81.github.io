#ifndef __VM_ASM
#define __VM_ASM

enum OPCODE
{
	val,vah,vax,veax,
	vbl,vbh,vbx,vebx,
	vcl,vch,vcx,vecx,
	vdl,vdh,vdx,vedx,
	vbp,vebp,
	vsi,vesi,
	vdi,vedi,
	vip,veip,
	vsp,vesp,
	vdata,
	vvip,
	num_regs,
	vand,
	vadd,
	vcall,
	vcmp,
	vdiv,
	vjmp,
	vmov,
	vmul,
	vneg,
	vnot,
	vor,
	vpop,
	vpush,
	vret,
	vext,
	vnext,
	vsub,
	fadd,
	fsub,
	fdiv,
	fmul,
	fcmp,
	je,
	jne,
	jg,
	jnle,
	jge,
	jnl,
	jl,
	jnge,
	jle,
	jng,
	vend,
	num_opcodes,
	radd,			//'+'
	rmul,			//'*'
	rsub,			//'-'
	iopen,			//'['
	iclose,			//']'
	rsep,
	cst,
	bltof,			//convert types to float
	itof,
	wtof,
	bytof,
	dwtof,
	ctof,
	stof,
	ftobl,			//convert float to type
	ftoi,
	ftow,
	ftoby,
	ftodw,
	ftoc,
	ftos,
	inc,
	dec,
	finc,
	fdec,
	texbegin,
	blend,
	tcmod,
	texend,
	tcgen,
	flush,
	cull,
	depth,
	pushn
};


#endif