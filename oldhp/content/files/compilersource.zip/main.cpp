/***********************************************************************
	Name: 			main.cpp
	Project:		ScriptC
	Description:	main file 
	
� 1999 SoftCore/Alex Herz - All rights reserved

	Programmer:	Alex
	Current Version:	1.0

	Update History:
	Programmers Initials	Date	Change Made	Version
	
	Alex					12.4.99 Initial Revision
***********************************************************************/
#pragma optimize( "", on )
#pragma warning( disable : 4244 )

#define MAX_CHAR_LEN 255


#include "compiler.h"
#include "symbols.h"

#define _DEBUG

extern int C_Output_Map;
extern int C_Output_Binary;
extern int C_Output_DebugInfo;
extern int C_Output_Symbols;

HWND        hwnd=NULL;
//WindowHandle
HDC hdc;
HPEN hpen, hpenOld;
PAINTSTRUCT ps;
RECT rect,orect;
int width;
HFONT hfont;

FILE * Log;

bool warning=0;

char TTF[30]="arial";
//char TTF[30]="newtown";
//char TTF[30]="system";
BYTE r,g,b;

char ScreenBuffer[200][200];
BYTE colr[200];
BYTE colg[200];
BYTE colb[200];
int Lines=0;

void SYS_ProcessMessages()
{
	MSG msg;
	PeekMessage( &msg, NULL, 0, 0, PM_REMOVE );
	TranslateMessage(&msg);
	DispatchMessage(&msg);
	
}

void SYS_SetWinSize(int xs,int ys)
{
	SetWindowPos(hwnd,HWND_TOPMOST,0,0,xs,ys,SWP_SHOWWINDOW);
}

void SYS_WriteText(char * Text)
{
	Lines++;
	while(!Log)Log=fopen("compiler.log","a+");	
	fprintf(Log,"%s\n",Text);
	fflush(Log);
	fclose(Log);
	Log=NULL;
	char txt[255]="";
	sprintf(txt,"%s\n",Text);
	OutputDebugString(txt);
}

int SYS_TextOut( const char *fmt, ... ) 
{
//    static short tmpTex[256*256];
    int rv = 0;
	int consoleX=0;
    va_list argptr;
	char Text[255]="";

        static char buffer[1024];
        const char *c;

        va_start( argptr, fmt );
        rv = vsprintf( buffer, fmt, argptr );
        va_end( argptr );

//        strupr( buffer );
        
        c = buffer;

        /* update console grid */
       while( *c &&consoleX<255) 
	   {
            switch( *c ) 
			{
				case '\n':
				 	SYS_WriteText(Text);
					consoleX=0;
					Text[consoleX]=(char)0;
					break;
				case '#':
					Text[consoleX]=' ';
					consoleX++;
					break;
				default:
					if(consoleX>=255)
					{
						Text[255]=0;
					 	SYS_WriteText(Text);
						return rv;
					}
					Text[consoleX]=*c;
					Text[consoleX+1]=(char)0;
					consoleX++;
					break;
            }
            c++;
        }
 	SYS_WriteText(Text);
    return rv;
}


void SYS_ClearScreenBuffer()
{
	Lines=0;
}

int SYS_DrawTexttoWindow(char * Text,int x, int y,int width)
{
	rect.left=x;
	rect.top=y;
	int w=DrawText(hdc,Text,-1,&rect,DT_TOP | DT_LEFT | DT_SINGLELINE);
	if(rect.top>rect.bottom-width*2)
	{
		for(int i=0;i<((orect.bottom-orect.top)/width)-1;i++)
		{
			colr[i]=colr[i+1];
			colg[i]=colg[i+1];
			colb[i]=colb[i+1];
			sprintf(ScreenBuffer[i],"%s",ScreenBuffer[i+1]);
			ScreenBuffer[i][strlen(ScreenBuffer[i+1])]=(char)0;
		}
		Lines--;
	}
	return w;
//	ShowWindow(hwnd, nCmdShow);


}


long WINAPI WndProc(HWND hwnd,UINT message, UINT wParam, LONG lParam) 
{

	switch(message)
	{
		case WM_PAINT:
/*			hdc=BeginPaint(hwnd,&ps);
			GetClientRect(hwnd,&rect);
			orect=rect;
			hfont=CreateFont( 15, 8, 0, 0, 700, 0, 0, 0, DEFAULT_CHARSET, OUT_TT_PRECIS 
				, CLIP_CHARACTER_PRECIS, DRAFT_QUALITY   , DEFAULT_PITCH | TMPF_TRUETYPE  | FF_DECORATIVE   
				, TTF );
			SelectObject(hdc,hfont);
			SetBkMode(hdc, TRANSPARENT );

			width=0;
			int i;
			for(i=0;i<Lines;i++)
			{
				//strupr(ScreenBuffer[i]);
				SetTextColor(hdc,RGB(colr[i],colg[i],colb[i]));
				width=SYS_DrawTexttoWindow(ScreenBuffer[i],2,i*width,width);
			}
			DeleteObject(hfont);
			EndPaint(hwnd,&ps);
			UpdateWindow(hwnd);
*/			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		case WM_ACTIVATE:
			UpdateWindow(hwnd);
			RedrawWindow(hwnd,NULL,NULL,RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE );
			SYS_ProcessMessages();
			break;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}




void SYS_InitWindow(HINSTANCE hInstance, int nCmdShow, char szAppName[],int SizeX, int SizeY)
{
	WNDCLASS    wndclass;
	HBRUSH hbrush;
	hbrush=CreateSolidBrush( RGB(225,225,225) );

	r=10;
	g=10;
	b=10;

        wndclass.style         = CS_HREDRAW | CS_VREDRAW;
        wndclass.lpfnWndProc   = WndProc;
        wndclass.cbClsExtra    = 0;
        wndclass.cbWndExtra    = 0;
        wndclass.hInstance     = hInstance;
        wndclass.hIcon         = NULL;
        wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
        wndclass.hbrBackground = NULL;
        wndclass.lpszMenuName  = NULL;
        wndclass.lpszClassName = szAppName;

        RegisterClass(&wndclass);
    

     hwnd = CreateWindowEx(WS_EX_OVERLAPPEDWINDOW,//WS_EX_TOPMOST
                            szAppName, 
                            szAppName,
                            WS_POPUP,
							//WS_OVERLAPPEDWINDOW,
                            0, 0,
                            //400,
							SizeX,
                            //400,
							SizeY,
                            NULL,
                            NULL,
                            hInstance,
                            NULL);

 
//	ShowWindow(hwnd, nCmdShow);
//  UpdateWindow(hwnd);
}


int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nShowCmd)
{
	char outn[255]="";
	Log=fopen("compiler.log","wt");
	fclose(Log);
	Log=NULL;
	SYS_InitWindow(hInstance, nShowCmd,"Sov. ScriptCompiler (c) 1999-2002 Alex Herz",800, 400);
	SYS_ProcessMessages();
	SYS_TextOut("Source:'%s'",lpCmdLine);
//	if(!strcmp(lpCmdLine,""))SYS_Error("Invalid source file :"");
	if(strlen(lpCmdLine)<4)exit(0);
	FILE * source_f=fopen(lpCmdLine,"r+t");
	if(!source_f)
	{
		SYS_TextOut("unable to open '%s'",lpCmdLine);
		exit(0);
	}
	char * str=lpCmdLine;
	char target[MAX_CHAR_LEN]="";
	int i=0;
	do
	{
		target[i]=*str;
		str++;
		i++;
	}
	while(*str!='.'&&i<MAX_CHAR_LEN);
	sprintf(outn,"%s",target);
	sprintf(target,"%s%s%c",target,".obj",(char)0);
//	SYS_TextOut("Target:'%s'",target);

	FILE * target_f=fopen(target,"w+b");
	if(!target_f)SYS_Error("Couldn't open ",target);
//	SYS_TextOut(" - opened\n");


	C_SetScr_Trg(source_f,lpCmdLine,target_f);
	SYS_TextOut("Compiling ...\n");
	SYS_TextOut("1st pass -> parsing symbols\n");
	bool err=0;
	if(C_Compile(lpCmdLine))err=1;//parse symbols+ add types

	if(!C_Output_Binary)
	{
		C_CreateError("file is not binary, enable #pragma binary to solve this!\n");
		err=1;
		SYS_Error("","");
	}

	fclose(source_f);

	if(C_Output_Map&&!err)
	{
		SYS_TextOut("Generating Mapfile ...");
		sprintf(target,"%s%s%c",outn,".map",(char)0);
		target_f=fopen(target,"w+b");
		if(!target_f)SYS_Error("Couldn't open ",target);
		
		C_SetScr_Trg(NULL,target,target_f);
		C_WriteMapFile();
	
		SYS_TextOut(" - done\n");
	}
	
	char* sss=strchr(target,'.');
	sprintf(sss,".vsm%c",0);
	source_f=fopen(target,"wb");
	if(!source_f)SYS_Error("Couldn't open ",target);
	fseek(target_f,0,SEEK_SET);
	P_TranslateBES(target_f,target,source_f);
	extern WORD C_Error;
	extern WORD C_Warnings;
	SYS_TextOut("\n%d error(s), %d warning(s)",C_Error,C_Warnings);
	C_FreeCommands();
	fclose(target_f);
	fclose(source_f);
	return C_Error;
}