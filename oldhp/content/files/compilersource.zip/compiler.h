#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <commdlg.h>
#include <stdarg.h>

#include <winbase.h>
#include <winuser.h>

#include <mmsystem.h>
#include <math.h>

float C_GetCompilerVer();

void C_SetScr_Trg(FILE*src,char*name,FILE*trg);

bool C_Compile(char* sn);

void C_WriteMapFile();

void C_FreeCommands();

bool C_CheckC_Option(char * co);

int SYS_TextOut( const char *fmt, ... ) ;

DWORD GetId(char* cn);

void C_CreateError(char*em);

void P_TranslateBES(FILE* bes,char* sn,FILE* out);

bool C_CInclude(char* sn);

#define __SOV_SCRIPT_COMPILER_VER 4.00f
#define MAX_CHAR_LEN 255
#define __MAX_COMMANDS 65537
