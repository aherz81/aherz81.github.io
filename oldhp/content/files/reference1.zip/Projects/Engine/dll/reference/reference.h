#ifndef REF
#define REF

//pas this to type DLLInterface_ReturnControl
typedef void(__cdecl*void_ret_dword)(DWORD dw);
//void DLLInterface_ReturnControl(void_ret_dword func);
//*/
/*

//renderer test..
		float a[4]={0,0,0,0};
	__SAVEDLLINSTALL(DLL_NAME,"renderer.dll",a);
	__DLLRUN("renderer.dll");

	__GETCMD(R_LOADLEV,&loadlev);
	__GETCMD(R_SETDEVICE,&setdevice);
	__GETCMD(R_LOCKDEVICE,&lockdevice);
	__GETCMD(R_UPDATEVIEWVEC,&updviewvec);

	__EOP();//push exit flag to fifo
	__CLEANFIFO();//remove all args(till next exit flag) from fifo

static OctLeaf BaseLeaf;//gotta be static so that it stays here after we left this func
static Mat* Mats;
	DWORD num_mats=0;

	__LOADLEV("ase2lev\\house.lev",&BaseLeaf,&Mats,&num_mats);

//	QObject *rQO=InitStandartWindow(dQO,"RenderWnd","Renderer",0,1,1,1,&MsgHandler,0.08,1);
//	QRC*rw=InitStandartRC(rQO,"RenderWindow",0.02,0.012,0.96,0.97,&BaseLeaf,Mats,1,WndProc);//add another dll to window
	QRC*rw=InitStandartRC(Desktop,"RenderWindow",0,0,1,1,&BaseLeaf,Mats,1,WndProc);//add another dll to window
//	InitStandartButton(rw,0,"Button03","ButtonButtonButton",0.15,0.8,0.7,0.1,&MsgHandler,0.13);
	rw->hRC->camera.Pos[1]=-125;
	rw->hRC->camera.Pos[2]=-25;
	rw->hRC->cr=0.001f;
	rw->hRC->cg=0.001f;
	rw->hRC->cb=0.001f;
	rw->hRC->camera.Rot[0]=X;
	rw->hRC->camera.Rot[1]=Y;
	rw->hRC->camera.farclip=400;
	ShowCursor(0);
	GetCursorPos(&CP);
//	__GETEVENTUPDATE(rw->hRC,FocusProc);	
//*/

#endif