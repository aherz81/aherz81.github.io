/*ScripEdit*/

  #pragma enable debug_info

  #define _ALLIGN DWORD

//include_file_insert_pos
//#include "header\defs.h"


//script_file_insert_pos
#compile "source\test.c"


