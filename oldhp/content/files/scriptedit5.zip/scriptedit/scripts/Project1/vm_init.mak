/*ScripEdit*/

  #pragma enable debug_info

  #define _ALLIGN DWORD

//include_file_insert_pos
//#include "header\wsock.h"

//#include "header\server.h"

//#include "header\memory.h"

//#include "header\importer.h"

//#include "header\error.h"

//#include "header\defs.h"


//script_file_insert_pos
#compile "source\wsock.c"

#compile "source\test.c"


