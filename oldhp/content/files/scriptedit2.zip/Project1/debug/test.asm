<Header Section>
Compiler Version: 5.100000, Debug Info: 1
<Code Section>
0: jmp const 4988 
112: mov data , const 112 
144: sne 
160: mov reg1 , const 1066192077 
192: mov reg2 , const 0 
224: mov [ reg2 ] , reg1 
260: mov reg1 , const 1634492780 
292: mov [ const 24 ] , reg1 
332: mov reg1 , const 24940 
364: mov [ const 28 ] , reg1 
404: mov reg1 , const 24 
436: mov [ const 32 ] , reg1 
476: mov reg1 , const 1634492780 
508: mov [ const 36 ] , reg1 
548: mov reg1 , const 3301740 
580: mov [ const 40 ] , reg1 
620: mov reg1 , const 24940 
652: mov [ const 44 ] , reg1 
692: mov reg1 , const 36 
724: mov [ const 48 ] , reg1 
764: mov reg1 , const 1734963791 
796: mov [ const 52 ] , reg1 
836: mov reg1 , const 1818324585 
868: mov [ const 56 ] , reg1 
908: mov reg1 , const 976380960 
940: mov [ const 60 ] , reg1 
980: mov reg1 , const 25637 
1012: mov [ const * 67 , reg1 
1052: mov reg1 , const 52 
1084: mov [ const 68 ] , reg1 
1124: mov reg1 , const 544695630 
1156: mov [ const 72 ] , reg1 
1196: mov reg1 , const 1630024292 
1228: mov [ const 76 ] , reg1 
1268: mov reg1 , const 1919251558 
1300: mov [ const 80 ] , reg1 
1340: mov reg1 , const 1836016416 
1372: mov [ const 84 ] , reg1 
1412: mov reg1 , const 1769103728 
1444: mov [ const 88 ] , reg1 
1484: mov reg1 , const 544108403 
1516: mov [ const 92 ] , reg1 
1556: mov reg1 , const 941649780 
1588: mov [ const 96 ] , reg1 
1628: mov reg1 , const 1680161321 
1660: mov [ const 100 ] , reg1 
1700: mov reg1 , const 25600 
1732: mov [ const 104 ] , reg1 
1772: mov reg1 , const 72 
1804: mov [ const 108 ] , reg1 
1844: ret 
1860: mov reg1 , data 
source\test.c(52)
1888: sne 
1904: add data , const 4 
1936: mov reg2 , const 10 
1968: neg reg2 
1988: mov reg3 , reg1 + const 0 
2028: mov [ reg3 ] , reg2 
2064: sne 
source\test.c(54)
2080: mov data , reg1 
2108: ret 
2124: mov reg1 , data 
source\test.c(15)
2152: sne 
2168: add data , const 8 
2200: mov reg2 , const 0 
2232: mov reg3 , reg1 + const 4 
2272: mov [ reg3 ] , reg2 
2308: mov reg2 , const 8 
source\test.c(16)
2340: add reg2 , const 0 
2372: mov reg3 , const 32 
2404: mov reg3 , [ reg3 ] 
2440: mov [ reg2 ] , reg3 
2476: mov reg2 , const 8 
source\test.c(17)
2508: add reg2 , const 4 
2540: mov reg3 , const 16 
2572: mov reg3 , [ reg3 ] 
2608: mov [ reg2 ] , reg3 
2644: mov reg2 , const 8 
source\test.c(19)
2676: add reg2 , const 4 
2708: mov reg2 , [ reg2 ] 
2744: add reg2 , const 0 
2776: mov reg3 , const 48 
2808: mov reg3 , [ reg3 ] 
2844: mov [ reg2 ] , reg3 
2880: mov reg2 , const 8 
source\test.c(20)
2912: add reg2 , const 4 
2944: mov reg2 , [ reg2 ] 
2980: add reg2 , const 4 
3012: mov reg3 , const 0 
3044: mov [ reg2 ] , reg3 
3080: mov reg1 , const 0 
source\test.c(30)
3112: inc data 
3132: fcmp [ const 0 ] , const 1067030938 
3176: je const 3080 
3200: ret 
3216: mov reg2 , const 4 
source\test.c(33)
3248: mov reg3 , const 7 
3280: mov reg4 , const 2 
3312: mov reg5 , const 3 
3344: mov reg6 , const 10 
3376: mov reg7 , const 2 
3408: and reg3 , reg4 
3436: mul reg3 , reg5 
3464: add reg3 , reg6 
3492: div reg3 , reg7 
3520: mov [ reg2 ] , reg3 
3556: pushn reg1 , const 2 
source\test.c(34)
3588: mov reg2 , const 68 
3620: mov reg2 , [ reg2 ] 
3656: push reg2 
3676: mov reg2 , const 4 
3708: mov reg2 , [ reg2 ] 
3744: push reg2 
3764: se 
3780: call const 28 
3804: mov reg3 , reg1 
3832: sub data , const 8 
3864: pop reg1 , const 2 
3896: mov reg2 , reg3 
3924: mov reg2 , const 8 
source\test.c(35)
3956: mov reg3 , const 4 
3988: mov reg3 , [ reg3 ] 
4024: cmp reg3 , reg2 
4052: jne const 4132 
4076: mov reg3 , const 1 
4108: jmp const 4164 
4132: mov reg3 , const 0 
4164: mov reg2 , reg3 
4192: cmp reg2 , const 0 
4224: je const 4372 
source\test.c(39)
4248: mov reg3 , const 4 
source\test.c(37)
4280: mov reg4 , const 16 
4312: mov [ reg3 ] , reg4 
4348: jmp const 4508 
source\test.c(42)
4372: mov reg3 , const 4 
source\test.c(41)
4404: mov reg4 , const 188 
4436: mov reg4 , [ reg4 ] 
4472: mov [ reg3 ] , reg4 
4508: pushn reg1 , const 3 
source\test.c(45)
4540: mov reg2 , const 108 
4572: mov reg2 , [ reg2 ] 
4608: push reg2 
4628: mov reg2 , const 4 
4660: mov reg2 , [ reg2 ] 
4696: push reg2 
4716: call const 28 
4740: mov reg4 , reg1 
4768: sub data , const 8 
4800: pop reg1 , const 3 
4832: mov reg3 , reg4 
4860: sne 
source\test.c(47)
4876: mov data , reg1 
4904: mov reg1 , const 4 
4936: mov reg1 , [ reg1 ] 
4972: ret 
4988:  <Link Section>
	<Imports>
		__cdecl void printf(*char,?) @ 3788
		__mem DWORD style @ 4420
		__cdecl void printf(*char,?) @ 4724
	<Uses>
		global @ 304
		global @ 376
		global @ 420
		global @ 448
		global @ 520
		global @ 592
		global @ 664
		global @ 708
		global @ 736
		global @ 808
		global @ 880
		global @ 952
		global @ 1024
		global @ 1068
		global @ 1096
		global @ 1168
		global @ 1240
		global @ 1312
		global @ 1384
		global @ 1456
		global @ 1528
		global @ 1600
		global @ 1672
		global @ 1744
		global @ 1788
		global @ 1816
		global @ 2324
		global @ 2388
		global @ 2492
		global @ 2556
		global @ 2660
		global @ 2792
		global @ 2896
		global @ 3144
		global @ 3232
		global @ 3604
		global @ 3692
		global @ 3972
		global @ 4264
		global @ 4388
		global @ 4556
		global @ 4644
		global @ 4920
	<Exports>
		void TTT(*float) @ 1860
		DWORD Test() @ 2124
	<Info Section>
		test::dd @ 0
		test::nn @ 16
		test::ttt @ 32
		ILinkedList::Item @ 0
		ILinkedList::Next @ 16
		printf(0)::c @ -12
		printf(0)::?CompilerGeneratedID11435373 @ -8
		global(0)::dag @ 0
		global(0)::d2 @ 4
		global(0)::style @ 0
		global(0)::il @ 8
		global(0)::il2 @ 16
		TTT(0)::bb @ -4
		string0 @ 32
		string1 @ 48
		Test(1)::dd @ 0
		string2 @ 68
		Test(1)::chp @ 4
		string3 @ 108
		TTT(1)::d2 @ 0
<End>