#ifndef RENDERER
#define RENDERER

#include <windows.h>
//#include <math.h>
#include <stdlib.h>
#include "..\pnpdll0005.h"

#include "anim.h"
#include "beam.h"
#include "mat.h"

enum geo_type
{
	LOAD,		//still has to be loaded
	NO_BSP,		//prog mesh algo (small trias with slightly changing angles)
	BSP,			//bsp/portal/anti portal(beam tree) (bigger trias connected with sharp angles)
};

struct _TexChange
{
	DWORD index;
	DWORD texid;
};

struct BspLeaf
{
	float bb[2][3];
	float e_bb[8][3];
	BspLeaf* Front;
	BspLeaf* Back;
	BspLeaf* Parent;
	tria* SurfList;
	DWORD surfs;
	DWORD* IndexList;
	DWORD ILLen;
	DWORD* SplitList;
	DWORD SPLen;
	float *norm;//normal of the splitplane
	float *point;//one point on the splitplane
};

struct OctLeaf
{
	float bb[2][3];
	float e_bb[8][3];
	OctLeaf *childs;
	DWORD num_childs;
	OctLeaf *parent;
	DWORD points;
	DWORD surfs;

	geo_type gt;

	float norm[3];
	float error;
	float point[3];
	float size;
	float* VertexList;
	BYTE* ColorList;
	float* ReflList;
	float* NormList;
	float* TexList;
	DWORD* IndexList;
	DWORD ILLen;
	_TexChange* TexChange;
	DWORD TCLen;
	edge_* EdgeList;
	tria*  SurfList;
	BspLeaf* bsp;
	DWORD offset;//offset in file
};

struct Mat
{
	float Alpha;
	float Reflection[3];
	char FileName[100];
	char MatName[100];
	char AlphaName[100];
	int ID;
	float X_Tile,Y_Tile;
};

struct Mats_
{
	Mat Materials[2000];
	int Num_materials;
};

typedef OctLeaf*(__cdecl*request_node)	(DWORD id);

void __cdecl InitShaderSystem();
void __cdecl UnloadShaderSystem();
void __cdecl TexEnd();
void __cdecl TexFlush();
void __cdecl TexTCMOD();
void __cdecl TexTCGEN();
void __cdecl TexBegin(DWORD id);
void __cdecl LoadLev(char*fn,OctLeaf*ol,Mat** Mats,DWORD* num_mats);
bool __cdecl SetDevice(RenderClient *rc,OctLeaf*data,Mat* mats);
bool __cdecl LockDevice(char*id);
bool __cdecl UnlockDevice(char*id);
void __cdecl Render(bool* update);
void __cdecl UpdateViewVector();
void __cdecl CloseRender();


#endif

