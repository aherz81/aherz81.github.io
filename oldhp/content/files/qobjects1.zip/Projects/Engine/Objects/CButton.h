#ifndef __CBUTTON
#define __CBUTTON

#include "CObject.h"

enum QButtonState
{
	UP=0,
	DOWN=1,
	GRAYED=2
};

class QButton : public QObject
{
public:
	BYTE state;
	float textcolor[3];
	char* Text;
	float x,y,textsize;
	EventHandler* uEV;
	bool EventHandlerInited;
	DWORD TexId;
	QButton();
	~QButton();
	bool b1;
	bool b2;
	virtual void Init(QO_Init* pInit);
};
QButton* InitStandartButton(QObject* father,char*name,char*text,float x,float y,float xs,float ys,EventHandler*ev,float ts);

bool QButtonMsgProc(bool mouse_pos,int mx,int my,bool b1,bool b2,bool key,BYTE state,void *data);


#endif