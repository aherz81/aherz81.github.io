#include "CButton.h"

void DeleteQButton(void* qo)
{
	delete (QButton*)qo;
}

QButton::QButton()
{
	SetClassName("QButton");
	b1=0;
	b2=0;
	state=GRAYED;
	textcolor[0]=0;
	textcolor[1]=0;
	textcolor[2]=0;
	textsize=0;
	x=0;
	y=0;
	EventHandlerInited=0;
	TexId=__TEXLOAD("textures\\objects\\button.tga",TGA);
	Delete=DeleteQButton;
}

QButton::~QButton()
{
	__TEXEREASE(TexId);
	free(Text);
	__DELEVENTUPDATE(Settings.MsgProc);
	if(hEV)delete hEV;
	if(hRC)
		__DELETEWINDOW(hRC->number);
}

bool QButtonMsgProc(bool mouse_pos,int mx,int my,bool b1,bool b2,bool key,BYTE state,void *data)
{
	QButton *hQB=(QButton*)data;
	EventHandler *hEV=hQB->hEV;
	if(state==2)
	{
		if(hQB->uEV)hQB->uEV->Push(2,hQB,MOUSE_LEFT);
	}
	else if(state==1)
	{
		if(hQB->uEV)hQB->uEV->Push(2,hQB,MOUSE_OVER);
	}
	if(mouse_pos)
	{
		if(hQB->uEV)hQB->uEV->Push(4,hQB,MOUSE_MOVE,mx,my);//notify user
	}
	if(hQB->state!=GRAYED)
	{		
		if(b1!=hQB->b1)
		{
			if(b1)
			{
				hEV->Push(1,MOUSE_LEFT_BUTTON_DOWN);
				if(hQB->uEV)hQB->uEV->Push(2,hQB,MOUSE_LEFT_BUTTON_DOWN);
			}
			else
			{
				hEV->Push(1,MOUSE_LEFT_BUTTON_UP);
				if(hQB->uEV)hQB->uEV->Push(2,hQB,MOUSE_LEFT_BUTTON_UP);
			}
			hQB->b1=b1;
		}
		if(b2!=hQB->b2)
		{
			if(b2)
			{
				if(hQB->uEV)hQB->uEV->Push(2,hQB,MOUSE_RIGHT_BUTTON_DOWN);
			}
			else
			{
				if(hQB->uEV)hQB->uEV->Push(2,hQB,MOUSE_RIGHT_BUTTON_UP);
			}
			hQB->b2=b2;
		}
	}
	return 0;
}

void QButtonWndProc(int*updates,void* data,Camera_*cam,RenderClient *hRC)
{
	QButton *hQB=(QButton*)data;
	void* Data=hQB->hEV->Pop();
	while(Data)
	{
		switch(*((DWORD*)Data))
		{
		case MOUSE_LEFT_BUTTON_DOWN:
			hQB->Draw();
			hQB->state=DOWN;
			break;
		case MOUSE_LEFT_BUTTON_UP:
			hQB->Draw();
			hQB->state=UP;
			break;
		default:
			break;
		}
		Data=hQB->hEV->Pop();
	}
}

void QButtonDrawProc(int*updates,void* data,Camera_*cam,RenderClient *hRC)
{
	QButton *hQB=(QButton*)data;

	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();
	glScalef (1, -1, -1);//left hand system
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	glScalef (1, -1*cam->aspect, -1);//left hand system
	glDepthFunc(GL_ALWAYS);
	DWORD ButtonDecal=hQB->TexId;
	if(hQB->state==UP)
	{
		((drawquad)(*Rasterizer,ButtonDecal,-1,-1/cam->aspect,2,1/cam->aspect*2,1,hQB->Settings.bkcolor[0],hQB->Settings.bkcolor[1],hQB->Settings.bkcolor[2],1,1));	//draw background(fixed tex pos)
		((drawtext)(*Rasterizer,hQB->Text,hQB->x,hQB->y,hQB->textsize,1,0,0,0,1,1));
	}
	else if(hQB->state==DOWN)
	{
		((drawquad)(*Rasterizer,ButtonDecal,-1,-1/cam->aspect,2,1/cam->aspect*2,1,hQB->Settings.bkcolor[0],hQB->Settings.bkcolor[1],hQB->Settings.bkcolor[2],0.4,1));	//draw background(fixed tex pos)
		((drawtext)(*Rasterizer,hQB->Text,hQB->x,hQB->y,hQB->textsize*0.98f,1,0,0,0,1,1));
	}
	else
	{
		((drawquad)(*Rasterizer,ButtonDecal,-1,-1/cam->aspect,2,1/cam->aspect*2,1,hQB->Settings.bkcolor[0]/1.7f,hQB->Settings.bkcolor[1]/1.7f,hQB->Settings.bkcolor[2]/1.7f,1,1));	//draw background(fixed tex pos)
		((drawtext)(*Rasterizer,hQB->Text,hQB->x,hQB->y,hQB->textsize,1,0,0,0,1,1));
	}

	glDepthFunc(GL_LEQUAL);

	
	gluPerspective(cam->fov, cam->aspect, cam->nearclip, cam->farclip);
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();
}

QButton* InitStandartButton(QObject* father,char*name,char*text,float x,float y,float xs,float ys,EventHandler*ev,float ts)
{
	QButton* hQB=new QButton;
	QO_Init qi;
	qi.bkcolor[0]=1;
	qi.bkcolor[1]=1;
	qi.bkcolor[2]=1;
	qi.DrawProc=NULL;
	qi.MsgProc=NULL;
	qi.WndProc=NULL;
	if(father)
	{
		qi.father=(char*)malloc(strlen(father->Settings.name)+1);
		sprintf(qi.father,father->Settings.name);
	}
	else qi.father=NULL;
	hQB->Parent=father;
//	qi.childs=num_childs;
	qi.name=(char*)malloc(strlen(name)+1);
	sprintf(qi.name,name);
	qi.uEV=ev;
	qi.wndsize[0]=x;
	qi.wndsize[1]=y;
	qi.wndsize[2]=xs;
	qi.wndsize[3]=ys;
	hQB->state=UP;
	hQB->textcolor[0]=1.0;
	hQB->textcolor[1]=1.0;
	hQB->textcolor[2]=1.0;
	hQB->textsize=ts;
	hQB->Text=(char*)malloc(strlen(text)+1);
	sprintf(hQB->Text,text);
	hQB->x=-((strlen(text)-1)*hQB->textsize)/2.5f;
	hQB->y=-hQB->textsize/2.f;
	if(father)father->AddObject(hQB);
	hQB->Init(&qi);
	return hQB;
}


void QButton::Init(QO_Init* pInit)
{
	if(!pInit->uEV)return;

	float _a[4]={0,0,1,1};

	if(pInit->father)((getclientarea)(*Importer,pInit->father,_a));
	//calc area
	_a[0]+=_a[2]*pInit->wndsize[0];
	_a[1]+=_a[3]*pInit->wndsize[1];
	_a[2]*=pInit->wndsize[2];
	_a[3]*=pInit->wndsize[3];
	memcpy(pInit->wndsize,_a,sizeof(float)*4);

	memcpy(Settings.wndsize,pInit->wndsize,sizeof(float)*4);
	memcpy(&Settings,pInit,sizeof(QO_Init));
	Settings.name=pInit->name;
	Settings.father=pInit->father;
	uEV=pInit->uEV;
	if(!Settings.WndProc)Settings.WndProc=QButtonWndProc;
	if(!Settings.DrawProc)Settings.DrawProc=QButtonDrawProc;
	hRC=(RenderClient*)this;
//	Childs=(QObject**)malloc(sizeof(QObject*)*(pInit->childs+1));
//	max_childs=pInit->childs+1;

	__EOP();
	__CLEANFIFO();
	
	((registerobject)(*Importer,Settings.name,Settings.wndsize,this));
	if(Settings.name)
		__GETWINDOW(Settings.WndProc,__CALLBACK_VOID,Settings.name
		,0,0,1,1,0,0,0
		,&hRC);

	__EOP();
	__CLEANFIFO();

	if(!EventHandlerInited)//init
	{
		if(!Settings.MsgProc)Settings.MsgProc=QButtonMsgProc;
		__GETEVENTUPDATE(hRC,Settings.MsgProc);
		hRC->RenderWindow=Settings.DrawProc;
		EventHandlerInited=1;
	}

	hEV=new EventHandler;
}