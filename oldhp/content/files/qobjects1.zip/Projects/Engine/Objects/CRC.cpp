#include "CRC.h"
#include "..\dll\renderer\rendereri.h"

void DeleteQRC(void* qo)
{
	delete (QRC*)qo;
}

QRC::QRC()
{
	SetClassName("QRC");
	Delete=DeleteQRC;
	locked=0;
	data=NULL;
	mats=NULL;
}

QRC::~QRC()
{
	if(hRC)
		__DELETEWINDOW(hRC->number);
}

void QRCWndProc(int*updates,void* data,Camera_*cam,RenderClient *hRC)
{
	*updates=2;
}

void QRCDrawProc(int*updates,void* data,Camera_*cam,RenderClient *hRC)
{
	QRC* rc=(QRC*)data;
	if(!rc->data||!rc->mats)return;
	bool OwnDevice=1;
	if(!rc->locked)	
		OwnDevice=__SETDEVICE(hRC,rc->data,rc->mats);
	if(OwnDevice)
		__RENDER(updates);
	else
	{
		glMatrixMode( GL_MODELVIEW );
		glPushMatrix();
		glLoadIdentity();
		glScalef (1, -1, -1);//left hand system
		glMatrixMode( GL_PROJECTION );
		glPushMatrix();
		glLoadIdentity();
		glScalef (1, -1*cam->aspect, -1);//left hand system
		glDepthFunc(GL_ALWAYS);

		((drawquad)(*Rasterizer,43,-1,-1/cam->aspect,2,1/cam->aspect*2,1,0,0,0,1,1));	//draw background(fixed tex pos)
		((drawtext)(*Rasterizer,"Device locked",-0.9,-0.05,0.2,1,1,1,1,1,1));

		glDepthFunc(GL_LEQUAL);
		gluPerspective(cam->fov, cam->aspect, cam->nearclip, cam->farclip);
		glPopMatrix();
		glMatrixMode( GL_MODELVIEW );
		glPopMatrix();
		
	}
}

QRC* InitStandartRC(QObject* father,char*name,float x,float y,float xs,float ys,OctLeaf*ol,Mat*mat,bool lock,_WndProc upd)
{
	QRC* hQB=new QRC;
	QO_Init qi;
	qi.bkcolor[0]=0;
	qi.bkcolor[1]=0;
	qi.bkcolor[2]=0;
	qi.DrawProc=NULL;
	qi.MsgProc=NULL;
	qi.WndProc=upd;
	if(father)
	{
		qi.father=(char*)malloc(strlen(father->Settings.name)+1);
		sprintf(qi.father,father->Settings.name);
	}
	else qi.father=NULL;
	hQB->Parent=father;
//	qi.childs=0;
	qi.name=(char*)malloc(strlen(name)+1);
	sprintf(qi.name,name);
	qi.uEV=NULL;
	qi.wndsize[0]=x;
	qi.wndsize[1]=y;
	qi.wndsize[2]=xs;
	qi.wndsize[3]=ys;
	if(father)father->AddObject(hQB);
	hQB->Init(&qi);
	hQB->data=ol;
	hQB->mats=mat;
	hQB->locked=lock;
	if(lock)
	{
		__SETDEVICE(hQB->hRC,ol,mat);
		__LOCKDEVICE(name);
	}
	hQB->hRC->camera.Rot[0]=X;
	hQB->hRC->camera.Rot[1]=Y;
	hQB->hRC->camera.Rot[2]=Z;

	hQB->hRC->camera.Angle[0]=0;
	hQB->hRC->camera.Angle[1]=0;
	hQB->hRC->camera.Angle[2]=0;
	__UPDVIEWVEC();
	return hQB;
}


void QRC::Init(QO_Init* pInit)
{
	float _a[4]={0,0,1,1};

	if(pInit->father)((getclientarea)(*Importer,pInit->father,_a));
	//calc area
	_a[0]+=_a[2]*pInit->wndsize[0];
	_a[1]+=_a[3]*pInit->wndsize[1];
	_a[2]*=pInit->wndsize[2];
	_a[3]*=pInit->wndsize[3];
	memcpy(pInit->wndsize,_a,sizeof(float)*4);

	memcpy(Settings.wndsize,pInit->wndsize,sizeof(float)*4);
	memcpy(&Settings,pInit,sizeof(QO_Init));
	Settings.name=pInit->name;
	Settings.father=pInit->father;
	if(!Settings.WndProc)Settings.WndProc=QRCWndProc;
	if(!Settings.DrawProc)Settings.DrawProc=QRCDrawProc;
	hRC=(RenderClient*)this;

	__EOP();
	__CLEANFIFO();
	
	((registerobject)(*Importer,Settings.name,Settings.wndsize,this));
	if(Settings.name)
		__GETWINDOW(Settings.WndProc,Settings.DrawProc,Settings.name
		,0,0,1,1,0,0,0
		,&hRC);

	__GETCMD(R_RENDER,&render);

	__EOP();
	__CLEANFIFO();

}