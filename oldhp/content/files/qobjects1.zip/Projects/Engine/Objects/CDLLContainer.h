#ifndef __CDLLCONTAINER
#define __CDLLCONTAINER

#include "CObject.h"

class QDLLContainer : public QObject
{
public:
	QDLLContainer();
	~QDLLContainer();
	char* DllName;
	virtual void Init(QO_Init* pInit);
	virtual void MoveTo(float x,float y);
	virtual void Move(float x,float y);
	virtual void Resize(float xp,float yp,float refx,float refy);
};

QDLLContainer* InitStandartDLLContainer(QObject* father,char*name,char* dll_name,float x,float y,float xs,float ys);

#endif