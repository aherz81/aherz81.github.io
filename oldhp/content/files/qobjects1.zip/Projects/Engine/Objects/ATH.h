#ifndef __ALEXTEMPLATEHEADER
#define __ALEXTEMPLATEHEADER

#include "..\dll\pnpdll0005.h"

template <class T> class ILinkedList
{
public:
	ILinkedList *Next;
	ILinkedList *Parent;
	DWORD Len;
	T *Item;
	ILinkedList(T* item,ILinkedList*parent);
	virtual void operator+=(T* item);	//add Item
	virtual void operator-=(T* item);	//remove Item
	virtual void operator!();			//clear list
	virtual T* operator~();				//access Item member

};

template <class T> ILinkedList<T>::ILinkedList(T* item,ILinkedList* parent) 
{
    Item=item;
	Parent=parent;
	Next=NULL;
};

template <class T>void ILinkedList<T>::operator!() 
{
	if(Next)
	{
		ILinkedList *Del=Next;
		Next=NULL;
		delete Del;
	}
}

template <class T>T* ILinkedList<T>::operator~()
{
	return Item;
}

template <class T>void ILinkedList<T>::operator+=(T* item) 
{
	ILinkedList* Actual=this;
	Len++;
	while(Actual->Next)    
		Actual=Actual->Next;
	Actual->Next=new ILinkedList<T>(item,Actual);
};

template <class T>void ILinkedList<T>::operator-=(T* item) 
{
	ILinkedList* Actual=this;
	Len--;

	while(Actual&&Actual->Item!=item)    
		Actual=Actual->Next;

	if(Actual)
	{
		if(Actual->Parent)
		{
			Actual->Parent->Next=Actual->Next;
			if(Actual->Next)
				Actual->Next->Parent=Actual->Parent;
			delete Actual;
		}
		else
		{
			ILinkedList* _Next=Next;
			Item=Next->Item;
			Next=Next->Next;
			delete _Next;
		}			
	}	
};

class IMem
{
protected:
	ILinkedList<void> *Items;
public:
	IMem();
	~IMem();
	template <class T> T* t_Alloc(T** item,unsigned int num =1)
	{
		T* data= (T*)malloc(sizeof(T)*num);
		(*Items)+=data;
		*item=(T*)data;
		return data;
	};
};

IMem::IMem()
{
	Items=new ILinkedList<void>((void*)this,NULL);
}

IMem::~IMem()
{
	ILinkedList<void>* Actual=Items->Next;
	while(Actual)
	{
		ILinkedList<void>* Actual_=Actual;
		Actual=Actual->Next;
		free (Actual_->Item);
	}
	!(*Items);
	delete Items;
}

struct MemInfo
{
	DWORD header;
	char* src_file;
	DWORD src_line;
	DWORD mem_size;
	BYTE* mem;
	bool check;
	DWORD footer;
};

class IProtectedMem
{
protected:
	ILinkedList<MemInfo> *Items;
public:
	bool _assert;
	bool _check;
	IProtectedMem(bool debug_check=0,bool debug_break=0)
	{
		_check=debug_check;
		_assert=debug_break;
		Items=new ILinkedList<MemInfo>((MemInfo*)this,NULL);
	}

	~IProtectedMem()
	{
		ILinkedList<MemInfo>* Actual=Items->Next;
		while(Actual)
		{
			ILinkedList<MemInfo>* Actual_=Actual;
			Actual=Actual->Next;
			t_Free(Actual_->Item->mem,Actual_->Item->check,Actual_->Item->check,_assert);
		}
		!(*Items);
		delete Items;
	}

	template <class T> T* t_Alloc(T** item,unsigned int num =1,bool check=0,char* src_file=NULL,DWORD src_line=0,bool log=0)
	{
		MemInfo* hMI=(MemInfo*)malloc(sizeof(MemInfo));
		if(!hMI)
		{
			_ASSERT(error);
			((error)(Server,"ATH::IProtectedMem < OUT OF MEM > failed to assign %d bytes to %s in line %d.",sizeof(MemInfo),__FILE__,__LINE__));
		}
		hMI->src_line=src_line;
		hMI->header=0xEFBEADDE;
		hMI->footer=0xEFBEADDE;
		hMI->mem_size=sizeof(T)*num;
		if(check)
		{
			hMI->check=1;
			if(src_file)
			{
				hMI->src_file=(char*)malloc(strlen(src_file)+1);
				if(!hMI->src_file)
				{
					_ASSERT(error);
					((error)(Server,"ATH::IProtectedMem < OUT OF MEM > failed to assign %d bytes to %s in line %d.",strlen(src_file)+1,__FILE__,__LINE__));
				}
				memcpy(hMI->src_file,src_file,strlen(src_file)+1);
			}
		}
		else hMI->check=0;
		static char unknown[10]="unknown";
		if(!src_file)hMI->src_file=unknown;
		T* data=(T*)malloc(hMI->mem_size+check*8);
		if(!data)
		{
			_ASSERT(error);
			((error)(Server,"ATH::IProtectedMem < OUT OF MEM > failed to assign %d bytes to %s in line %d.",hMI->mem_size,hMI->src_file,hMI->src_line));
		}
		if(check)
		{
			*((DWORD*)data)=0xEFBEADDE;
			BYTE* pdata=(BYTE*)data; 
			pdata+=hMI->mem_size+4;
			DWORD* end=(DWORD*)pdata;
			*end=0xEFBEADDE;
		}
		hMI->mem=(BYTE*)(((DWORD*)data)+(check*1));
		(*Items)+=hMI;
		*item=(T*)(((DWORD*)data)+(check*1));
		if(check)
			memset(*item,0,hMI->mem_size);//zero out mem
		if(log)
		{
			_ASSERT(_log);
			((_log)(Server,"ATH::IProtectedMem < ALLOCATED > block 0x%x by %s in line %d size %d bytes.",hMI->mem+4,hMI->src_file,hMI->src_line,hMI->mem_size));
		}
		return *item;
	};

	MemInfo* t_Test(void* mem,bool check=0,bool _assert=0)
	{
		if(!mem&&check)
		{
			_ASSERT(_log);
			((_log)(Server,"ATH::IProtectedMem < INTEGRITY CHECK > of 0x%x.",this));
		}

		MemInfo* hMI=NULL;
		ILinkedList<MemInfo>* Actual=Items->Next;
		while(Actual)
		{
			ILinkedList<MemInfo>* Actual_=Actual;
			Actual=Actual->Next;
			if(Actual_->Item->mem==mem||!mem)
			{
				hMI=Actual_->Item;
				if((check||!mem)&&hMI->check)
				{
					if(hMI->header!=0xEFBEADDE||hMI->footer!=0xEFBEADDE)
					{
						_ASSERT(_log); if(Warnings)(*Warnings)++;
						((_log)(Server,"ATH::IProtectedMem < MEMINFO DAMAGED > of block 0x%x.",mem));
						if(_assert)_ASSERT(NULL);//debug break
						if(mem)return NULL;
					}
					if(*((DWORD*)hMI->mem)!=0xEFBEADDE)
					{
						_ASSERT(_log); if(Warnings)(*Warnings)++;
						((_log)(Server,"ATH::IProtectedMem < HEADER DAMAGED > of block 0x%x allocated by %s in line %d.",hMI->mem+4,hMI->src_file,hMI->src_line));
						if(_assert)_ASSERT(NULL);//debug break
					}
					if(*((DWORD*)(hMI->mem+hMI->mem_size+4))!=0xEFBEADDE)
					{
						_ASSERT(_log); if(Warnings)(*Warnings)++;
						((_log)(Server,"ATH::IProtectedMem < FOOTER DAMAGED > block 0x%x allocated by %s in line %d.",hMI->mem+4,hMI->src_file,hMI->src_line));
						if(_assert)_ASSERT(NULL);//debug break
					}
				}
				if(mem)return hMI;
			}
		}
		if(!mem&&check)
		{
			_ASSERT(_log);
			((_log)(Server,"ATH::IProtectedMem < END INTEGRITY CHECK > of 0x%x.",this));
		}
		return NULL;
	};

	void t_Free(void* mem,bool check=0,bool log=0,bool _assert_=0)
	{
		MemInfo* hMI=hMI=t_Test(mem,check,_assert_||_assert);
		if(!hMI)
		{
			_ASSERT(_log);
			((_log)(Server,"ATH::IProtectedMem < RELEASED FAILED > block 0x%x allocated by %s in line %d.",hMI->mem+4,hMI->src_file,hMI->src_line));
			return;
		}
		*Items-=hMI;
		free(((BYTE*)hMI->mem)-hMI->check*4);
		if(check)memset(hMI->mem,0x0DF0ADBA,hMI->mem_size+hMI->check*8);
		if(log)
		{
			_ASSERT(_log);
			((_log)(Server,"ATH::IProtectedMem < RELEASED > block 0x%x allocated by %s in line %d.",hMI->mem+4,hMI->src_file,hMI->src_line));
		}
		if(hMI->src_file&&hMI->check)free(hMI->src_file);
		free(hMI);
	};
};


template <class T> T* p_Alloc(IProtectedMem* IPMem,T** item,DWORD num=1,char* src_file=__FILE__,DWORD src_line=__LINE__) 
{
	if(IPMem->_check)
	{
		IPMem->t_Test(NULL);
		return IPMem->t_Alloc(item,num,1,src_file,src_line,1);
	}
	else return IPMem->t_Alloc(item,num); 
}

template <class T> void p_Free(IProtectedMem* IPMem,T* item) 
{
	if(IPMem->_check)
	{
		IPMem->t_Free(item,1,1,1);
		return;
	}
	else 
		IPMem->t_Free(item);
}

template <class T> void t_Swap( T& a, T& b )
{
    T c( a );
    a = b; b = c;
}

//guess what a fifo class
template <class T> class IFifo : public IMem
{
public:
	T* Fifo;
	T* F_sptr;
	T* F_eptr;
	bool ptr_xchg;
	DWORD IFifo_SIZE;

	IFifo(DWORD size);

	void Error(char *c);
	void Push(DWORD size,...);
	T* Pop();
	bool Empty();
};


template <class T>IFifo<T>::IFifo(DWORD size)
{
	IFifo_SIZE=size;
	t_Alloc(&Fifo,(IFifo_SIZE+1)*4);
	F_sptr=Fifo;
	F_eptr=F_sptr;
	ptr_xchg=0;
}

template <class T>void IFifo<T>::Error(char* c)
{
	MessageBox(NULL,c,"Error",MB_OK);
}

template <class T>void IFifo<T>::Push(DWORD size,...)
{
   va_list argptr;

	va_start( argptr, size );
	if(F_eptr+size>=Fifo+IFifo_SIZE)
	{
		F_eptr=Fifo;
		ptr_xchg=1-ptr_xchg;
		F_sptr=Fifo+IFifo_SIZE;
	}
	*((DWORD*)F_eptr)=size+1;
	F_eptr++;

	if(ptr_xchg)//check overflow
	{
		if(F_eptr>F_sptr)
			Error("Fifo overflow.");
	}
	else if(F_eptr<F_sptr)
		Error("Fifo overflow.");


	for(int i=0;i<size;i++)
	{
		T* dptr=(T*)argptr;
		memcpy(F_eptr,dptr,sizeof(T));
		va_arg( argptr , T );
		F_eptr++;

		if(ptr_xchg)//check overflow
		{
			if(F_eptr>F_sptr)
				Error("Fifo overflow.");
		}
		else if(F_eptr<F_sptr)
			Error("Fifo overflow.");
	}
    va_end( argptr );

}

template <class T>T* IFifo<T>::Pop()
{
	if(F_sptr==F_eptr)//IFifo empty
		return NULL;

	if(F_sptr>=Fifo+IFifo_SIZE)
	{
		F_sptr=Fifo;
		ptr_xchg=1-ptr_xchg;
	}

	T* ptr=(T*)(F_sptr+1);
	F_sptr+=*((DWORD*)F_sptr);

	return ptr;

}

template <class T>bool IFifo<T>::Empty()
{
	if(F_sptr==F_eptr)return 1;
	else return 0;
}

#endif