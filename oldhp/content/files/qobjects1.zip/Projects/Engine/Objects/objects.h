#ifndef __QOBJECTS_INCLUDE
#define __QOBJECTS_INCLUDE

#include "CObject.h"
#include "CButton.h"
#include "CDllContainer.h"
//#include "CRC.h"
#include "CWindow.h"

#endif //__QOBJECTS_INCLUDE