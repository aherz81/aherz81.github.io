#include "CObject.h"

void QObject::SetClassName(char*n)
{
	sprintf(ClassName,"%s%c",n,0);
}

void DeleteQObject(void* qo)
{
	delete (QObject*)qo;
}

QObject::QObject()
{
	SetClassName("QObject");
	hRC=NULL;
	hEV=NULL;
//	num_childs=0;
	Parent=NULL;
	Settings.father=NULL;
	Delete=DeleteQObject;
//	max_childs=0;
	mChilds=(QMem*)malloc(sizeof(QMem));
	mChilds->mem=NULL;
	mChilds->next=NULL;
	ObjectID=0;
	if(!movetotop)__GETCMD(CMD_MOVETOTOP,&movetotop);
}

QObject::~QObject()
{
	//cleanup
	if(Parent)
	{
		Parent->DelObject(this);
		Parent=NULL;
	}
	if(Settings.father)
	{
		free(Settings.father);
		Settings.father=NULL;
	}
/*
	for(DWORD d=0;d<num_childs;d++)
		if(Childs[d])
		{
			((Childs[d]->Delete)(Childs[d]));
			Childs[d]=NULL;
		}
	if(num_childs)
	{
		num_childs=0;
		free(Childs);
	}
*/
	QMem* qm=mChilds;
	while(qm)
	{
		if(qm&&qm->mem)
		{
			((((QObject*)qm->mem)->Delete)(((QObject*)qm->mem)));
			qm->mem=NULL;
		}
		qm=qm->next;
	}
	qm=mChilds;
	while(qm)
	{
		QMem* lqm=qm;
		qm=qm->next;
		free(lqm);
	}
}

void QObject::SetFocus()
{
	if(hRC)((movetotop)(Server,hRC->number));
	QMem* qm=mChilds;
	while(qm)
	{
		if(qm&&qm->mem)
			((QObject*)qm->mem)->SetFocus();
		qm=qm->next;
	}
}

void QObject::DisableWindow()
{
	QMem* qm=mChilds;
	while(qm)
	{
		if(qm&&qm->mem)
			((QObject*)qm->mem)->DisableWindow();
		qm=qm->next;
	}
/*
	for(DWORD d=0;d<num_childs;d++)
		if(Childs[d])
		{
			Childs[d]->DisableWindow();
		}
*/
	if(hRC)
	{
		Settings.DrawProc=hRC->RenderWindow;
		Settings.WndProc=hRC->UpdateWindow;
		hRC->RenderWindow=NULL;
		hRC->UpdateWindow=NULL;
		ObjectID=hRC->number;
		hRC->number=0;
		Settings.clearcolor[0]=hRC->cr;
		Settings.clearcolor[1]=hRC->cg;
		Settings.clearcolor[2]=hRC->cb;
		hRC->cr=0;
		hRC->cg=0;
		hRC->cb=0;
	}
}

void QObject::EnableWindow()
{
/*
	for(DWORD d=0;d<num_childs;d++)
		if(Childs[d])
		{
			Childs[d]->EnableWindow();
		}
*/
	QMem* qm=mChilds;
	while(qm)
	{
		if(qm&&qm->mem)
			((QObject*)qm->mem)->EnableWindow();
		qm=qm->next;
	}

	if(hRC)
	{
		hRC->number=ObjectID;
		hRC->RenderWindow=Settings.DrawProc;
		hRC->UpdateWindow=Settings.WndProc;
		hRC->cr=Settings.clearcolor[0];
		hRC->cg=Settings.clearcolor[1];
		hRC->cb=Settings.clearcolor[2];
	}
}

QObject* QObject::FindObject(char* name)
{
	if(!strcmp(Settings.name,name))return this;

	/*
	for(DWORD d=0;d<num_childs;d++)
		if(Childs[d])
		{
			QObject* mq=Childs[d]->FindObject(name);
			if(mq)return mq;
		}
	*/
	QMem* qm=mChilds;
	while(qm)
	{
		if(qm&&qm->mem)
		{
			QObject* mq=((QObject*)qm->mem)->FindObject(name);
			if(mq)return mq;
		}
		qm=qm->next;
	}

	return NULL;
}

void QObject::AddObject(QObject* qo)
{
	/*
	if(num_childs>=max_childs)
		((error)(Server,"QObject Library : Cannot add '%s(%s)' to '%s(%s)' as it has only %d childs allocated.",qo->Settings.name,qo->ClassName,Settings.name,ClassName,max_childs));
	Childs[num_childs]=qo;
	num_childs++;
	*/
	QMem* qm=mChilds;
	while(qm)
	{
		if(!qm->mem)
		{
			qm->mem=qo;
			break;
		}
		if(!qm->next)
		{
			qm->next=(QMem*)malloc(sizeof(QMem));
			qm=qm->next;
			qm->mem=qo;
			qm->next=NULL;
			break;
		}
		qm=qm->next;
	}
	

	if(!qo->Parent)qo->Parent=this;
}

void QObject::DelObject(QObject* qo)
{
	/*
	for(DWORD d=0;d<num_childs;d++)
		if(Childs[d]==qo)Childs[d]=NULL;
		*/
	QMem* qm=mChilds;
	QMem* last=mChilds;
	while(qm)
	{
		if(qm->mem==qo)
		{
			if(qm->next)
			{
				if(last!=qm)
					last->next=qm->next;
				else
					last=last->next;
			}
			else 
			{
				if(last!=qm)
					last->next=NULL;
				else last=NULL;
			}
//			free(qm);
			qm=NULL;
			break;
		}
		last=qm;
		if(qm)
			qm=qm->next;
	}

}

void QObject::Draw()
{
	if(hRC)hRC->NeedUpdate=2;
	/*
	for(DWORD d=0;d<num_childs;d++)
		if(Childs[d])Childs[d]->Draw();
		*/
	QMem* qm=mChilds;
	while(qm)
	{
		if(qm&&qm->mem)
			((QObject*)qm->mem)->Draw();
		qm=qm->next;
	}

}

void QObject::Move(float x,float y)
{
	if(hRC)
	{
		hRC->window.TopLeft.x+=x;
		hRC->window.TopLeft.y+=y;
		hRC->window.BottomRight.x=hRC->window.TopLeft.x+hRC->window.width;
		hRC->window.BottomRight.y=hRC->window.TopLeft.y+hRC->window.height;
		hRC->window.Center.x=hRC->window.TopLeft.x+hRC->window.width/2;
		hRC->window.Center.y=hRC->window.TopLeft.y+hRC->window.height/2;
	}
	QMem* qm=mChilds;
	while(qm)
	{
		if(qm&&qm->mem)
			((QObject*)qm->mem)->Move(x,y);
		qm=qm->next;
	}
	Draw();
}

void QObject::MoveTo(float x,float y)
{
	float xm,ym;
	if(hRC)
	{
		xm=x-hRC->window.TopLeft.x;
		ym=y-hRC->window.TopLeft.y;
		hRC->window.TopLeft.x=x;
		hRC->window.TopLeft.y=y;
		hRC->window.BottomRight.x=hRC->window.TopLeft.x+hRC->window.width;
		hRC->window.BottomRight.y=hRC->window.TopLeft.y+hRC->window.height;
		hRC->window.Center.x=hRC->window.TopLeft.x+hRC->window.width/2;
		hRC->window.Center.y=hRC->window.TopLeft.y+hRC->window.height/2;

		QMem* qm=mChilds;
		while(qm)
		{
			if(qm&&qm->mem)
				((QObject*)qm->mem)->Move(xm,ym);
			qm=qm->next;
		}
	}
	else
	{
		QMem* qm=mChilds;
		while(qm)
		{
			if(qm&&qm->mem)
				((QObject*)qm->mem)->MoveTo(x,y);
			qm=qm->next;
		}
	}
	Draw();
}

void QObject::Resize(float xp,float yp,float refx,float refy)
{
	if(hRC)
	{
		hRC->window.TopLeft.x-=refx;
		hRC->window.TopLeft.y-=refy;
		hRC->window.BottomRight.x-=refx;
		hRC->window.BottomRight.y-=refy;
		hRC->window.width*=xp;
		hRC->window.height*=yp;
		hRC->window.TopLeft.x*=xp;
		hRC->window.TopLeft.y*=yp;
		hRC->window.BottomRight.x=hRC->window.TopLeft.x+hRC->window.width;
		hRC->window.BottomRight.y=hRC->window.TopLeft.y+hRC->window.height;
		hRC->window.Center.x=hRC->window.TopLeft.x+hRC->window.width/2;
		hRC->window.Center.y=hRC->window.TopLeft.y+hRC->window.height/2;
		hRC->window.TopLeft.x+=refx;
		hRC->window.TopLeft.y+=refy;
		hRC->window.BottomRight.x+=refx;
		hRC->window.BottomRight.y+=refy;
		hRC->window.Center.x+=refx;
		hRC->window.Center.y+=refy;
	}
	QMem* qm=mChilds;
	while(qm)
	{
		if(qm&&qm->mem)
			((QObject*)qm->mem)->Resize(xp,yp,refx,refy);
		qm=qm->next;
	}
	Draw();
}

void QObject::Init(QO_Init* pInit)
{
	if(!Settings.WndProc)Settings.WndProc=__CALLBACK_VOID;
	if(!Settings.DrawProc)Settings.DrawProc=__CALLBACK_VOID;

	float _a[4]={0,0,1,1};

	if(pInit->father)((getclientarea)(*Importer,pInit->father,_a));
	//calc area
	_a[0]+=_a[2]*pInit->wndsize[0];
	_a[1]+=_a[3]*pInit->wndsize[1];
	_a[2]*=pInit->wndsize[2];
	_a[3]*=pInit->wndsize[3];

	memcpy(pInit->wndsize,_a,sizeof(float)*4);

	memcpy(Settings.wndsize,pInit->wndsize,sizeof(float)*4);
	memcpy(&Settings,pInit,sizeof(QO_Init));
	Settings.name=pInit->name;
	Settings.father=pInit->father;
//	Childs=(QObject**)malloc(sizeof(QObject*)*pInit->childs);
//	max_childs=pInit->childs;
	((registerobject)(*Importer,Settings.name,Settings.wndsize,this));
}

QObject* InitStandartObject(QObject* father,char*name,float x,float y,float xs,float ys)
{
	QObject* hQO=new QObject;
	QO_Init qi;
	qi.bkcolor[0]=0;
	qi.bkcolor[1]=0;
	qi.bkcolor[2]=0;
	qi.clearcolor[0]=0;
	qi.clearcolor[1]=0;
	qi.clearcolor[2]=0;
	qi.DrawProc=NULL;
	qi.MsgProc=NULL;
	qi.WndProc=NULL;
	if(father)
	{
		qi.father=(char*)malloc(strlen(father->Settings.name)+1);
		sprintf(qi.father,father->Settings.name);
	}
	else qi.father=NULL;
//	qi.childs=num_childs;
	hQO->Parent=father;
	qi.name=(char*)malloc(strlen(name)+1);
	sprintf(qi.name,name);
	qi.uEV=NULL;
	qi.wndsize[0]=x;
	qi.wndsize[1]=y;
	qi.wndsize[2]=xs;
	qi.wndsize[3]=ys;
	if(father)father->AddObject(hQO);
	hQO->Init(&qi);
	return hQO;
}
