#ifndef __CRC
#define __CRC

#include "CObject.h"
#include "..\dll\renderer\renderer.h"

class QRC : public QObject
{
public:
	QRC();
	~QRC();
	bool locked;
	OctLeaf* data;
	Mat* mats;
	virtual void Init(QO_Init* pInit);
};
QRC* InitStandartRC(QObject* father,char*name,float x,float y,float xs,float ys,OctLeaf*ol,Mat* mats,bool lock,_WndProc upd);

#endif