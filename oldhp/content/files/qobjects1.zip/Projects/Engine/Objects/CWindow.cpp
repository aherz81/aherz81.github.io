#include "CWindow.h"
#include "CButton.h"

void DeleteQWindow(void* qo)
{
	delete (QWindow*)qo;
}

QWindow::QWindow()
{
	SetClassName("QWindow");
	b1=0;
	b2=0;
	textcolor[0]=0;
	textcolor[1]=0;
	textcolor[2]=0;
	textsize=0;
	x=0;
	y=0;
	EventHandlerInited=0;
	TexId[0]=__TEXLOAD("textures\\objects\\button2.tga",TGA);
	TexId[1]=__TEXLOAD("textures\\objects\\quit.tga",TGA);
	TexId[2]=__TEXLOAD("textures\\objects\\min.tga",TGA);
	TexIdForm=__TEXLOAD("textures\\objects\\form.tga",TGA);
	Delete=DeleteQWindow;
//	Focus=0;
}

QWindow::~QWindow()
{
	QButton *qb=(QButton*)FindObject(Sysmenu);
	qb->TexId=ButtonTexId;
	
	QButton *mqb=(QButton*)qb->FindObject(Quit);
	mqb->TexId=ButtonTexId;

	mqb=(QButton*)qb->FindObject(Minimize);
	mqb->TexId=ButtonTexId;

	mqb=(QButton*)FindObject(Body);
	mqb->TexId=ButtonTexId;

	__TEXEREASE(TexId[0]);
	__TEXEREASE(TexId[1]);
	__TEXEREASE(TexId[2]);
	__TEXEREASE(TexIdForm);
	free(CaptionText);
	__DELEVENTUPDATE(Settings.MsgProc);
	__DELEVENTUPDATE(Settings.MsgProc);
	__DELEVENTUPDATE(Settings.MsgProc);
	__DELEVENTUPDATE(Settings.MsgProc);
	if(hEV)delete hEV;
}

bool QWindowMsgProc(bool mouse_pos,int mx,int my,bool b1,bool b2,bool key,BYTE state,void *data)
{
	QButton*lhQO=(QButton*)data;
	QObject*mQO=lhQO->Parent;
	QWindow* hQO=(QWindow*)mQO;
	if(strcmp(hQO->ClassName,"QWindow"))hQO=(QWindow*)mQO->Parent;
	void* Data=lhQO->uEV->Pop();
	static POINT p;

	while(Data)
	{
		switch(*((DWORD*)(Data)+1))
		{
		case MOUSE_LEFT_BUTTON_DOWN:
			if(hQO->size_state!=MINIMIZED)mQO->SetFocus();
//			else ((movetotop)(Server,((QWindow*)mQO->mChilds->mem)->hRC->number));
			mQO->Draw();
			if(!strcmp(hQO->Sysmenu,lhQO->Settings.name)||!strcmp(hQO->Body,lhQO->Settings.name))
			{
				if(hQO->state!=DRAG&&hQO->state!=RESIZE)
				{
					GetCursorPos(&p);
					if(!strcmp(hQO->Sysmenu,lhQO->Settings.name))
					{
						p.x=lhQO->hRC->window.TopLeft.x-p.x;
						p.y=lhQO->hRC->window.TopLeft.y-p.y;
						hQO->state=DRAG;
					}
					else
					{
						hQO->state=RESIZE;
					}
				}
			}
			break;
		case MOUSE_LEFT_BUTTON_UP:
			if(!strcmp(hQO->Sysmenu,lhQO->Settings.name)||!strcmp(hQO->Body,lhQO->Settings.name))
			{
				if(hQO->state==DRAG||hQO->state==RESIZE)hQO->state=NORMAL;
			}
			else if(!strcmp(hQO->Quit,lhQO->Settings.name))
			{
				
				QObject* mQO=lhQO->Parent;
				QWindow* pQO=(QWindow*)mQO->Parent;
				pQO->DisableWindow();
				pQO->body->DisableWindow();
				Desktop->Draw();
				
			}
			else if(!strcmp(hQO->Minimize,lhQO->Settings.name))
			{
				QObject* mQO=lhQO->Parent;
				QWindow* pQO=(QWindow*)mQO->Parent;
				if(pQO->size_state==NORMAL)
				{
					pQO->body->DisableWindow();
					pQO->size_state=MINIMIZED;
				}
				else if(pQO->size_state==MINIMIZED)
				{
					pQO->body->EnableWindow();
					pQO->size_state=NORMAL;
					mQO->SetFocus();
				}
				Desktop->Draw();
			}
			break;
		case MOUSE_LEFT:
			
			if(!strcmp(hQO->Sysmenu,lhQO->Settings.name))
			{
				if(hQO->state==DRAG)
				{
					Server->MouseWindow=lhQO->hRC->number;
					QButton* qo=(QButton*)hQO->FindObject(hQO->Body);
					qo->state=UP;
				}
			}
			else if(!strcmp(hQO->Body,lhQO->Settings.name))
			{
				if(hQO->state==RESIZE)
				{
					Server->MouseWindow=lhQO->hRC->number;
					QButton* qo=(QButton*)hQO->FindObject(hQO->Sysmenu);
					qo->state=UP;
				}
			}
		case MOUSE_MOVE:
			if(!strcmp(hQO->Sysmenu,lhQO->Settings.name))
			{
				if(hQO->state==DRAG)
				{
					POINT np;
					GetCursorPos(&np);
					np.x+=p.x;
					np.y+=p.y;
					lhQO->MoveTo(np.x,np.y);
					hQO->body->MoveTo(np.x,np.y+lhQO->hRC->window.height-1);
					Desktop->Draw();
				}
			}
			if(!strcmp(hQO->Body,lhQO->Settings.name))
			{
				if(hQO->state==RESIZE)
				{
					POINT np;
					GetCursorPos(&np);
					float x=(float)np.x/(float)p.x;
					float y=(float)np.y/(float)p.y;
					p=np;
					QObject* sys=hQO->FindObject(hQO->Sysmenu);
					sys->Resize(x,1,sys->hRC->window.TopLeft.x,sys->hRC->window.TopLeft.y);
					hQO->body->Resize(x,y,hQO->body->hRC->window.TopLeft.x,hQO->body->hRC->window.TopLeft.y);
					Desktop->Draw();
				}
			}
			break;
		default:
			break;
		}
		Data=lhQO->uEV->Pop();
	}
	return 0;
}

QObject* InitStandartWindow(QObject* father,char*name,char*text,float x,float y,float xs,float ys,EventHandler*ev,float ts,bool form)
{
	QWindow* hQB=new QWindow;
	QO_Init qi;
	qi.bkcolor[0]=0.8;
	qi.bkcolor[1]=0.8;
	qi.bkcolor[2]=0.8;
	qi.DrawProc=NULL;
	qi.MsgProc=NULL;
	qi.WndProc=NULL;
	if(father)
	{
		qi.father=(char*)malloc(strlen(father->Settings.name)+1);
		sprintf(qi.father,father->Settings.name);
	}
	else qi.father=NULL;
	hQB->Parent=father;
//	qi.childs=num_childs;
	qi.name=(char*)malloc(strlen(name)+1);
	sprintf(qi.name,name);
	qi.uEV=ev;
	qi.wndsize[0]=x;
	qi.wndsize[1]=y;
	qi.wndsize[2]=xs;
	qi.wndsize[3]=ys;
	hQB->state=NORMAL;
	hQB->size_state=NORMAL;
	hQB->textcolor[0]=1.0;
	hQB->textcolor[1]=1.0;
	hQB->textcolor[2]=1.0;
	hQB->textsize=ts;
	hQB->CaptionText=(char*)malloc(strlen(text)+1);
	sprintf(hQB->CaptionText,text);
	hQB->x=-((strlen(text)-1)*hQB->textsize)/2.5f;
	hQB->y=-hQB->textsize/2.f;
	hQB->form=form;
	if(father)father->AddObject(hQB);
	hQB->Init(&qi);
	
	return hQB->body;
}

void QWindow::Init(QO_Init* pInit)
{
	if(!pInit->uEV)return;

	float _a[4]={0,0,1,1};

	if(pInit->father)((getclientarea)(*Importer,pInit->father,_a));
	//calc area
	_a[0]+=_a[2]*pInit->wndsize[0];
	_a[1]+=_a[3]*pInit->wndsize[1];
	_a[2]*=pInit->wndsize[2];
	_a[3]*=pInit->wndsize[3];
	memcpy(pInit->wndsize,_a,sizeof(float)*4);

	memcpy(Settings.wndsize,pInit->wndsize,sizeof(float)*4);
	memcpy(&Settings,pInit,sizeof(QO_Init));
	Settings.name=pInit->name;
	Settings.father=pInit->father;
	uEV=pInit->uEV;
	if(!Settings.WndProc)Settings.WndProc=NULL;
	if(!Settings.DrawProc)Settings.DrawProc=NULL;
	if(!form)Settings.DrawProc=__CALLBACK_VOID;
	if(!Settings.MsgProc)Settings.MsgProc=QWindowMsgProc;
	hRC=NULL;

	__EOP();
	__CLEANFIFO();
	hEV=new EventHandler;
	((registerobject)(*Importer,Settings.name,Settings.wndsize,this));
	sprintf(Sysmenu,"%s_%s%c",Settings.name,"Sysmenu",0);
	QButton* qb=InitStandartButton(this,Sysmenu,CaptionText,0,0,1,0.06,hEV,textsize);
	ButtonTexId=qb->TexId;
	qb->TexId=TexId[0];
	
	sprintf(Quit,"%s_%s%c",Settings.name,"Quit",0);
	QButton* mqb=InitStandartButton(qb,Quit,"",0.95,0.15,0.04,0.8,hEV,textsize);
	mqb->TexId=TexId[1];

	sprintf(Minimize,"%s_%s%c",Settings.name,"Min",0);
	mqb=InitStandartButton(qb,Minimize,"",0.91,0.15,0.04,0.8,hEV,textsize);
	mqb->TexId=TexId[2];

	sprintf(Body,"%s_%s%c",Settings.name,"Body",0);
	body=InitStandartButton(this,Body,"",0,0.055,1,1-0.005,hEV,textsize);
	body->TexId=TexIdForm;

	__EOP();//push exit flag to fifo
	__CLEANFIFO();//remove all args(till next exit flag) from fifo

	__GETEVENTUPDATE(FindObject(Sysmenu)->hRC,Settings.MsgProc);
	__GETEVENTUPDATE(FindObject(Quit)->hRC,Settings.MsgProc);
	__GETEVENTUPDATE(FindObject(Minimize)->hRC,Settings.MsgProc);
	__GETEVENTUPDATE(FindObject(Body)->hRC,Settings.MsgProc);
}