#include "CDLLContainer.h"

void DeleteQDLLContainer(void* qo)
{
	delete (QDLLContainer*)qo;
}

QDLLContainer::QDLLContainer()
{
	SetClassName("QDLLContainer");
	Delete=DeleteQDLLContainer;
}

QDLLContainer::~QDLLContainer()
{
	Desktop->DelObject(FindObject(DllName));
	((push)(Server,2,UNLOAD_DLL,DllName));
}

void QDLLContainer::MoveTo(float x,float y)
{
	((getclientarea)(*Importer,DllName,Settings.wndsize));
	Settings.wndsize[0]=x/(*Rasterizer)->width;
	Settings.wndsize[1]=y/(*Rasterizer)->height;
	((registerobject)(*Importer,DllName,Settings.wndsize,this));
	float xm,ym;
	if(hRC)
	{
		xm=x-hRC->window.TopLeft.x;
		ym=y-hRC->window.TopLeft.y;
		hRC->window.TopLeft.x=x;
		hRC->window.TopLeft.y=y;
		hRC->window.BottomRight.x=hRC->window.TopLeft.x+hRC->window.width;
		hRC->window.BottomRight.y=hRC->window.TopLeft.y+hRC->window.height;
		hRC->window.Center.x=hRC->window.TopLeft.x+hRC->window.width/2;
		hRC->window.Center.y=hRC->window.TopLeft.y+hRC->window.height/2;
	}
	QMem* qm=mChilds;
	while(qm)
	{
		if(qm&&qm->mem)
			((QObject*)qm->mem)->Move(xm,ym);
		qm=qm->next;
	}
	Draw();
}

void QDLLContainer::Move(float x,float y)
{
	((getclientarea)(*Importer,DllName,Settings.wndsize));
	Settings.wndsize[0]+=x/(*Rasterizer)->width;
	Settings.wndsize[1]+=y/(*Rasterizer)->height;
	((registerobject)(*Importer,DllName,Settings.wndsize,this));
	if(hRC)
	{
		hRC->window.TopLeft.x+=x;
		hRC->window.TopLeft.y+=y;
		hRC->window.BottomRight.x=hRC->window.TopLeft.x+hRC->window.width;
		hRC->window.BottomRight.y=hRC->window.TopLeft.y+hRC->window.height;
		hRC->window.Center.x=hRC->window.TopLeft.x+hRC->window.width/2;
		hRC->window.Center.y=hRC->window.TopLeft.y+hRC->window.height/2;
	}
	QMem* qm=mChilds;
	while(qm)
	{
		if(qm&&qm->mem)
			((QObject*)qm->mem)->Move(x,y);
		qm=qm->next;
	}
	Draw();
}

void QDLLContainer::Resize(float xp,float yp,float refx,float refy)
{
	((getclientarea)(*Importer,DllName,Settings.wndsize));
	Settings.wndsize[0]-=refx/(*Rasterizer)->width;
	Settings.wndsize[1]-=refy/(*Rasterizer)->height;
	Settings.wndsize[0]*=xp;
	Settings.wndsize[1]*=yp;
	Settings.wndsize[2]*=xp;
	Settings.wndsize[3]*=yp;
	Settings.wndsize[0]+=refx/(*Rasterizer)->width;
	Settings.wndsize[1]+=refy/(*Rasterizer)->height;
	((registerobject)(*Importer,DllName,Settings.wndsize,this));
	if(hRC)
	{
		hRC->window.TopLeft.x-=refx;
		hRC->window.TopLeft.y-=refy;
		hRC->window.BottomRight.x-=refx;
		hRC->window.BottomRight.y-=refy;
		hRC->window.width*=xp;
		hRC->window.height*=yp;
		hRC->window.TopLeft.x*=xp;
		hRC->window.TopLeft.y*=yp;
		hRC->window.BottomRight.x=hRC->window.TopLeft.x+hRC->window.width;
		hRC->window.BottomRight.y=hRC->window.TopLeft.y+hRC->window.height;
		hRC->window.Center.x=hRC->window.TopLeft.x+hRC->window.width/2;
		hRC->window.Center.y=hRC->window.TopLeft.y+hRC->window.height/2;
		hRC->window.TopLeft.x+=refx;
		hRC->window.TopLeft.y+=refy;
		hRC->window.BottomRight.x+=refx;
		hRC->window.BottomRight.y+=refy;
		hRC->window.Center.x+=refx;
		hRC->window.Center.y+=refy;
	}
	QMem* qm=mChilds;
	while(qm)
	{
		if(qm&&qm->mem)
			((QObject*)qm->mem)->Resize(xp,yp,refx,refy);
		qm=qm->next;
	}
	Draw();
}

QDLLContainer* InitStandartDLLContainer(QObject* father,char*name,char* dll_name,float x,float y,float xs,float ys)
{
	QDLLContainer* hQB=new QDLLContainer;
	QO_Init qi;
	qi.bkcolor[0]=0.0;
	qi.bkcolor[1]=0.0;
	qi.bkcolor[2]=0.0;
	qi.DrawProc=NULL;
	qi.MsgProc=NULL;
	qi.WndProc=NULL;
	if(father)
	{
		qi.father=(char*)malloc(strlen(father->Settings.name)+1);
		sprintf(qi.father,father->Settings.name);
	}
	else qi.father=NULL;
	hQB->Parent=father;
//	qi.childs=num_childs;
	qi.name=(char*)malloc(strlen(name)+1);
	sprintf(qi.name,name);
	qi.uEV=NULL;
	qi.wndsize[0]=x;
	qi.wndsize[1]=y;
	qi.wndsize[2]=xs;
	qi.wndsize[3]=ys;
	if(father)father->AddObject(hQB);
	hQB->DllName=(char*)malloc(strlen(dll_name)+1);
	sprintf(hQB->DllName,dll_name);
	hQB->Init(&qi);
	hQB->AddObject(Desktop->FindObject(dll_name));
	
	return hQB;
}


void QDLLContainer::Init(QO_Init* pInit)
{

	float _a[4]={0,0,1,1};
//	Childs=(QObject**)malloc(sizeof(QObject*)*(pInit->childs+1));
//	max_childs=pInit->childs+1;

	if(pInit->father)__DLLINSTALL(pInit->father,DllName,pInit->wndsize);
	else
	{
		((importdll)(*Importer,DllName,_a));		
	}
	if(pInit->father)((getclientarea)(*Importer,pInit->father,_a));
	__DLLRUN(DllName);
	_a[0]+=_a[2]*pInit->wndsize[0];
	_a[1]+=_a[3]*pInit->wndsize[1];
	_a[2]*=pInit->wndsize[2];
	_a[3]*=pInit->wndsize[3];
	memcpy(pInit->wndsize,_a,sizeof(float)*4);

	memcpy(Settings.wndsize,pInit->wndsize,sizeof(float)*4);
	memcpy(&Settings,pInit,sizeof(QO_Init));
	Settings.name=pInit->name;
	Settings.father=pInit->father;
	
	((registerobject)(*Importer,Settings.name,Settings.wndsize,this));
}