#ifndef __CWINDOW
#define __CWINDOW

#include "CObject.h"
#include "CButton.h"

enum QWindowState
{
	NORMAL,
	DRAG,
	MINIMIZED,
	RESIZE
};

class QWindow : public QObject
{
public:
	BYTE state;
	BYTE size_state;
	float textcolor[3];
	char* CaptionText;
	float x,y,textsize;
	EventHandler* uEV;
	bool EventHandlerInited;
	DWORD TexId[4];
	DWORD TexIdForm;
	DWORD ButtonTexId;
	char Minimize[255];
	char Quit[255];
	char Sysmenu[255];
	char Body[255];
	bool form;
	QButton* body;
	QWindow();
	~QWindow();
	bool b1;
	bool b2;
	virtual void Init(QO_Init* pInit);
};
QObject* InitStandartWindow(QObject* father,char*name,char*text,float x,float y,float xs,float ys,EventHandler*ev,float ts,bool form);

bool QWindowMsgProc(bool mouse_pos,int mx,int my,bool b1,bool b2,bool key,BYTE state,void *data);


#endif