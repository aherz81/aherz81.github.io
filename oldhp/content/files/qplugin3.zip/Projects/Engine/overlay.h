#include "windows.h"
#include "global.h"

#ifndef OVERLAY
#define OVERLAY

struct Overlay_
{
	DWORD texid;
	float xywh[4];
	float rgba[4];
	BYTE type;//how to render..BUMPMAP or whatever
};

#endif