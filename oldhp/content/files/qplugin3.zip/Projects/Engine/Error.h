#include <windows.h>

#ifndef CLASS_ERROR
#define CLASS_ERROR

class Sys_Error
{
public:
	Sys_Error();
	char ClassName[40];
	void SetClassName(char* n);
	virtual void Error();
};

#endif