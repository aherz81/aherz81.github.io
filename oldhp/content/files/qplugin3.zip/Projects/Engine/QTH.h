#ifndef __QTEMPLATEHEADER
#define __QTEMPLATEHEADER

#include <crtdbg.h>
#include "WinMain.h"

extern Sys_WinMain* WinManager;//notify tp update
extern DWORD Warnings;				//did we have some warnings?

template <class T> class ILinkedList
{
public:
	ILinkedList *Next;
	ILinkedList *Parent;
	T *Item;
	ILinkedList(T* item,ILinkedList*parent);
	virtual void operator+=(T* item);	//add Item
	virtual void operator-=(T* item);	//remove Item
	virtual void operator!();			//clear list
	virtual T* operator~();				//access Item member

};

template <class T> ILinkedList<T>::ILinkedList(T* item,ILinkedList* parent) 
{
    Item=item;
	Parent=parent;
	Next=NULL;
};

template <class T>void ILinkedList<T>::operator!() 
{
	if(Next)
	{
		ILinkedList *Del=Next;
		Next=NULL;
		delete Del;
	}
}

template <class T>T* ILinkedList<T>::operator~()
{
	return Item;
}

template <class T>void ILinkedList<T>::operator+=(T* item) 
{
	ILinkedList* Actual=this;
	while(Actual->Next)    
		Actual=Actual->Next;
	Actual->Next=new ILinkedList<T>(item,Actual);
};

template <class T>void ILinkedList<T>::operator-=(T* item) 
{
	ILinkedList* Actual=this;

	while(Actual&&Actual->Item!=item)    
		Actual=Actual->Next;

	if(Actual)
	{
		if(Actual->Parent)
		{
			Actual->Parent->Next=Actual->Next;
			if(Actual->Next)
				Actual->Next->Parent=Actual->Parent;
			delete Actual;
		}
		else
		{
			ILinkedList* _Next=Next;
			Item=Next->Item;
			Next=Next->Next;
			delete _Next;
		}			
	}	
};

struct MemInfo
{
	DWORD header;
	char* src_file;
	DWORD src_line;
	DWORD mem_size;
	BYTE* mem;
	bool check;
	DWORD footer;
};

#ifdef _DEBUG

class IProtectedMem
{
protected:
	ILinkedList<MemInfo> *Items;
public:
	bool _assert;
	bool _check;
	DWORD size;
	DWORD real_size;

	IProtectedMem(bool debug_check=0,bool debug_break=0)
	{
		_check=debug_check;
		_assert=debug_break;
		size=0;
		real_size=0;
		Items=new ILinkedList<MemInfo>((MemInfo*)this,NULL);
	}

	~IProtectedMem()
	{
		ILinkedList<MemInfo>* Actual=Items->Next;
		if(_check&&Actual)
			WinManager->Log("IProtectedMem->~IProtectedMem() <RELEASE LIST>");

		while(Actual)
		{
			ILinkedList<MemInfo>* Actual_=Actual;
			Actual=Actual->Next;
			t_Free(Actual_->Item->mem,Actual_->Item->check,Actual_->Item->check,_assert);
		}
		!(*Items);
		delete Items;
	}

	template <class T> T* t_Alloc(T** item,unsigned int num =1,bool check=0,char* src_file=__FILE__,DWORD src_line=__LINE__,bool log=0)
	{
		MemInfo* hMI=(MemInfo*)malloc(sizeof(MemInfo));
		if(!hMI)WinManager->Error("IProtectedMem->t_Alloc() < OUT OF MEM > failed to assign %d bytes to %s in line %d.",sizeof(MemInfo),__FILE__,__LINE__);
		hMI->src_line=src_line;
		hMI->header=0xEFBEADDE;
		hMI->footer=0xEFBEADDE;
		hMI->mem_size=sizeof(T)*num;
		size+=hMI->mem_size;
		real_size+=hMI->mem_size+sizeof(MemInfo)+check*8;
		if(check)
		{
			hMI->check=1;
			if(src_file)
			{
				hMI->src_file=(char*)malloc(strlen(src_file)+1);
				if(!hMI->src_file)WinManager->Error("IProtectedMem->t_Alloc() < OUT OF MEM > failed to assign %d bytes to %s in line %d.",strlen(src_file)+1,__FILE__,__LINE__);
				memcpy(hMI->src_file,src_file,strlen(src_file)+1);
			}
		}
		else hMI->check=0;
		static char fn_unknown[10]="unknown";
		if(!src_file)hMI->src_file=fn_unknown;
		T* data=(T*)malloc(hMI->mem_size+check*8);
		if(!data)WinManager->Error("IProtectedMem->t_Alloc() < OUT OF MEM > failed to assign %d bytes to %s in line %d.",hMI->mem_size,hMI->src_file,hMI->src_line);
		if(check)
		{
			*((DWORD*)data)=0xEFBEADDE;
			BYTE* pdata=(BYTE*)data; 
			pdata+=hMI->mem_size+4;
			DWORD* end=(DWORD*)pdata;
			*end=0xEFBEADDE;
		}
		hMI->mem=(BYTE*)(((DWORD*)data)+(check*1));
		(*Items)+=hMI;
		*item=(T*)(((DWORD*)data)+(check*1));
		if(check)
			memset(*item,0,hMI->mem_size);//zero out mem
		if(log)
			WinManager->Log("IProtectedMem->t_Alloc() < block 0x%x > by %s in line %d size %d bytes.",hMI->mem,hMI->src_file,hMI->src_line,hMI->mem_size);
		return *item;
	};

	MemInfo* t_Test(void* mem,bool check=0,bool l_assert=0)
	{
		if(!mem&&check)
			WinManager->Log("IProtectedMem->t_Test() < INTEGRITY CHECK > of 0x%x.",this);

		MemInfo* hMI=NULL;
		ILinkedList<MemInfo>* Actual=Items->Next;
		while(Actual)
		{
			ILinkedList<MemInfo>* Actual_=Actual;
			Actual=Actual->Next;
			if(Actual_->Item->mem==mem||!mem)
			{
				hMI=Actual_->Item;
				if(hMI->header!=0xEFBEADDE||hMI->footer!=0xEFBEADDE)
				{
					Warnings++;
					WinManager->Log("IProtectedMem->t_Test() < MEMINFO DAMAGED > of block 0x%x.",mem);
					if(l_assert)_ASSERT(NULL);//debug break
					if(mem)return NULL;
				}
				if((check||!mem)&&hMI->check)
				{
					if(*((DWORD*)((BYTE*)hMI->mem-hMI->check*4))!=0xEFBEADDE)
					{
						Warnings++;
						WinManager->Log("IProtectedMem->t_Test() < HEADER DAMAGED > of block 0x%x allocated by %s in line %d.",hMI->mem,hMI->src_file,hMI->src_line);
						if(l_assert)_ASSERT(NULL);//debug break
					}
					if(*((DWORD*)(((BYTE*)hMI->mem-hMI->check*4)+hMI->mem_size+4))!=0xEFBEADDE)
					{
						Warnings++;
						WinManager->Log("IProtectedMem->t_Test() < FOOTER DAMAGED > block 0x%x allocated by %s in line %d.",hMI->mem,hMI->src_file,hMI->src_line);
						if(l_assert)_ASSERT(NULL);//debug break
					}
				}
				if(mem)return hMI;
			}
		}
		if(!mem&&check)
			WinManager->Log("IProtectedMem->t_Test() < END INTEGRITY CHECK > of 0x%x.",this);
		return NULL;
	};

	void t_Free(void* mem,bool check=0,bool log=0,bool _assert_=0)
	{
		MemInfo* hMI=hMI=t_Test(mem,check,_assert_||_assert);
		if(!hMI)
		{
			Warnings++;
			WinManager->Log("IProtectedMem->t_Free() < RELEASE FAILED > of 0x%x, not found n list.",mem);
			return;
		}
		*Items-=hMI;
		free(((BYTE*)hMI->mem)-hMI->check*4);
		if(log)
			WinManager->Log("IProtectedMem->t_Free() < block 0x%x > allocated by %s in line %d.",hMI->mem,hMI->src_file,hMI->src_line);
		if(hMI->src_file&&hMI->check)free(hMI->src_file);
		free(hMI);
	};
};

#else

class IProtectedMem
{
protected:
	ILinkedList<void> *Items;
public:
	bool _assert;
	bool _check;
	DWORD size;
	DWORD real_size;

	IProtectedMem(bool debug_check=0,bool debug_break=0)
	{
		_check=debug_ckecks;
		_assert=debug_break;
		WinManager->Log("IProtectedMem::IProtectedMem() < debug_checks > %d",debug_ckecks);
		WinManager->Log("IProtectedMem::IProtectedMem() < debug_break > %d",debug_break);
		size=0;
		real_size=0;
		Items=new ILinkedList<void>((void*)this,NULL);
	}

	~IProtectedMem()
	{
		ILinkedList<void>* Actual=Items->Next;
		while(Actual)
		{
			ILinkedList<void>* Actual_=Actual;
			Actual=Actual->Next;
			free(Actual_->Item);
		}
		!(*Items);
		delete Items;
	}

	template <class T> T* t_Alloc(T** item,unsigned int num =1,bool check=0,char* src_file=NULL,DWORD src_line=0,bool log=0)
	{
		DWORD mem_size=sizeof(T)*num;
		size+=mem_size;
		real_size+=mem_size;
		T* data=(T*)malloc(mem_size);
		if(!data)WinManager->Error("IProtectedMem->t_Alloc() < OUT OF MEM > failed to assign %d bytes.",mem_size);
		(*Items)+=data;
		*item=data;
		return *item;
	};

	MemInfo* t_Test(void* mem,bool check=0,bool l_assert=0)//we're release
	{
		return NULL;
	};

	void t_Free(void* mem,bool check=0,bool log=0,bool _assert_=0)
	{
		*Items-=mem;
		free(mem);
	};
};

#endif

template <class T> T* _Alloc(IProtectedMem* IPMem,T** item,DWORD num,char* src_file,DWORD src_line) 
{
	if(IPMem->_check)
	{
		IPMem->t_Test(NULL,0,IPMem->_assert);
		return IPMem->t_Alloc(item,num,1,src_file,src_line,1);
	}
	else return IPMem->t_Alloc(item,num); 
}

template <class T> void p_Free(IProtectedMem* IPMem,T* item) 
{
	if(IPMem->_check)
	{
		IPMem->t_Free(item,1,1,1);
		return;
	}
	else 
		IPMem->t_Free(item);
}
//use this macro
#define p_Alloc(ipm,item,num) (_Alloc(ipm,item,num,__FILE__,__LINE__))

#endif