#ifndef __REGEDIT
#define __REGEDIT

#include "dllimporter.h"

enum _DataType
{
	DT_STRING,
	DT_DWORD,
	DT_INT,
	DT_FLOAT,
	DT_OBJECT
};

struct _DataContainer
{
	_DataType type;
	void* item;
	char* link;
};

void RegEdit(HINSTANCE hinst,HWND hwnd,_DLLData* data);

#endif
