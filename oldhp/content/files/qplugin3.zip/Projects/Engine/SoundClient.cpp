#include "SoundClient.h"
#include "malloc.h"

void __cdecl SoundClient::Init(DWORD num)
{
	lpSB=(LPDIRECTSOUNDBUFFER*)malloc(sizeof(LPDIRECTSOUNDBUFFER)*num);
	lpSB3d=(LPDIRECTSOUND3DBUFFER*)malloc(sizeof(LPDIRECTSOUND3DBUFFER)*num);
	time=(DWORD*)malloc(sizeof(DWORD)*num);
	MaxSounds=num;
	NumSounds=0;
}

LPDIRECTSOUNDBUFFER* __cdecl SoundClient::GetSB(int num)
{
	return (lpSB+num);
}

LPDIRECTSOUND3DBUFFER* __cdecl SoundClient::GetSB3d(int num)
{
	return (lpSB3d+num);
}

DWORD __cdecl SoundClient::GetTime(int num)
{
	return *(time+num);
}

void __cdecl SoundClient::DeleteSB(int num)
{
	for(int i=num;i<NumSounds-1;i++)
	{
		*(lpSB+i)=*(lpSB+i+1);
		*(lpSB3d+i)=*(lpSB3d+i+1);
	}
	NumSounds--;
}

void __cdecl SoundClient::Set3dSoundPos( float pos[3] ,int num )
{
	lpSB3d[num]->SetPosition( pos[0], pos[1], pos[2], DS3D_IMMEDIATE );
}  // MoveSound
