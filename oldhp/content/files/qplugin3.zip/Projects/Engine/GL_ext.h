#ifndef OPENGL_H
#define OPENGL_H
#include "windows.h"
#include <gl\gl.h>
#include "GLext.h"

//implementations of all used gl extentions..

// EXT_compiled_vertex_array
typedef void (APIENTRY * GLLOCKARRAYSEXTPROC) (GLint first, GLsizei count);
typedef void (APIENTRY * GLUNLOCKARRAYSEXTPROC) ();

// ARB_multitexture
#define TPU(x)								(GLenum)(GL_TEXTURE0_ARB+x)
#define	GL_BYTES(x)							(GLenum)(GL_2_BYTES+(x-2))

typedef void (APIENTRY * GLMULTITEXCOORD2FARBPROC) (GLenum target, GLfloat s, GLfloat t);
typedef void (APIENTRY * GLACTIVETEXTUREARBPROC) (GLenum target);
typedef void (APIENTRY * GLCLIENTACTIVETEXTUREARBPROC) (GLenum target);

// This class handles management of OpenGL-related stuff like extensions and their function
// pointers.
class GLext
{
public:
  GLext();
  ~GLext();
  // Multitexture function pointers.
  GLMULTITEXCOORD2FARBPROC glMultiTexCoord2fARB;
  GLACTIVETEXTUREARBPROC glActiveTextureARB;
  GLCLIENTACTIVETEXTUREARBPROC glClientActiveTextureARB;
  
  // Compiled vertex array function pointers.
  GLLOCKARRAYSEXTPROC glLockArraysEXT;
  GLUNLOCKARRAYSEXTPROC glUnlockArraysEXT;

  int getNumMultiTextures();
  bool getSupportsCompiledVertexArrays();

  void initExtensions();

  int numMultiTextures;
  bool supportsCompiledVertexArrays;
  char* glExtentions;
};

#endif //OPENGL_H