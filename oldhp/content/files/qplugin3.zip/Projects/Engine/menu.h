#include <windows.h>
#include "renderclient.h"
#include "3d.h"

void UPD_Window(int *nu,void* data,Camera_* cam,RenderClient *rc);

//standart
void UPD_Initializing(int *nu,void* data,Camera_* cam,RenderClient *rc);
