#ifndef TGA_FILE
#define TGA_FILE

#include "file.h"
#include "texmanager.h"

typedef struct 
{
    BYTE IDLength;
    BYTE ColorMapType;
    BYTE ImgType;
    BYTE CMapStartLo;
    BYTE CMapStartHi;
    BYTE CMapLengthLo;
    BYTE CMapLengthHi;
    BYTE CMapDepth;
    BYTE XOffSetLo;
    BYTE XOffSetHi;
    BYTE YOffSetLo;
    BYTE YOffSetHi;
    BYTE WidthLo;
    BYTE WidthHi;
    BYTE HeightLo;
    BYTE HeightHi;
    BYTE PixelDepth;
    BYTE ImageDescriptor;
} TGAHEAD;

class TgaFile : public Sys_File
{
public:
	virtual void open(char * fn,RamTex_t* tex,bool trans);
};

inline int Write_TGA( const char *filename, int width,  int height )
{
	TGAHEAD t;
	FILE *fp;
	//BYTE  data;
	float *region,*pixel;
	BYTE *buff,*p;

		fp = fopen(filename, "wb");
		if (fp == NULL)
		return false;

		t.IDLength        = 0;
		t.ColorMapType     = 0;
		t.ImgType        = 0x2;
		t.CMapStartLo      = 0;
		t.CMapStartHi      = 0;
		t.CMapLengthLo     = 0;
		t.CMapLengthHi     = 0;
		t.CMapDepth        = 0;
		t.XOffSetLo        = 0;
		t.XOffSetHi        = 0;
		t.YOffSetLo        = 0;
		t.YOffSetHi        = 0;
		t.WidthHi          = (BYTE)((width >> 8) & 0xFF);
		t.WidthLo          = (BYTE)(width & 0xFF);
		t.HeightHi         = (BYTE)((height >> 8) & 0xFF);
		t.HeightLo         = (BYTE)(height & 0xFF);
		t.PixelDepth       = 24;       // 32;
		t.ImageDescriptor  = 0x20;       // image always right side up.

		fwrite(&t,1,18,fp);         // Write Header

	region = (float*)malloc(width * height * sizeof(float)*3);
	buff   = (BYTE*) malloc(width * height * 3);    // RGB 24bit Format
	/*
	grLfbReadRegion( GR_BUFFER_FRONTBUFFER,
						 0, 0, width, height,
						 width*2, region );
	*/
	glReadBuffer(GL_FRONT);
	glReadPixels(0,0,width,height,GL_RGB ,GL_FLOAT,region);
	pixel = region+width*height*3-3;
	p     = buff;
	int i,j;
	for(i=0;i<height;i++) 
	{
	  for(j=0;j<width;j++) 
	  {
	   p[0] = (BYTE)(pixel[2]*255);
	   p[1] = (BYTE)(pixel[1]*255);
	   p[2] = (BYTE)(pixel[0]*255);
	   p += 3;
	   pixel-=3;
	  }
	}

	/* LFB data */
	fwrite(buff, width * height * 3, 1, fp);

    free(buff);
    free(region);
    fclose(fp);

    return true;
}


#endif