//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDCANCEL2                       3
#define IDD_MAIN                        102
#define IDC_STANDART                    104
#define IDD_REMCONNABORTDLG             106
#define IDD_Q_CREATE                    108
#define IDI_ICON1                       108
#define IDI_ICON2                       126
#define IDD_CHOOSEPROVIDER              129
#define IDD_SELSESSION                  130
#define IDD_MSGBOX                      131
#define IDD_WAIT                        132
#define IDD_SERVCON                     133
#define IDD_REGEDIT                     134
#define IDC_MSGTEXT                     1000
#define IDC_CREATE                      1005
#define IDC_CONNECT                     1006
#define IDC_EDIT1                       1010
#define IDC_TREE1                       1020
#define IDC_LIST1                       1021
#define IDC_LB_SESSION                  1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
