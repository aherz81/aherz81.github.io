#include <windows.h>

#ifndef GLOBAL_DEFS
#define GLOBAL_DEFS

#pragma warning( disable : 4305 )
#pragma warning( disable : 4244 )

#pragma warning( disable : 4096 )
#pragma warning( disable : 4800 )

#pragma warning( disable : 4018 )

#define PI    3.14159265358979323846f
#define DEG2RAD( x ) ( (x) * 0.01745329251994f )
#define random(num)(float)(((float)rand()*(num))/(RAND_MAX+1))

#define SNAP_CONSTANT (3L << 18)

struct Vec3d
{
	float x,y,z;
};

struct Vec2d
{
	float x,y;
};

inline bool IsKeyDown(int virtKeyCode){if (GetAsyncKeyState(virtKeyCode) & 0x8000) return TRUE;return FALSE;}
float __cdecl absf(float x);

#endif