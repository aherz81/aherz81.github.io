/***********************************************************************	
� 1998 Alex Herz - All rights reserved

	Programmer:	Alex
	Current Version:	1.0

	Update History:
	Programmers Initials	Date	Change Made	Version
	
	Alex					15.9.98 Initial Revision
***********************************************************************/
#ifndef __DSOUND_INTERFACE
#define __DSOUND_INTERFACE

#include <windows.h>
#include "mmsystem.h"
#include "conio.h"
#include "stdio.h" 
#include "memory.h"
#include "net.h"
#include "soundclient.h"


struct WaveHeader
{
    BYTE        RIFF[4];          // "RIFF"
    DWORD       dwSize;           // Size of data to follow
    BYTE        WAVE[4];          // "WAVE"
    BYTE        fmt_[4];          // "fmt "
    DWORD       dw16;             // 16
    WORD        wOne_0;           // 1
    WORD        wChnls;           // Number of Channels
    DWORD       dwSRate;          // Sample Rate
    DWORD       BytesPerSec;      // Sample Rate
    WORD        wBlkAlign;        // 1
    WORD        BitsPerSample;    // Sample size
    BYTE        DATA[4];          // "DATA"
    DWORD       dwDSize;          // Number of Samples
};


class SoundServer : public Sys_Memory
{
protected:	
	BOOL S_CreateSoundBufferDS( DWORD dwBufSize, DWORD dwFreq, DWORD dwBitsPerSample, DWORD dwBlkAlign, BOOL bStereo, LPLPDIRECTSOUNDBUFFER lplpdsb ,bool b3d);
	BOOL S_CreateBufferFromWaveFile(char* FileName,bool b3d,LPDIRECTSOUNDBUFFER *lpSB,LPDIRECTSOUND3DBUFFER *lpSB3d);
	DWORD DSOUND;
public:

	SoundServer();
	~SoundServer();
	void UpdateClient(int num);
	bool S_InitDSound(DWORD num);//init dsound obj
	void S_CleanupDSound(  );
	int __cdecl S_LoadSound(char fn[],bool b3d,SoundClient* sc);
	int __cdecl S_UpLoadSound(SoundClient* sc,int num); //uploads
	bool __cdecl S_ResidentSound(int num,DWORD time);

	void __cdecl S_PlaySound(int num,bool loop);//plays sbuffer
	void __cdecl S_StopSound(int num);//stops sb
	void __cdecl S_ResetSound(int num);//resets sb

	void __cdecl S3D_Set3dSoundPos( float pos[3] ,int num );
	void __cdecl S3D_SetListenerDir( float dir[3] ,float up[3] );
	void __cdecl S3D_SetListenerPos(float pos[3]);

	void __cdecl CDA_CloseCDAudio();
	void __cdecl CDA_PlayCDAudio(short nTrack,WORD m,WORD s);
	short __cdecl CDA_ReadCDInfos();
	long __cdecl CDA_GetTrackLen(int tr);
	long __cdecl CDA_GetTrackLenAct();
	DWORD __cdecl CDA_GetTrackTime();
	void __cdecl CDA_Enable(bool e);
	void CDA_SetVolume(DWORD vol);

	void S_SetSpeakerConf(int conf,int ang);
	void S_SetDistFactort(long distf);
	//SoundStuff
	bool S_LoadSounds();

};

#endif 
