#include <windows.h>
#ifndef CLASS_MEMORY
#define CLASS_MEMORY

#include "Error.h"
#include "LogFile.h"

#define MAX_ALLOCS 3000

class Sys_Memory : public Sys_Error
{
protected:
	DWORD* AllocHistory;
	DWORD* Ptr;
	bool CleanedUp;
	void* IPMem;

public:
	Sys_Memory();
	~Sys_Memory();

//	void* alloc(DWORD size);
//	void* __cdecl lalloc(DWORD size);
	void* __cdecl lalloc(DWORD size,char* src_file,DWORD src_line);
//	void free(void* item);
	void __cdecl lfree(void* item);
	void __cdecl lcheck(bool check);
	void __cdecl lstats();
//	void lfree();
//	void ladd(void* item);

	virtual void __cdecl Error(char*str,...);
	void __cdecl Log(char*str,...);
	void CloseLog();
};

#endif