#ifndef LOG_FILE
#define LOG_FILE

#include "Error.h"
#include "windows.h"
#include "stdio.h"

class Sys_LogFile : public Sys_Error
{
public:
	char FileName[255];
	FILE* File;
	virtual void open(char * fn);
	virtual void close();
	void Out(char* txt,...);
	~Sys_LogFile();
	Sys_LogFile(){SetClassName("Sys_LogFile");}
};


#endif