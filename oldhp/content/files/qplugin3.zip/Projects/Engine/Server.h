#include <windows.h>
#include <dplay.h>

#include "global.h"
#include "client.h"

#ifndef CLASS_SERVER
#define CLASS_SERVER

struct NetList_
{
	char* dllname;
	DWORD id;
	NetList_ *next;
};

class Sys_Server : public Sys_Client
{

public:
	NetList_ NetList;
	DWORD NetIdCounter;
	DWORD Max_Players;
	DWORD Min_Ping;
	void ProcessServerFifo(DWORD* data);
	//virtual funcs cause trouble
	virtual void* Pop();
	DWORD AddList(char* dllname);
};

void ServerThread(void* v);

#endif