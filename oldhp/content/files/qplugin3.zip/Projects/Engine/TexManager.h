#ifndef TEXMANAGER
#define TEXMANAGER

#include "memory.h"
#include "gl_ext.h"

#define MAX_TEXTURES_IN_RAM 2000
#define MAX_TPUS 12

enum PicFormats
{
	TGA
};

enum TexCombine
{
	LIGHTMAP,
	DETAILMAP,
	BUMPMAP,
	ENVMAP
};

struct RamTex_t
{
	DWORD* data;//to support 32bit texs
	BYTE bpp;
	WORD xsize,ysize;//max 255*255 for voodoo
	DWORD id;//id in card's mem..
	bool uploaded;
	char* name;//prevent double loading
	BYTE ref;//number of refernces pointing to this tex..if 0 it is deleted
};

class TexManager : public Sys_Memory
{
public:
	GLext *glext;
	RamTex_t *MemTex;
	DWORD Num_MemTex;
	WORD Num_TPUs;//we don't exspect more than 65535 tpus soon :)
	WORD Act_TPU;
	DWORD VidMemLeft;
	DWORD ActiveTexture[MAX_TPUS];
	float Act_Prio;
	bool GLTexCoordArray;
	bool FilterTexture;

	TexManager();
	~TexManager();

	void __cdecl TPUActivate(BYTE tpu);

	void __cdecl TexErease(DWORD id);
	void __cdecl TexActivate(DWORD id);
	void __cdecl TexBind(DWORD name);
	void __cdecl TexPrio(float p);
	void __cdecl TexArray(bool j);
	DWORD __cdecl TexLoad(char* fn,BYTE tp);//0=TGA
	void __cdecl TexReset();
/*
	void __cdecl TexEnd();
	void __cdecl TexFlush();
	void __cdecl TexTCMOD();
	void __cdecl TexTCGEN();
*/
	void LoadPic(char* fn,RamTex_t* tex,BYTE tp);
	bool Power2(int v);
};

#endif
