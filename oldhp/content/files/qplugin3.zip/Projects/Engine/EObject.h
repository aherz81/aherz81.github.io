#ifndef __EOBJECT
#define __EOBJECT
//this implementation of QObject is ONLY for the server app

//#include "..\dll\pnpdll0005.h"
#include "RenderClient.h"

//object base class

typedef void(*_MsgProc)(bool mouse_pos,int mx,int my,bool b1,bool b2,bool key,BYTE state,void* data);
typedef void(*_WndProc)(int*updates,void* dat,Camera_*cam,RenderClient *hRC);
typedef void(*_DrawProc)(int*updates,void* dat,Camera_*cam,RenderClient *hRC);

typedef void(*_IUnknown)(void* qo);

inline void __CALLBACK_VOID(int *nu,void* data,Camera_* cam,RenderClient *rc){}

struct QO_Init
{
	char* name;
	char* father;
	float wndsize[4];
	float bkcolor[3];
	float clearcolor[3];
	_MsgProc MsgProc;
	_WndProc WndProc;
	_DrawProc DrawProc;
	void* uEV;
//	WORD childs;
};

struct QMem
{
	void* mem;
	QMem* next;
};

class QObject
{
public:
	RenderClient *hRC;
	void *hEV;
	QObject *Parent;
	QMem *mChilds;
	QO_Init Settings;
	char ClassName[40];
	DWORD ObjectID;
	_IUnknown Delete;
public:
	QObject();
	~QObject();
	void AddObject(QObject* qo);
	void DelObject(QObject* qo);
	void DisableWindow();
	void EnableWindow();
	QObject* FindObject(char* name);
	virtual void Move(float x,float y);
	virtual void MoveTo(float x,float y);
	virtual void Resize(float xp,float yp,float refx,float refy);
	virtual void Draw();
	virtual void Init(QO_Init* pInit);
	virtual void SetFocus();
	void SetClassName(char*n);
};

QObject* InitStandartObject(QObject* father,char*name,float x,float y,float xs,float ys);


#endif