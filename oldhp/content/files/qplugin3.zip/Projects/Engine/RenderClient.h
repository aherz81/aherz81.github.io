#include <windows.h>

#ifndef CLASS_RCLIENT
#define CLASS_RCLIENT

#include "memory.h"
#include "global.h"
#include "3d.h"
#include "glrasterizer.h"

struct Window_
{
	Vec2d TopLeft;
	Vec2d BottomRight;
	Vec2d Center;
	float width;
	float height;
	bool inited;
};

class RenderClient : public Sys_Memory
{
public:
	Window_ window;
	void* data;
	BYTE type;
	WORD number;
	void(*UpdateWindow)(int*nu,void* dat,Camera_*cam,RenderClient *rc);
	void(*RenderWindow)(int*nu,void* dat,Camera_*cam,RenderClient *rc);
	float cr,cg,cb;
	GLRasterizer * glr;
	int NeedUpdate;
	float pos[3];
	float dir[3];
	float up[3];
	float zoom;
	bool Updated;
public:
	Camera_ camera;
	RenderClient(GLRasterizer * glrast);
	void Init(WORD x1,WORD y1,WORD x2,WORD y2);
	void Target(void* dat,BYTE tp,WORD num,...);//set what to render
	void Update();
	bool CheckUpdate();
	void ClearColor(float r, float g, float b);
	void InitCam(float fov,float zoom,float nc,float fc);
//	bool Render(void* data,BYTE tp);//does the actual rendering
};

#endif