#include <windows.h>
#include "memory.h"
#include <dplay.h>
#include <dsound.h>

#ifndef CLASS_NET
#define CLASS_NET

//#include "client.h"

class DP_Info : public Sys_Memory
{
public:
	char* Text;
	GUID Guid;
	DWORD Session;
	char* Name;
};

class Sys_Net : public Sys_Memory
{
public:
	LPDIRECTPLAY            lpIDC;     
//	LPGUID                  g_lpGuid;
	HANDLE                  dphEvent;
	DPID					PlayerId;

//	DPSESSIONDESC dpDesc;
	DWORD* buffer;

	Sys_Net();
	~Sys_Net();
	void __cdecl HostConnect(WORD index);
	void __cdecl HostOpen(char *SessionName);
	void __cdecl CreatePlayer(DPID* PlayerID);
	void __cdecl ReceiveMessages( void* CL );
	void __cdecl SendData(void* data,DPID to);
	void __cdecl Send(DPID to,DWORD size,...);
	void __cdecl KillDP();
	void __cdecl CreateProviderList();
	void __cdecl CreateSessionsList(DWORD timeout);
	void __cdecl ChooseProvider(WORD index);

	void GetPlayerNick(DPID id,char** nick);
};

#endif