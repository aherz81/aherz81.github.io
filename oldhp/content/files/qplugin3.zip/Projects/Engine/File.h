#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <commdlg.h>
#include <stdarg.h>

#include <winbase.h>
#include <winuser.h>

#include "Memory.h"

#ifndef CLASSES_FILE
#define CLASSES_FILE

class Sys_File : public Sys_Memory
{
public:
	FILE* File;
	~Sys_File();
	virtual void open(char * fn,char * tp);
	virtual void close();
	
};

#endif