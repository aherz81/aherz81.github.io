#include "windows.h"

#ifndef MESH_H
#define MESH_H

//implementation for dynamic models

#define MAX_PASSES 8

//bones anim..

struct KeyFrame_
{
	float xw,yw,zw;
	float Pos[3];

	DWORD Time;
};

struct Animation_
{
	KeyFrame_ *KeyFrames;

	int Num_Frames;
	int Act_Frame;

	bool Loop;// not implemented yet
	DWORD StartTime;//Time of KeyFrames+0 is always 0;0 then means StartTime
};

struct B_Node_
{
	B_Node_* Childs;

	int Num_Childs;
	int Node_Index;//vertexes with equal b_index belong to this node

	float xw,yw,zw;
	float Pos[3];
};

struct Surface_
{
	int *b_index;//bones anim
	WORD *v_index; //should presort to have strips or fans
	float *norm;
	int num_verts;

	DWORD *texId; //normal texture
	WORD *texMode;
	BYTE num_passes;
};

struct Mesh_
{
	float *vertex;//+(Surface_+i->v_index*4) ... 3 verts + allignment
	float *normal;//+(Surface_+i->v_index*4) ... 3 floats + allignment
	float *color[MAX_PASSES];//[pass]+(Surface_+i->v_index*4) ... 4 floats (rgba)
	float *texcoords[MAX_PASSES];//[pass]+(Surface_+i->v_index*2) ... 2 floats

	Surface_ * surfaces;

	int num_surfs;
	int num_verts;

	float BBox[6];//bounding box..must have max extentions of all anims together
};


#endif MESH_H
