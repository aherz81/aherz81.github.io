//	!!!! do not change this header file !!!!
#ifndef __PLUGIN_DLL
#define __PLUGIN_DLL
#pragma warning( disable : 4305 )
#pragma warning( disable : 4244 )
//sound,net is missing

//I highly encourage U to use the app intern texmanagement funcs as
//you'll probably mess up a lot if you don't

//all new dlls installed by your dll should never exceed your dll's client area!!
//so check using getclient area or use the __DLLINSTALL func

#pragma warning( disable : 4096 )
#pragma warning( disable : 4800 )

#pragma warning( disable : 4018 )

#include <windows.h>
#include <crtdbg.h>

//Server communication
#include "cs_com.h"

//struct defs
#include "..\3d.h"
#include "..\renderclient.h"
#include "..\dllimporter.h"
#include "..\texmanager.h"
#include "..\winmain.h"
#include "..\glrasterizer.h"
#include "..\sound.h"

//v0.0002
#include "..\net.h"

#define PNPDLL_VERSION 0.0005		//interface version for this header

//<function prototypes>
//use this to pass floats to (...) functions (like push,log,error func->look func defs below)
inline DWORD __CONV(float f){DWORD* d=(DWORD*)&f;return *d;}

typedef RenderClient* HRC;

//<<member_functions>>
//push function

typedef void* (__cdecl*push_function)			(void* adress,WORD w,...);

//other functions
typedef void* (__cdecl*voidp_Func_charp_any)	(void* adress,char *c,...);
typedef void* (__cdecl*voidp_Func_charp)		(void* adress,char *c);
typedef void  (__cdecl*void_Func_charp)			(void* adress,char *c);
typedef void  (__cdecl*void_Func_charp_charp)	(void* adress,char *c1,char *c2);
typedef void  (__cdecl*FuncUnique1)				(void* adress,char *c,float f1,float f2,float f3, float f4,float f5,float f6, float f7, float f8,float f9);
typedef void  (__cdecl*FuncUnique2)				(void* adress,WORD w,float f1, float f2, float f3, float f4,float f5,float f6, float f7, float f8, float f9,float f10);
typedef bool  (__cdecl*bool_Func_charp)			(void* adress,char *c);

typedef void  (__cdecl*void_Func_dword)			(void* adress,DWORD d);
typedef void  (__cdecl*void_Func_bool)			(void* adress,bool b);
typedef DWORD  (__cdecl*dword_Func_charp_byte)	(void* adress,char *c,BYTE b);
typedef void  (__cdecl*void_Func_charp_f4)		(void* adress,char *c,float area[4]);
typedef void  (__cdecl*void_Func_charp_f4_voidp)(void* adress,char *c,float area[4],void* data);
typedef lpFunc(__cdecl*lpfunc_Func_charp)		(void* adress,char*c1,char*c2);

//v0.0002
typedef void(__cdecl*void_Func_word)			(void* adress,WORD w);
typedef void(__cdecl*void_Func_voidp)			(void* adress,void* adress2);
typedef void(__cdecl*void_Func_voidp_dword)		(void* adress,void* adress2,DWORD dw);
typedef void(__cdecl*void_Func_void)			(void* adress);
typedef void(__cdecl*void_Func_dwordp)			(void* adress,DWORD* dw);

//<<global_functions>>
typedef bool  (__cdecl*bool_Func_int)			(int i);
typedef float (__cdecl*float_Func_float)		(float f);

typedef void (__cdecl*void_f_voidp)				(void* adress);

typedef bool (__cdecl*bool_Func_int_dword)		(void* adress,int i,DWORD dw);
typedef void (__cdecl*void_Func_int_bool)		(void* adress,int i,bool b);
typedef void (__cdecl*void_Func_int)			(void* adress,int i);
typedef void (__cdecl*void_Func_float3_int)		(void* adress,float f[3],int i);
typedef void (__cdecl*void_Func_float3_float3)	(void* adress,float f[3],float f2[3]);
typedef void (__cdecl*void_Func_float3)			(void* adress,float f[3],int i);

typedef int (__cdecl*LoadSound)					(void* adress,char *c,bool b,void* adress2);
typedef int (__cdecl*UpLoadSound)				(void* adress,void* adress2,int i);

typedef void (__cdecl*void_Func_short_word_word)(void* adress,short s,WORD w,WORD w2);
typedef short (__cdecl*short_Func_void)			(void* adress);
typedef long (__cdecl*long_Func_void)			(void* adress);
typedef long (__cdecl*long_Func_int)			(void* adress,int i);
typedef DWORD (__cdecl*dword_Func_void)			(void* adress);

typedef int (__cdecl*int_Func_int_int)			(void* adress,int i,int i2);
typedef void (__cdecl*void_Func_dword_byte_byte)(void* adress,DWORD d,BYTE b,BYTE b2);
typedef bool (__cdecl*bool_Func_long_long_long)	(void* adress,LONG l1,LONG l2,LONG l3);
typedef void (__cdecl*void_Func_int_int_bool_bool)	(void* adress,int i,int i2,bool b,bool b2);

typedef DWORD (__cdecl*dword_Func_int)			(void* adress,int i);
typedef void (__cdecl*void_Func_dword_int_int)	(void* adress,DWORD d,int i1,int i2);

typedef void (__cdecl*void_GLFunc_int_int)		(int i1,int i2);
typedef void (__cdecl*void_GLFunc)				();

typedef void (__cdecl*plugin_function)			(char* args);
typedef void (__cdecl*arbtc2f)			(GLenum target, float s, float t);

//<<object defs>>
extern Sys_Client *Server;		
//Server-Object needs to be passed as first arg to <push,error,log>
extern DLLImport **Importer;	
//DllImporter-Object needs to be passed as first arg to <importdll,unloaddll,getadress,register,isregistered>
extern GLRasterizer **Rasterizer;	
//GLRasterizer-Object needs to be passed as first arg to <drawtext,drawquad>
extern Sys_WinMain **WinManager;
//actually not needed

//v0.0002
extern Sys_Net** Net;
//Sys_Net-Object needs to be passed as first arg to <Sys_Net->Funcs>
extern SoundServer** Sound;
//SoundServer-Object needs to be passed as first arg to <SoundServer->Funcs>

//<function decls>

extern push_function push;			
//void ((push)(Server,number_of_following_args,...));->pushes the passed args to he stack of the server
extern voidp_Func_charp_any _log;		
//void ((log)(Server,"%s",...));->dumps passed string fprintf like into the logfile
extern voidp_Func_charp_any reg;
//void ((reg)(Importer,name_of_value_to_register,adress_of_value));->dumps adress and name into the 
//server internal registry
extern voidp_Func_charp_any error;
//void ((error)(Server,"%s",...));->executes log() and creates a messagebox reporting the error

//Importer class
extern void_Func_charp_f4 importdll;
extern void_Func_charp_f4_voidp registerobject;
//void ((importdll)(Importer,name_of_dll_to_load,float area[4]));->loads the dll(and calls its init funcs)
//area is [0]->y;[1]->x;[2]->xsize;[3]->ysize (all 4 range 0 to 1.f where 1.f is ScreenWidth)
extern void_Func_charp unloaddll;
//void ((unloaddll)(Importer,name_of_dll_to_unload));->unloads specifyed dll..DO NOT TRY TO UNLOAD YOURSLEF!
extern voidp_Func_charp getadress;
//void* ((getadress)(Importer,name_of_registered_value));->returns the adress or whatever was saved along 
//with the registration of that name
extern bool_Func_charp isregistered;
//bool ((isregistered)(Importer,name_of_value));->returns if that name was registered previously...
//should be called to see if a name passed to othet funcs was regeistered as most other funcs create an error
//if the name was not registered
extern void_Func_charp_f4 getclientarea;
//void ((getclientarea)(Importer,name_of_dll_to_load,float area[4]));->returns the client area of the specifyed dll
extern lpfunc_Func_charp importfunc;
//lpFunc ((importfunc)(Importer,name_of_dll_to_unload));->unloads dll

//Rasterizer class
extern FuncUnique1 drawtext;
//void ((drawtext)(Rasterizer,text,x,y,seize,zoom,r,g,b,a,z));->draws text to x,y with size and color rgba to z depth
//should only be used in rendercallbacks....zoom is not used
extern FuncUnique2 drawquad;
//void ((drawquad)(Rasterizer,id,x,y,xsize,ysize,zoom,r,g,b,a,z));->draws a quad using tex nr(id) to x,y withe size xsize,ysize
//and color rgba to depth z...zoom is an unused value

//texture class
extern void_Func_dword			tpuactivate;
//void ((tpuactivate)(Rasterizer,WORD id));->activates tpu number id
//be shure to check weather multytex is avalable or not before calling
extern void_Func_dword			texactivate;
//void ((texactivate)(Rasterizer,WORD id));->activates texture number id
//(must have been loaded to mem (but not necessarily to vidmem) previosly)
extern void_Func_dword			texbind;
//void ((texbind)(Rasterizer,WORD id));->activates texture number id
//(must have been loaded to vidmem previosly)
extern void_Func_dword			texerease;
//void ((texerease)(Rasterizer,WORD id));->deletes tex id
extern void_Func_bool			texarray;
//void ((texarray)(Rasterizer,bool b));->switches using of texarray
extern dword_Func_charp_byte	texload;
//void ((texload)(Rasterizer,name,type));->loads name(as texture)and assumes type
//yet only type==0 means '.tga' files are supported;returns tex id

//net class
extern lpFunc					dpsend;
//((send)(Net,dword_DPID to,dword_size,...)
//->sends args like (push) via network to DPID
extern void_Func_word			hostconnect;
//connects to game DPInfo[word] from DP_info[word]
extern void_Func_charp			hostopen;
//creates game using passed string as name
extern void_Func_dwordp		createplayer;
//creates a player and writes it's DPID into passes adress
extern void_Func_voidp			receavemessages;
//->pass Server object!!..causes the sever to fetch net messages
extern void_Func_voidp_dword	senddata;
//do not use
extern void_Func_void			killdp;
//->shutdown directplay
extern void_Func_void 			createproviderlist;
//->fills DP_Info with info, see "Net.h" for details
extern void_Func_dword			createsessionslist;
//->fills DP_Info with info, see "Net.h" for details
extern void_Func_word			chooseprovider;
//->selects provider[word] from DP_info[word]

//sounserver class
//dsound wave stuff
extern LoadSound				loadsound;
//((loadsound)(Server,name,3d,soundclient));->loads the wave file 'name' into the next free buffer of the soundclient
extern UpLoadSound				uploadsound;
//((uploadsound)(Server,soundclient,num));->loads wave soundclient[num] into playable buffer

extern bool_Func_int_dword		residentsound;
//returns if the sound in buffer[num] is the one we uploaded
extern void_Func_int_bool		playsound;
//plays sound in buffer[num] and loops if loop
extern void_Func_int			stopsound;
//stops sound[num]
extern void_Func_int			resetsound;
//rewinds sound

//dsound 3d stuff
extern void_Func_float3_int	set3dsoundpos;
//use only for 3d sounds
extern void_Func_float3_float3	setlistenerdir;
extern void_Func_float3		setlistenerpos;

//cda stuff
extern void_Func_void				closecdaudio;
extern void_Func_short_word_word	playcdaudio;
extern short_Func_void				readcdinfos;
//should be called first
extern long_Func_int				gettracklen;
extern long_Func_void				gettracklenact;
extern dword_Func_void				gettracktime;
extern void_Func_bool				cda_enable;

extern void_f_voidp					netserverthread;
extern void_f_voidp					clientthread;

extern int_Func_int_int				findwnd;
extern void_Func_dword_int_int  	setmousepointer;
extern void_Func_int_int_bool_bool	initmousebuffer;

extern void_GLFunc_int_int			glLockCVA;
extern void_GLFunc					glUnlockCVA;

extern void_Func_void				memstats;
extern arbtc2f						multytexcoord;
extern void_Func_word				movetotop;

extern void_Func_charp_charp		addlinkinfo;


//<function defs>

//<global vars>
extern char		*Version;			//Server pnpversion

extern char		*ScreenBuffer;		//servers textbuffer
extern DWORD	*Lines;				//number of lines in buffer
extern DWORD	*Time;				//actual server time in ms
extern _DLLData	*DLLData;			//data of reged dlls and funcs..look "dllimporter.h" fordetails
extern WORD		*Num_TPUs;
extern WORD		*Act_TPU;
extern DP_Info	*ProviderInfo;
extern bool		*HostGame;
extern bool		*Net_Inited;
extern bool		*Net_Locked;
extern DWORD	*Warnings;

extern DWORD	UIN;

#define PNP_VERSION "PNPDLL_VERSION"

//MACROS
#define __GETCMD(c,adress)	((push)(Server,3,GET_VALUE,c,adress))
#define __REG(c,adress)		((reg)(*Importer,c,adress))
#define __LINK(n,l)			((addlinkinfo)(*Importer,n,l))
#define __LINK_PNP(n)		((addlinkinfo)(*Importer,n,"void pnp_log(*char)"))
#define __RUNFUNC(c,n)		((push)(Server,3,RUN_DLL,c,n))
#define __GETWINDOW(f1,f2,c,fl1,fl2,fl3,fl4,r,g,b,adr)		((push)(Server,12,REQUEST_WINDOW,f1,f2,c,__CONV(fl1),__CONV(fl2),__CONV(fl3),__CONV(fl4),__CONV(r),__CONV(g),__CONV(b),adr))
#define __DELETEWINDOW(n)	((push)(Server,2,DELETE_WINDOW,n))
#define __UPDATEALL()		((push)(Server,1,GFX_UPDATE_ALL))
#define __GETNETUPDATE(f)	((push)(Server,2,REQUEST_NET,f))
#define __EOP()				((push)(Server,1,EOP))
//0.0004
#define __ISREG(name)		((isregistered)(*Importer,name))
//0.0005
#define __DELNETUPDATE(f)	((push)(Server,2,DELETE_NET,f))
#define __GETEVENTUPDATE(wa,f)	((push)(Server,3,REQUEST_EVENTS,wa,f))
#define __DELEVENTUPDATE(f)	((push)(Server,2,DELETE_EVENTS,f))

#define __CHANGERES(x,y,d)	((push)(Server,4,CHANGE_RES,x,y,d))
#define __CLEARBUFFERS()	((push)(Server,1,CLEAR_BUFFERS))

#define __TEXACTIVATE(dw)	((texactivate)(*Rasterizer,dw))
#define __TEXLOAD(n,b)		((texload)(*Rasterizer,n,b))
#define __TEXEREASE(dw)		((texerease)(*Rasterizer,dw))
#define __TPUACTIVATE(dw)	((tpuactivate)(*Rasterizer,dw))
#define __TEXARBCOORDS(u,s,t)	((multytexcoord)(u,s,t))

#define __TEXARRAY(b)		(*Rasterizer)->GLTexCoordArray=b

#define __CLEANFIFO()		((clientthread)(NULL))

//!!!!!!!!DO NOT ALTER THE FOLLOWING!!!!!!!!!!!!!!

//objects
#define OBJ_IMPORTER	"DLLImport"
#define OBJ_WINMANAGER	"Sys_WinMain"
#define OBJ_RASTERIZER	"GLRasterizer"
#define OBJ_SERVER		"Sys_Client"

//v0.0002
#define OBJ_NET			"Sys_Net"
#define OBJ_SOUND		"SoundServer"

//v0.0005

#define OBJ_DESKTOP		"Desktop"

//vars
#define VAL_DLLDATA			"DLLImport::DLLData"
#define VAL_LINES			"Sys_WinMain::Lines"
#define VAL_SCREENBUFFER	"Sys_WinMain::ScreenBuffer"
#define VAL_TIME			"Sys_Client::Time"
#define VAL_NUMTPUS			"GLRasterizer::Num_TPUs"
#define VAL_ACTTPU			"GLRasterizer::Act_TPU"
#define VAL_PROVIDERINFO	"DP_Info"
//v0.0002
#define VAL_HOSTGAME			"Sys_Net::HostGame"
#define VAL_NET_INITED			"Sys_Net::Net_Inited"
#define VAL_NET_LOCKED			"Sys_Net::Net_Locked"

//v0.0005
#define VAL_WARNINGS			"Warnings"

//member functions
#define CMD_ERROR			"Sys_Client::Error"
#define CMD_LOG				"Sys_Client::Log"
#define CMD_IMPORTDLL		"DLLImport::ImportDll"
#define CMD_REGISTEROBJECT	"DLLImport::RegisterObject"
#define CMD_UNLOADDLL		"DLLImport::UnloadDll"
#define CMD_GETADRESS		"DLLImport::GetAdress"
#define CMD_REGISTER		"DLLImport::Register"
#define CMD_ISREGISTERED	"DLLImport::IsRegistered"
#define CMD_GETCLIENTAREA	"DLLImport::GetClientArea"
#define CMD_IMPORTFUNC		"DLLImport::ImportFunc"
#define CMD_DRAWTEXT		"GLRasterizer::DrawText"
#define CMD_DRAWQUAD		"GLRasterizer::DrawQuad"
#define CMD_TEXACTIVATE		"GLRasterizer::TexActivate"
#define CMD_TEXARRAY		"GLRasterizer::TexArray"
#define CMD_TEXEREASE		"GLRasterizer::TexErease"
#define CMD_TEXLOAD			"GLRasterizer::TexLoad"
#define CMD_TPUACTIVATE		"GLRasterizer::TPUActivate"

//v0.0002
#define CMD_HOSTCONNECT			"Sys_Net::HostConnect"
#define CMD_HOSTOPEN			"Sys_Net::HostOpen"
#define CMD_CREATEPLAYER		"Sys_Net::CreatePlayer"
#define CMD_RECEAVEMESSAGES		"Sys_Net::ReceiveMessages"
#define CMD_SEND				"Sys_Net::Send"
#define CMD_SENDDATA			"Sys_Net::SendData"
#define CMD_KILLDP				"Sys_Net::KillDP"
#define CMD_CREATEPROVIDERLIST	"Sys_Net::CreateProviderList"
#define CMD_CREATESESSIONLIST	"Sys_Net::CreateSessionsList"
#define CMD_CHOOSEPROVIDER		"Sys_Net::ChooseProvider"

#define CMD_S_LOADSOUND			"SoundServer::S_LoadSound"
#define CMD_S_UPLOADSOUND		"SoundServer::S_UpLoadSound"
#define CMD_S_RESIDENTSOUND		"SoundServer::S_ResidentSound"

#define CMD_S_PLAYSOUND			"SoundServer::S_PlaySound"
#define CMD_S_STOPSOUND			"SoundServer::S_StopSound"
#define CMD_S_RESETSOUND		"SoundServer::S_ResetSound"

#define CMD_S3D_SET3DSOUNDPOS	"SoundServer::S3D_Set3dSoundPos"
#define CMD_S3D_SETLISTENERDIR	"SoundServer::S3D_SetListenerDir"
#define CMD_S3D_SETLISTENERPOS	"SoundServer::S3D_SetListenerPos"

#define CMD_CDA_CLOSECDAUDIO	"SoundServer::CDA_CloseCDAudio"
#define CMD_CDA_PLAYCDAUDIO		"SoundServer::CDA_PlayCDAudio"
#define CMD_CDA_READCDINFOS		"SoundServer::CDA_ReadCDInfos"
#define CMD_CDA_GETTRACKLENACT	"SoundServer::CDA_GetTrackLenAct"
#define CMD_CDA_GETTRACKLEN		"SoundServer::CDA_GetTrackLen"
#define CMD_CDA_GETTRACKTIME	"SoundServer::CDA_GetTrackTime"
#define CMD_CDA_ENABLE			"SoundServer::CDA_Enable"

#define CMD_SC_INIT				"SoundClient::Init"
#define CMD_SC_GETSB			"SoundClient::GetSB"
#define CMD_SC_GETSB3D			"SoundClient::GetSB3d"
#define CMD_SC_GETTIME			"SoundClient::GetTime"
#define CMD_SC_SET3DSOUNDPOS	"SoundClient::Set3dSoundPos"
#define CMD_SC_DELETESB			"SoundClient::DeleteSB"

#define CMD_NETSERVERTHREAD		"ServerThread"
#define CMD_NETSERVERTHREAD		"ServerThread"
#define CMD_CLIENTTHREAD		"ClientThread"
//0.0005

#define CMD_FINDWND				"Sys_Client::FindWnd"		

#define CMD_SETMOUSEPOINTER		"GLRasterizer::SetMousepointer"		
#define CMD_CHANGERESOLUTION	"GLRasterizer::ChangeResolution"
#define CMD_INITMOUSEBUFFER		"GLRasterizer::InitMouseBuffer" 		

#define CMD_CVALOCK				"GLext::Lock"
#define CMD_CVAUNLOCK			"GLext::Unlock"

#define CMD_MEMSTATS			"Sys_Memory::lstats"
#define CMD_ARBTC2F				"GLExt::ARBTexCoord2f"
#define CMD_MOVETOTOP			"Sys_Client::MoveToTop"		
#define CMD_ADDLINKINFO			"DLLImport::AddLinkInfo"		

#define NET_RECEAVE_NETID	0
#define NET_SERVERUP		1

inline void __TESTCOM() {try{((push)(Server,1,NOP));}catch(...){MessageBox(NULL,"Failed to access server!","Error",MB_OK);}}

inline void __GETUIN(char*c)
{
	_ASSERT(Server&&Net&&senddata);
	static bool net_inited=0;
	if(!net_inited)
	{
		DWORD *msg=(DWORD*)malloc((4+(strlen(c))/4)*sizeof(DWORD));
		DWORD* mp=msg;
		*mp=(4+(strlen(c))/4);
		mp++;
		*mp=Server->Net->PlayerId;
		mp++;
		*mp=REQUEST_NETID;
		*mp++;
		memcpy(mp,c,strlen(c)+1);
		((senddata)(*Net,msg,Server->ServerId));
		net_inited=1;
		free(msg);
	}

}

inline void __RECEAVE_UIN(DWORD* data,char*c)
{
	_ASSERT(_log);
	if(!UIN)
	{
		data++;
		DWORD id=*data;
		data++;
		if(!strcmp((char*)data,c))	//is it us??
		{
			UIN=id;
			((_log)(Server,"%s receaved NET-UIN %d.",c,UIN));
		}
	}
}

inline void __UPDATESOUND(SoundClient*SC,DWORD *sound00,DWORD sn)
{
	_ASSERT(Sound&&*Sound&&residentsound&&SC&&uploadsound&&sound00);
	if(!((residentsound)(*Sound,*sound00,SC->GetTime(sn))))
		*sound00=((uploadsound)(*Sound,SC,sn));
}

//does client area calcs for the user
//you should move your dll's area after installing a new one or disable the old dll
//so you don't overdraw the new dll
inline void __DLLINSTALL(char *thisdll,char *newdll,float a[4])
{
	_ASSERT(getclientarea&&importdll&&(*Importer));
	float _a[4];
	((getclientarea)(*Importer,thisdll,_a));
	//calc area
	_a[0]+=_a[2]*a[0];
	_a[1]+=_a[3]*a[1];
	_a[2]*=a[2];
	_a[3]*=a[3];
	((importdll)(*Importer,newdll,_a));
}

inline void __SAVEDLLINSTALL(char *thisdll,char *newdll,float a[4])
{
	_ASSERT(getclientarea&&importdll&&(*Importer)&&isregistered);
	if(((isregistered)(*Importer,newdll)))return;
	float _a[4];
	((getclientarea)(*Importer,thisdll,_a));
	//calc area
	_a[0]+=_a[2]*a[0];
	_a[1]+=_a[3]*a[1];
	_a[2]*=a[2];
	_a[3]*=a[3];
	((importdll)(*Importer,newdll,_a));
}

inline void __SETWINDOW(char *thisdll,float a[4],RenderClient* rc)
{
	_ASSERT(getclientarea&&(*Importer));
	float area[4];
	((getclientarea)(*Importer,thisdll,area));

	float x_delta;
	x_delta=rc->glr->width*area[2];
	float y_delta;
	y_delta=rc->glr->height*area[3];
	rc->window.TopLeft.x=rc->glr->width*area[0]+a[0]*x_delta;
	rc->window.TopLeft.y=rc->glr->height*area[1]+a[1]*y_delta;
	rc->window.width=a[2]*x_delta;
	rc->window.height=a[3]*y_delta;
	rc->window.BottomRight.x=rc->window.TopLeft.x+rc->window.width;
	rc->window.BottomRight.y=rc->window.TopLeft.y+rc->window.height;
	rc->window.Center.x=rc->window.TopLeft.x+rc->window.width/2;
	rc->window.Center.y=rc->window.TopLeft.y+rc->window.height/2;
}

inline void __DLLRUN(char*name)
{
	_ASSERT(importfunc);
	lpFunc Init;
	Init=((importfunc)(*Importer,name,"DLLInterface"));
	try
	{
		((Init)(push,Server));
	}
	catch(...)
	{
		((_log)(Server,"An error occured while running :%s:",name));
	}
	lpFunc DLLRequest;
	DLLRequest=((importfunc)(*Importer,name,"DLLInterface_Init"));
	try
	{
		((DLLRequest)());
	}
	catch(...)
	{
		((_log)(Server,"An error occured while running :%s:",name));
	}
}

inline void __DLLUNLOAD(char* name)
{
//	_ASSERT(importfunc);
	try
	{
//		lpFunc shutdown=((importfunc)(*Importer,name,"DLLInterface_ShutDown"));
//		((shutdown)());
		((push)(Server,2,UNLOAD_DLL,name));
	}
	catch(...)
	{
		((_log)(Server,"An error occured while trying to unload %s.",name));		
	}	
}

inline bool __CHECKSERVER(char* dllname)
{
	_ASSERT(HostGame&&_log);
	if(*HostGame)
	{
		_ASSERT(Net);
		((_log)(Server,"ServerDLL '%s' successfully installed by (%d).",dllname,(*Net)->PlayerId));
	}
	else
	{
		if(Net)
			((_log)(Server,"Failed to install ServerDLL '%s' by (%d).Server unavailable.",dllname,(*Net)->PlayerId));	
		else 
			((_log)(Server,"Failed to install ServerDLL '%s'.Server and Network unavailable.",dllname));	
		__DLLUNLOAD(dllname);
	}
	return *HostGame;
}

inline void __SETVALUE(char * name,void* value)
{
	_ASSERT(DLLData);
	_ImpFunc *func=DLLData->funcs;

	while(strcmp(func->name,name))
		func=func->next;
	func->func=(lpFunc)value;
}

inline void __GETVALUE(char * name,void*** value)
{
	_ASSERT(DLLData&&isregistered);
	_ImpFunc *func=DLLData->funcs;
	if(!__ISREG(name))value= NULL;

	while(strcmp(func->name,name))
		func=func->next;
	(*value)=(void**)(func->func);
}

inline void __SAVEREG(char* name,...)
{
	_ASSERT(isregistered);
	va_list argptr;

	va_start( argptr, name );
	void* fa=va_arg( argptr , void* );
    va_end( argptr );

	if(!__ISREG(name))
		__REG(name,fa);
	else __SETVALUE(name,fa);
}

inline void __SETFOCUS(DWORD wnd)
{
	for(int i=0;i<Server->Num_Windows;i++)
	{
		if(Server->windows[i]->number==wnd)
		{
			RenderClient* hRC=Server->windows[i];
			for(int i2=i;i2<Server->Num_Windows-1;i2++)
				Server->windows[i2]=Server->windows[i2+1];
			Server->windows[Server->Num_Windows-1]=hRC;
			break;
		}
	}
}

inline void __CALLBACK_VOID(int *nu,void* data,Camera_* cam,RenderClient *rc){}

inline void __REGNET(char* dllname)
{
	_ASSERT(dllname&&senddata&&Net&&Net_Inited);
	_ASSERT(Server->ServerId&&*Net_Inited);
	DWORD buf[100];
	DWORD* bp=buf;
	*bp=3+strlen(dllname)/4+1;
	bp++;
	*bp=(*Net)->PlayerId;
	bp++;
	*bp=REQUEST_NETID;
	bp++;
	memcpy(bp,dllname,strlen(dllname)+1);
	((senddata)(Net,buf,Server->ServerId));
}

class EventHandler
{
public:
	DWORD* Fifo;
	DWORD* F_sptr;
	DWORD* F_eptr;
	bool ptr_xchg;
	EventHandler();
	~EventHandler();

	void Error(char *c);
	void Push(WORD size,...);
	void* Pop();
	bool Empty();

};

enum Events
{
	MOUSE_OVER,
	MOUSE_LEFT,
	MOUSE_MOVE,
	MOUSE_LEFT_BUTTON_DOWN,
	MOUSE_RIGHT_BUTTON_DOWN,
	MOUSE_LEFT_BUTTON_UP,
	MOUSE_RIGHT_BUTTON_UP,
	KEYBOARD,
	FORCED_UPDATE,
	NUM_EVENTS
};

#endif



