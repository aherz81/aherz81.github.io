//!!!! do not change this header file !!!!

#ifndef CS_COM
#define CS_COM
/*
<<<<<<<<<<<<<<<<<<<<<<client-server-communication>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
<	- do not change given values													>
<   - you may add values to the end of the list but be shure to use					>
<	  the latest ver as you'll breake compatiblity with other versions otherwise	>
-------------------------------------------------------------------------------------
Version 1.0000
*/
//client cmds

enum Msg
{
	INIT,					//no args		do not call from dll
	GET_NET,				//no args								->	stars retreaving of net messages
	SHUTDOWN,				//no args								->	kills the app
	REQUEST_SERVERID,		//UNUSED		do not call from dll
	REPLY_SERVERID,			//DPID ServerId,DWORD ServerTime		->	set new server
	RETRY_CONNECTION,		//no args		do not call from dll
	GFX_INIT,				//no args		do not call from dll
	GFX_UPDATE,				//DWORD number_of_window				->	updates a certain widow twice
	GFX_UPDATE_ALL,			//no args								->	updates all wndows
	REQUEST_DATA,			//UNUSED		do not call from dll
	ASSIGN_DATA,			//UNUSED		do not call from dll
	REQUEST_JOIN,			//UNUSED		do not call from dll
	CONFIRMED_JOIN,			//UNUSED		do not call from dll
	DENIED_JOIN,			//UNUSED		do not call from dll
	CREATE_DPLAY,			//UNUSED		do not call from dll
	SFX_INIT,				//no args		do not call from dll	->	inits sound
	NOP,					//no args								->	does nothing
	GET_VALUE,				//char name,void** adress				->	writes the adress of name into adress
	RUN_DLL,				//char dllname,char funcname			->	calls funcname from dllname
	UNLOAD_DLL,				//char name								->	unloads name
	REQUEST_WINDOW,			//void* update_func,void* render_func	->	two funcs used to update the window
							//,char dllname,float x,y,xsize,ysize,	->	name of the dll the 2 funcs are in and the size of the window
							//float r,g,b,RenderClient** adr		->	clear color (0,0,0) means no clearing,if this adress is !=0 
							//											the adress of your renderclient is returned
	DELETE_WINDOW,			//DWORD num								->	deletes window num
	UPDATE_DISPLAY,
	NET,					//??									->	special network message not handled by client/server
	REQUEST_NET,			//void_netupdate_func_dwordp,dword size	->	the passed function will be called everytime the server app receaves some 
							//message via network
	REQUEST_EVENTS,			//window*,void_event_func				->	notifys passed func of mousemove,keydown,etc
	DELETE_NET,				//void_netupdate_func_dwordp,dword size	->	stops notification(must be called when uninstalling a dll which requested the 
							//REQUEST_NET feature
	DELETE_EVENTS,			//void_event_func						->	stops notification(similar to DELETE_NET)
	CHANGE_RES,				//xres,yres,bitdepth					->	change resolution
	CLEAR_BUFFERS,			//no args								->	clear front/backbuffer once
	REQUEST_NETID,
	ASSIGN_NETID,
	REQUEST_PLAYERLIST,
	ADD_PLAYER,
	NEW_SERVERID,
	IS_SERVERUP,
	NICK,
	MAX_PLAYER,				//dword num								->	set servers max player amount
	MIN_PING,				//dword num								->	set server's min ping
	EOP						//none			->	stop FIFO processing andreturn control to user dlls
};


#endif