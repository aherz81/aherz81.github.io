#include <windows.h>
#ifndef CLASS_DLLIMPORTER
#define CLASS_DLLIMPORTER

#include "Memory.h"
#include "renderclient.h"

//typedef int (*lpFunc)(int*nu,void* dat,Camera_*cam,RenderClient *rc);
typedef void* (*lpFunc)(...);

struct _ImpFunc
{
	lpFunc func;
	char *name;
	char *link;
	_ImpFunc *next;
};

struct _DLLData
{
	HINSTANCE hi;
	char *name;
	_ImpFunc *funcs;
	_DLLData *next;
	float ClientArea[4];
};

class DLLImport : public Sys_Memory
{
public:
	_DLLData DLLData;
	DLLImport();
	~DLLImport();
	void __cdecl GetClientArea(char *dllname,float area[4]);
	void __cdecl RegisterObject(char *name,float area[4],void* fdata);
	void __cdecl ImportDll(char *name,float area[4]);
	void __cdecl UnloadDll(char *dllname);
	lpFunc __cdecl ImportFunc(char* dllname,char *funcname);
	void __cdecl Register(char* name,...);
	void *__cdecl GetAdress(char* name);
	bool __cdecl IsRegistered(char* name);
	void __cdecl AddLinkInfo(char* name,char*info);
	void ImportList(char *name);
};

#endif