
#ifndef INI_FILE
#define INI_FILE

#include "File.h"

class Sys_IniFile : public Sys_File
{
protected:
	char** Args;
	int NumArgs;
public:
	Sys_IniFile();
	~Sys_IniFile();

	virtual void open(char * fn);
	virtual void close();
	int IsArg(char * arg);
	void AddArg(char * arg);
	char * GetArg(int id);
	int GetNumArgs();
	
};


#endif