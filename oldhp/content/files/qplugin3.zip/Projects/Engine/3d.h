#include "windows.h"

#ifndef MESH_H
#define MESH_H

#include "global.h"

#include "mesh.h"
#include "overlay.h"

enum _3dData
{
	CELL,			//indoor room
	HEIGHTMAP,		//landscape
	CELL_MAP,		//map of cells//only trias with normal.y>0.2;maybe symbols for objects
	HEIGHTMAP_MAP,	//map of landscape
	MESH,			//single object
	OVERLAY2D			//text or similar 2d stuff
};

enum _Axe
{
	X,
	Y,
	Z,
	USER1,
	USER2,
	USER3,
	CAMX,
	CAMY,
	CAMZ,
	NONE
};

struct Camera_
{
	float nearclip;
	float farclip;
	float Pos[3];
	float Dir[3];
	float Up[3];
	float TDir[3];
	float TUp[3];
	float TSide[3];
	_Axe  Rot[3];
	float Angle[3];
	float *User[3];
	float fov;
	float zoom;//1 is standart
	float aspect;
	_Axe  *AddRot;
	float *AddAngle;
	BYTE  AddNum;
	float T2Dir[3];
	float T2Up[3];
	float T2Side[3];
};

//overlay


#endif