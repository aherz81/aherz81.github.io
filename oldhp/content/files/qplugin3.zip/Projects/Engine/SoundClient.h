/***********************************************************************	
� 1998 Alex Herz - All rights reserved

	Programmer:	Alex
	Current Version:	1.0

	Update History:
	Programmers Initials	Date	Change Made	Version
	
	Alex					15.9.98 Initial Revision
***********************************************************************/
#ifndef __DSOUND_CLIENT
#define __DSOUND_CLIENT

#include <windows.h>
#include "mmsystem.h"
#include "conio.h"
#include "stdio.h" 
//#include "memory.h"
#include "net.h"
//#include "sound.h"

class SoundClient
{
public:
	LPDIRECTSOUNDBUFFER     *lpSB;
	LPDIRECTSOUND3DBUFFER   *lpSB3d;
	DWORD					*time;
	DWORD					NumSounds;
	DWORD					MaxSounds;

public:
	SoundClient(){};
	~SoundClient(){};
	void __cdecl Init(DWORD num);
	LPDIRECTSOUNDBUFFER* __cdecl GetSB(int num);
	LPDIRECTSOUND3DBUFFER* __cdecl GetSB3d(int num);
	DWORD __cdecl GetTime(int num);
	void __cdecl Set3dSoundPos( float pos[3] ,int num );
	void __cdecl DeleteSB(int num);
	
};


#endif
