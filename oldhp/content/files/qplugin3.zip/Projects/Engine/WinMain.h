#include <windows.h>

#include "Memory.h"
#include "IniFile.h"
#include "Server.h"

#ifndef CLASS_WINMAIN
#define CLASS_WINMAIN

#define APPNAME "TacTech"
#define CLASSNAME "Main Window"


class Sys_WinMain : public Sys_Memory
{
public:
	bool Active;
	HWND hwnd;//WindowHandle
	HINSTANCE hInstance;
	int nShowCmd;
	Sys_IniFile *IniFile;

	HDC hdc;
	HPEN hpen, hpenOld;
	PAINTSTRUCT ps;
	RECT rect,orect;
	HFONT hfont;

	int width;
	char ScreenBuffer[200][200];
	int Lines;
	char ClassName[255];
	char AppName[255];

	int DrawTexttoWindow(char * Text,int x, int y,int width);
	void WriteText(char * Text);
	void TextOut( const char *fmt, ... );
	void WinMain(HINSTANCE hInstance,int iCmdShow,char *szAppName, char *className);
//	virtual void Error(char*str,...);
	
	~Sys_WinMain();
	Sys_WinMain();
	void __cdecl ShutDown();
	void XCreateWindow();
};

#endif