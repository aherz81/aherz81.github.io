#include <windows.h>
#include <dplay.h>
#include <process.h>

#include "global.h"
#include "memory.h"
#include "net.h"
#include "renderclient.h"
#include "dllimporter.h"

#ifndef CLASS_CLIENT
#define CLASS_CLIENT

#define MAX_WINDOWS 0x1000

#define MAX_PLAYERS 0xff //(max value in NumPlayer)

struct Player_
{
	DPID ID;
	DWORD Time;
	char* nick;
	DWORD ping;
};

typedef void (__cdecl*void_netupdate_func_dwordp)			(DWORD* dp);
typedef bool (__cdecl*void_event_func)						(bool mpos,int mx,int my,bool b1,bool b2,bool key,BYTE state,void *data);

struct ClientList_
{
	void_netupdate_func_dwordp func;
	ClientList_ *next;
};

struct ClientEventList_
{
	void_event_func func;
	ClientEventList_ *next;
	RenderClient *window;
	bool WantUpdate;
};

class Sys_Client : public Sys_Memory
{
public:
	Player_ *Player[MAX_PLAYERS];
	BYTE NumPlayer;
	
	DWORD* Fifo;
	DWORD* F_sptr;
	DWORD* F_eptr;
	bool ptr_xchg;
	Sys_Net* Net;
	HANDLE  FifoHandle;
	RenderClient *windows[MAX_WINDOWS];
	WORD ZTable[MAX_WINDOWS];
	BYTE Num_Windows;
	DLLImport *Importer;
	ClientList_ List;
	ClientEventList_ EventList;
	int MouseWindow;
public:
	DWORD Time;
	long TimeOffset;
	DPID NetId;
	DPID ServerId;
	bool Connection;

	Sys_Client();
	~Sys_Client();
	void ShutDown();
	void __cdecl Push(WORD size,...);
	int __cdecl FindWnd(int x,int y);
	void PushData(void* data);
	virtual void* Pop();
	void ProcessFifo(DWORD* data);
	void UpdateGFX();
	DWORD GetIndex(DPID id);
	void AddPlayer(DPID id,DWORD ping);

	void AddList(WORD x,...);
	void DelList(WORD x,...);
	void AddEventList(RenderClient *window,...);
	void DelEventList(WORD x,...);
	
	int FindWindow(int x,int y);
	void UpdateMouse();
	void SetNick(DPID id,char* nick);
	void __cdecl MoveToTop(WORD w);
};

void ClientThread(void* v);

#endif