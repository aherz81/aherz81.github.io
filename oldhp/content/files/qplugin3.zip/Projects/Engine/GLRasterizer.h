#ifndef GLRASTERIZER__
#define GLRASTERIZER__

#include <gl\gl.h>
#include <gl\glu.h>

#include "windows.h"
#include "texmanager.h"
#include "3d.h"


#define OSR2_BUILD_NUMBER 1111

struct Mode_Info
{
	int xres,yres,bpp;
	float fov;
};


typedef struct
{
    int   width;
    int   height;
    int   bpp;
    int   flags;
    int   frequency;
}screen_res_t;

typedef struct
{
    HINSTANCE        hInstance;
    int              iCmdShow;
    HWND             hWnd;
    HDC              hDC;
    HGLRC            hGLRC;
    BOOL             bActive;
    BOOL             bFullScreen;
    ATOM             wndclass;
    WNDPROC          wndproc;
    int              width;
    int              height;
    int              bpp;
    BOOL             bChangeBPP;
    BOOL             bAllowSoft;
    char            *szCmdLine;
    int              argc;
    char           **argv;
    int              glnWidth;
    int              glnHeight;
    float            gldAspect;
    float            NearClip;
    float            FarClip;
    float            fov;
    int              iResCount;
    screen_res_t    *pResolutions;
    int              iVidMode;
}windata_t;

typedef struct
{
    int  width;
    int  height;
    int  bpp;
}devinfo_t;


class GLRasterizer : public TexManager 
{
public:
	HDC hDC;
	HGLRC hRC;
	LONG width,height;
	float NearClip,FarClip,Fov,Aspect;

	bool Mouse;
	int MouseX;
	int MouseY;
	int MPx;
	int MPy;
	int lastx,lasty;
	DWORD MP;
	DWORD MID;

	GLRasterizer();
	~GLRasterizer();
	void OGL_Init(float f,float nc,float fc);

	bool __cdecl ChangeResolution(LONG w, LONG h, LONG bitdepth);
	bool SetupPixelFormat(HDC hdc);
	void __cdecl DrawQuad(WORD id,float x, float y, float xsize, float ysize,float zoom,float r, float g, float b, float a,float z);
	void __cdecl DrawText(char *text,float x,float y,float size, float zoom,float r, float g, float b, float a,float z);
	void __cdecl SwapBuffer();
	void __cdecl UpdateMouse(int x,int y,bool restore,bool save);
	void __cdecl InitMouseBuffer(int x,int y,bool restore,bool save);
	void __cdecl SetMousepointer(DWORD mp,int x,int y);
	bool __cdecl ChangeVidMode(LONG w, LONG h, LONG bitdepth);
};




#endif