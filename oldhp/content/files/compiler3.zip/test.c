//#pragma enable debug_info	

#define _ALLIGN DWORD			

#define PRINTF

#include "defs.h"

DWORD d2=0;

#compile "test2.c"

extern DWORD style;

__cdecl DWORD Test()				
{
	for(int i=0;i<20;i++)
	{
		d2--;	
	}

	DWORD dd;
	d2=((7&2)*3+10)/2;


	printf("Original d2:%d",d2);
	NEWLINE;

	if(d2==8)
	{
		d2=16;
	}
	else
	{
		d2=style;
	}
	char*chp=NULL;

	printf("New d2(after comparison to 8):%d",d2);
	NEWLINE;

	return d2;
}

__cdecl void TTT(float*bb)
{
	d2=10;
}
