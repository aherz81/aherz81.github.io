@echo off
vc_rel3 test.c
c:\vsm_read2.exe e test.vxe
notepad compiler.log
