#ifndef __DEFS__
#define __DEFS__

#define MY_PI 3.14

struct test
{
	DWORD dd,aa;
	char* nn;
	test* ttt;
};

#ifdef PRINTF

#define _DBGMSG "printf support"

#define NEWLINE printf("%c%c",13,10)
#define TAB		printf("%c",9)

__cdecl extern void printf(char*c,?);	//the only extern function available in the VM

#endif

#endif