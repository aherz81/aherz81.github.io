
__cdecl DWORD Test2()				
{
	DWORD dd;
	d2=((7&2)*3+10)/2;

	printf("Original d2:%d",d2);
	NEWLINE;

	if(d2==8)
	{
		d2=16;
	}
	else
	{
		d2=15;
	}
	char*chp=NULL;

	printf("New d2(after comparison to 8):%d",d2);
	NEWLINE;

	return d2;
}

__cdecl void TTT2(float*bb)
{
	d2=10;
}