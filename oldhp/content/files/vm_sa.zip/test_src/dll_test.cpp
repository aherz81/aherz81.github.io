// dll_test.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

#define STAND_ALONE_VM	//MUST BE DEFINED!!

#include "..\ivm.h"


//func to be called by script..make it __cdecl!!(even for member funcs)
__cdecl int test_func(int d)
{
	return d+2;
}


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.

	InitVM();//init VM


	//tell VM that we have a func called "test_func" which can be called by script
	Reg("test_func",test_func);
	Addlinkinfo("test_func","__cdecl int test_func(int)");

	//load sap.vxe (stand alone project.virtual executable)
	if(UploadScript("scripts\\sap.vxe"))//try to load init script
	{
		DWORD ret_val;
		//call a function which should be inside the script
		//pass number of arguments for function(2) and arguments("Argument passed from real binary.",10)
		Exec("__script int main(*char,int)",&ret_val,2,"Argument passed from real binary.",10);

		//script actually returns the return vale of our function 'test_func'
		//and passes the second argument passed to the script to that function..
		//so the function calcs: 10+2 (=12)...so ret_val should be 12 if things worked right
		if(ret_val==12)
			MessageBox(NULL,"Script successfully run","Info",MB_OK);
	}

	ShutDownVM();//called once when finished with any kinda script stuff

	return 0;
}



