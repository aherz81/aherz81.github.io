// library.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "library.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

void my_func(int*ip,float**fpp,int i)
{
	MessageBox(NULL,"func 'my_func' inside library.dll successfully called","Info",MB_OK);	
}


void Vm_Interface(reg_func rf,link_func lf)
{
	//here inside the function it can register funcs/vars
	//where rf is a function pointer pointing to Reg();
	//and lf points to Addlinkinfo()

	rf("my_func",my_func);	//add an item to the registry(along with its adress)

	lf("my_func","__cdecl void my_func(*int,**float,int)");//specify the type of an itam already in the registry


	MessageBox(NULL,"func registered","Info",MB_OK);
}
