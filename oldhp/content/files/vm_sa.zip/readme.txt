This zip contans :

-	the complete script IDE(editor,debugger,compiler,vxe2asm tool,help,...)
	ScriptEdit.exe allows you to interface with these easily.

-	a sample application 'test.exe' with source and msvc6 workspace which loads the virtual machine 'vm_sa.dll'
	and executes(loads etc) a  (very little) script 'scripts\sap.vxe' where native c/c++ functions are 
	called from inside the script

-	a sample script 'scripts\sap.vxe' with sources (sap folder) and project file 'scripts\sap\sap.prj'

-	a sample library 'library.dll' wich is imported by the sample script 'scripts\sap.vxe',
	the library contains a function which is exposed to the virtual machine 'vm_sa.dll' and is then
	called by the script 'sap.vxe'

-----------------------------------------

to include the vm into your .exe include the 'vm_sa.lib' in your project->settings->link->modules list
then add these lines to the source file:

#define STAND_ALONE_VM	//MUST BE DEFINED!!
#include "ivm.h"

see sources of test.exe for an example of how to load/execute a script which calls native functions

-----------------------------------------

usage of library.dll is optinal..it is there as an additional example..showing how to import
a 'library' into a script..for functionality that is commonly used..

to remove dependency of the script sap.vxe from that library you have to remove:

#bind 'library.dll'

and all references to 'my_func'

-----------------------------------------

additinally the script sap.vxe uses some class called 'my_class'
again this is only for demonstration purposes..as some of the class syntax differs from
standart C++ syntax (constructor/destructor for eg)

-----------------------------------------

the block of assembler code within the '__asm' statement
is for demonstration iussues as well..there is no need to call the cpuid instruction or anything..
but it is possible..

-----------------------------------------

finally I wanted to note that it is also possible to import native classes/variables into the script..
to do so you have to register those items just as we do here in test.exe for 'test_func(int i);'..

the only difference is the syntax which describes the item..for 'test_func(int i);' we specified:

Reg("test_func",test_func);
Addlinkinfo("test_func","__cdecl int test_func(int)");

for a variable .. declared like this:

DWORD *my_var[10];

we specify:

"__mem DWORD* my_var" (note that there is a space after the '*' and that we don't specify the '[10]')

now for classes:

a class declared like this:

class MClass
{
	DWORD d;
	DWORD function(int* i);
};

MClass* mcp = new MClass;

is passed to the script with following describtions:

1stly we register+describe the class pointer:

Reg("MClass* mcp",&mcp);	//note that we register the adress!!! of mcp!!!
Addlinkinfo("MClass* mcp","__mem MClass* mcp");

secondly we describe all functions:

Reg("MClass::function",mcp->function);
Addlinkinfo("MClass::function","__cdecl DWORD MClass::function(*int)");

note:

	-	the '*' for func arguments preceedes the vartype
	-	no var names are specfied
	-	class prefix 'MClass::' is specified 
	-	we register the func's adress: Reg("MClass::function",mcp->function);


(c) Alex Herz