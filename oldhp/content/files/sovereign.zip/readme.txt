I've included 3 LITTLE levels..which were created for test purposes mostly..
After starting you press Escape to jump to the next level, after the thrird escape you exit automatically
(unless you change the script game2.con).
Before starting put your favourite audio-cd into your cdrom!

while in a level you can open the console(press TAB) and type
'indoor 0' + enter to switch into outdoor view..(you'll see an ugly landscape)
type 'indoor 1' to go inside again..
actually it's a combined indoor outdoor engine..but quake2 .bsp levels seldomly have windows to the outside :)
so I had to put this shit for testing in

oh ya..press escape to leave console!

Within the game you steer with mouse+w,s,a,d for movement...

ONLY FOR VOODOO users!!!
I use direct frame buffer manipulation..so it might not work on all voodoos outthere..bungee and rush makes prob
as far as I know.
DONT'T EXSPECT too much..I've coded this years ago..my first little 3d engine mna..this IS old..

Alex Herz
