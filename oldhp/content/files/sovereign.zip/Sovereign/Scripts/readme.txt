Ver 2

Filetypes:

.scc      source file
.shh     header file

.sap     mapfile (needed to run the script but needn't be recreated for every compilation...only if a header file has changed)
.sbj      obj file...the compiled binary code

ScriptC.exe scriptcompiler syntax ( scriptc sourcefile )


--------------------------------------------------------------ScriptDucumentation------------------------------------------------------------

Layout of source files (.scc):

1. pragmas

#pragma enable binary 		
// weather to compile into a binary object file(.sbj) or text one 
// !!!!!!!!must always be enabled
#pragma disable debug_info	
// weather to include debuginfo into object file...if enabled you can debug the script more easily but it will be executed much slower
#pragma enable map_file
// !!!!!!!!should always be enabled

-all 3 pragmas must be defined..but they can be defined in any order...
-you can either enable or disable a pragma...see comments for their usage
-you may not change pragmas later in the source file
-the pragmas MUST be the first commands

2. includes

#include std.shh 		// standart include file...must be included or you have no symbols available at all
#include MyVars.shh	// additional include files (to define your local vars+funcs in)

-you may include files anywhere in the source file (but not before the pragmas) 
-you must include the header file that contains the symbol definition (see Layout of header files) before U use that symbol
-you may use the #include command in header files(.shh) to inclde other files..so U needn't include all files in the source file

{about Symbols}
-you may use only symbold which were previously defined in a header file...otherwise the compiler will not translate the the file and report an error
-any statement U use (but no comments) is a symbol...any name of a var , of a func, even letters, digits and var types or signs(* + - /)
-I was too lazy to write a real lexer so you have to put a space between any symbol U use so that the compiler can recognize it
-that also forces you to predefine any var or func U use (see Layout of header files) in a heaer file

3. comments

/* comment */
-you may put comments anywhere in the source file (but not before the pragmas) these won't be added to the debuginfo thought
-you cannot use '//' to comment out a line..you must use /* */ and have a space between the comment and its start/end symbols(/* and */)
-you may not have comments within comments

4.  code

Note: 
I tryed to keep the code c similar and I'll only show up the main differences between this script an c here

4.1 'extern_callable'

-all functions must be defined as extern_callable 
-you cannot pass arguments nor return values using script funcs (funcs's which's source is in the script) but all vars are global so you can 
pass args via global vars


4.2 var types

valid var types are:

	c like:

		float 
		int 
		Vec
		WORD
		DWORD
		char

	special:

		ptr		//is more or less equivalent to void* in c , ptr(=pointer)
		string		//somewhat like char*

explanation of special types

	ptr

		-unlike in c where pointers are pointing on a certain kind of data (WORD*,char*,...)
		ptr is a unified version...so you can assign the adress of any type of var to a ptr
		
		-as a pointer can (at least in this script) only hold adresses of vars you don't need the '&'
		infront of a var to say you want it's adress...eg:

		scriptcode:
			ptr MyPtr ; //define it
			int MyInt ;

			MyPtr = MyInt ; //now MyPtr contains the adress of MyInt

		c dode:
			int* MyIntPtr ;
			int MyInt ;
			
			MyPtr = &MyInt; 

		-if you assign the value of a ptr back to a var you need the indirectness '*' like in c and you must cast 
		(see chapter 4.3 cast as casts highly differ from c ) the pointer (unlike in c) as ptr has no type..the advantage is you 		
		could assign the value of this pointer to any type of var ...eg:

		scriptcode:
			ptr MyPtr ; 
			int MyInt ;
			char MyChar ;

			MyPtr = MyInt ; 
			MyChar = * ( MyPtr ( char ) ) ;

IMPORTAND NOTE:	MyChar = * ( MyPtr (string) ) ; is wrong..as MyChar is a char and no string... (though there is the indirectness ('*'))

		c code:
			int* MyIntPtr ;
			int MyInt ;
			char MyChar ;
			
			MyPtr = &MyInt; 
			MyChar = *((char*)MyIntPtr);

		-if you cast a var to (ptr) it will be treated like a ptr in this codeline..that means if you assign a var to a to (ptr) casted var
		not the value will be copyed to this var but the adress of the var will be overwritten with the adress of tge other var and 
		the contents of the var will be lost (this is a valid operation)
		that way you can create a pointer with type:

		scriptcode:
			char MyChar [ 0 ] ;
			string MyString [ 5 ] ;
			
			MyString = " t e s t " ;


	string
		
		-string is kinda special typy I introduced for U..yeah U heared right.for U :)...U are given acces to some funcs 
		(yet MessageBox only) whichenable you to output some text..before the stringtype was existent U had to 
		make an array of char and assign the ascii values to each index ..which was kinda ugly..
		-the string var is the only var to which letters can be assigned
		-the letters must be in quotes like this : " l e t t e r s " and remeber..there must be space between every symbol..
		and as 'letters' is no symbol there must be one between every letter
		-'_' means ' '(= space) when between " "..you cannot use ' ' to create a space...
		-you can do 4 things with strings:
			
			1. assign characters to it (explained above)
			2. pass it to a func
			3. do pointer operations on it (see 4.2 var types -> explanation of special types -> ptr )
			4. cast(see chapter 4.3 cast as casts highly differ from c ) it to another type and assign 
			or compae it withe that type of var
		
	about defining vars 

		-to define vars you firstly need to predefine em for the compiler as valid symbol (see Layout of header files)
		-2 ways to define a var:

			vartype varname ;
			vartype varname [ size ] ;

		script eg code:

			float MyFloat ;			//normal float
			float MyFloatArray [ 3 ] ;		//array of float with size 3 (0..2)
			
	how to access arrays

		-you cannot index arrays like in c but you can access it like some allocated array in c (with offsets)
		-the offset is (unlike in c) always in bytes so to access th second float we have to add the size of float times the index
		(1*4) and use that as offset
		-U may use vars (of type in or OWRD or DWORD) to specify the offset
		-U may cast the var for which the offset is specifiyed but not for the var representing the offset nor are you allowed 
		to add an offset to the var representing the ofset
		-'*' indiectness is not needed..at least not for the the array its self...if you want to assign the value of a ptr to 		
		MyFloat Array you need he indirectness for the ptr (* ptr )
		-notice the space between every digit of the number whic is assigned to MyFloatArray and their meaning for symbols

		script eg code:

			float MyFloatArray [ 3 ] ;	
			WORD Offset ;

			( MyFloatArray + 4 ) = 3 . 4 5 6 7 ;
			
			Offset = 4 ;
			( MyFloatArray + Offset ) = 3 . 4 5 6 7 ;


		-use the table printed below to lookup the size of vars and for app internal structs (will be introduced later) use the given 		
		script external vars (see 4.4 script external funcs + vars )

		VAR SIZE TABLE

		char		= 1	byte(s);
		WORD		= 2	byte(s);
		int		= 4	byte(s);
		DWORD	= 4	byte(s);
		float		= 4	byte(s);
		Vec		= 12	byte(s); //(3*float)


		-to calc offsets for script external structs you can use sizeofstruct..(replace 'struct' by the name of the struct you mean..)
		(recommented..as structs might change with different versions... )
		-these vars are defined in std.shh!!
		-for standart types(float, int etc. you might use these though using hard byte offsets will probably be faster
		-see model.h for def of the different strucs...

	assigning values to a var

		-u may do one mathematical operation max while assigning a values...egs:
		-if you assign a float (value, float vars must be casted ) or equivalent then it will be truncated

		script eg code:

			WORD Offset ;

			Offset = 3 . 4 5 + 2 . 5 5 ; //valid...ony one math. operation  ( floats will be truncated ) 
			( Offset + 1 ) = 2 / 4 ; //valid

			Offset = 1 + 2 *3 ; //invalid as 2 math operations
			Offset = ( 1 + 2 ) * 3 ; //invalid brakets aren't supported and these are more than 1 math operation

	assigning vars to vars

		-works as with values (only 1 math operation) and you may use offsets + casts

4.3 casts

	-u need to cast:
		1.numbers(values) U pass to func as the script doesn't know what type of data the func want's to have
		2.pointers (ptr) you assign to a non pointer var 

	-u don't need to cast
		1.vars U pass to a func	

	how to cast

		-unlike in c the cast is placed behind the var to be casted
		-casts are in 2 brakets unless you're casting a value in a script external functioncall(unlike in c where you need only one)

		script eg code
				
			ptr MyPtr ; 
			int MyInt ;
			char MyChar ;

			MyPtr = MyInt ; 
			MyChar = * ( MyPtr ( char ) ) ;    // ( MyPtr ( char ) )  valid cast
			

4.4 script external funcs + vars

	-you can(and have to probably) pass args to script external funcs (like 'MessageBox')..
	-you can aswell pass absolute values to script external funcs but these need to be casted (see chapter 4.3 casts)
	 (absolute values need only one pair of barakets)

	eg:

		MessageBox ( 0 ( WORD ) , ...

	-u only need to specify indirectness ('*') if desired to pass the var's value..if you don't 

	return values

		-if a function (like 'MessageBox') returns a value it is placed

			1. in the global var retval_float if the returntype is float
			2. in the global var retval if the returntype != float.. the var retval is of type ptr and you need to cast 
			it properly to access it's value (see 4.3 casts)
	
!	carefull calling external funcs				
		
			-for speed reasosn the script will push any args you pass to a func (no matter how many the func needs) and call the func..
			so if you pass shit the func it is likely to blow up...

	vars

		-you should be provided (as soon all is implmented) with all vars you need to script object behavior+ai 
		(depending on the object defs you make objects.ini)
		-yet you have the retval/retval_float vars (see 4.4 script external funcs+args -> retun values) 
		and the sizeofstruct vars (introduced in 4.2 var types -> how to access arrays)
		and the var 'SCP_DBGOutput' which is importand for debugging the script..(see chapter debugging)


optimizations
	
	-function calls to app internal funcs are rather fast..so use rather the given funcs than your own 
	(for a list of given funcs look std.shh)
	-try to keep the commands within an if block low
	-look if the member of the struct U want to access is already given as a var instead of calcing its offset 
	 yourself
	-short code is fast code!!
	-execution without debug_info is much faster
	-only binary code can be executed..if ya disable pragme binary the code cannot be run...



Layout of header files (.shh)

1. what is a header file good for?

	-the compiler reads the header file and saves a reference of every symbol which is defined within a header file.
	-then he gives a unique ID (0-0xfff) to every symbol.
	-now while compiling the source file is translated using these IDs so if U use a symbol which hasn't been
	defined it has no ID and can't be translated..so you have to predefine every var U use and every func U create

2. how to define symbols?

	-there are free types of symbols:

		1. EXT varname -> predefines a var which is provided by the game (no scriptcoder should change these...)
		2. DEF varname -> DEF is absolute...simply define local vars in the source file
		3. CMD funcname -> predefines a func...this func might either be provided by the game or by he script

	Note:
		I tryed to keep all funcs provided by the game within std.shh (you shouldn't change that file!!) and all 
		script provided ones in another..so you prevent yourself from mixing up your funcs and the game ones
		(exception : I placed MessageBox along with script vars and defs though it is game internal(=script external)
		cause it will probably not be used for real scripts and therefore deleted soone or later..(scripts should make 
		some monsters run and not output sensless messages :))

Debugging

		-I added some debug functions (say thank you! was  hell lot of work :- ) 
		-to debug a script you should realy start the game with nolog(prevents gdi lock) disabled and server_sleep
		(runs the game without gfx) enabled (see init.cfg) and with #pragma enable debug_info as lower described servises 
		mostly don't work without it
		-the game external var SCP_DBGOutput is initially 0...
		-as soon it is set to 1 (within your script) the game will hold at that position(within the script)
		and you can execute the script sign by sign or line by line (s key/l key) run it till next set of SCP_DBGOutput to 1 
		(r key) or open the debugconsole (c key)

		console 

			following commands can be entered in console mode:

				1. info varname 	-> will give ya adress, value, id and all importand shit about varname
				2. list_vars	-> lists all initialzed vars 
				( a var is inited(=allocated) after theline of code is passed where the var is defined eg: int MyInt ; )
				3. assign varname offset value -> assigns a value to (&varname + offset)..where value and offset are bytes
				if you assign a value to a ptr it will be assign to the locatoion the pointer is pointing to..no to the actual adress
				4. lines num_lines -> num_lines of code wil be executed..then the script will hold on again
				
Final notes

	-if you miss something (options/commands for debugging for loops or what ever) tell me and I'll consider adding it..
	-neither this compiler nor the running executeable can trace wrong offsets eg:
	
		script eg code
	
			Vec Pos ;

			( Pos + 1 2 ) = 0 . 0 1 ;

	-that might lead to an accessviolation or other vars will be overwritten

	-you're providet with the ability to access lowlevel structs as POINTS array...
	but the script is not thought to do so as it is rather slow...
	(the script is parsed at runtime...not very nice/fast but works)
	

	-I removed the need to predefine script internal vars via DEF in an .shh file
	-don't use too many vars/funcs...65534 is the max at the mo!!
