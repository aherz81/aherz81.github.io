// note: all function calls to external provided class membes have to pass
// the adress of the object the function belongs to, to solve the thiscall
// requirement

//has to be included!!
#include "..\pnpdll0005.h"

#include <gl\gl.h>
#include <gl\glu.h>
#include <math.h>

#include "..\..\SoundClient.h"
#include "..\..\Objects\CObject.h"

QObject* Desktop=NULL;

#define DLL_NAME "ttdebug.dll"
//<local vars>
char last_Commandline[200]="";		//buffer containing last executed commandline
bool CommandlineEnabled=1;			//is commandline enabled?
char Commandline[200]="";			//actually displayed comandline
bool showCursor=1;					//is cursor actually drawn?
DWORD _time;							//last update of cursor
DWORD texid=0;						//texture id
char unloadName[200]="";
DWORD MP2Id=0;
RenderClient *rc1=NULL;
RenderClient *rc2=NULL;
RenderClient *rc3=NULL;
RenderClient *rc4=NULL;
RenderClient *rc5=NULL;
int MPx=0;
int MPy=0;
BYTE MState=2;
DWORD NetId=0;
EventHandler* ButtonEvent=NULL;
EventHandler* ScrollEvent=NULL;
DWORD Scroll=0;

SoundClient* SC=NULL;
DWORD sound00=0;
DWORD sound01=0;
DWORD sound02=0;
DWORD sound03=0;

bool PASS=0;
#define MAX_PASS 50
//<Dll's funtions>

//inline bool IsKeyDown(int virtKeyCode){if (GetAsyncKeyState(virtKeyCode) & 0x8000) return TRUE;return FALSE;}
inline float absf(float x){if(x<0)return x;else return x;}

void Update_View(int *nu,void* data,Camera_* cam,RenderClient *rc);
void Render_View(int *nu,void* data,Camera_* cam,RenderClient *rc);

void updnet(DWORD*data)
{
	DPID from=*data;
	data+=2;
	if(*data==NET_RECEAVE_NETID)	//NET_ID for some dll
		__RECEAVE_UIN(data,DLL_NAME);
	else if(*data==NET_SERVERUP)	//server is running
		__GETUIN(DLL_NAME);
	else if(UIN&&*data==UIN)		//message for us
	{
		//handle message
		data++;
		((_log)(Server,"MSG0x%x '%s'",from,(char*)data));
	}
}

void pnp_log(char* txt)
{
	((_log)(Server,"pnp_log:%s",txt));
}

bool updevents(bool mpos,int mx,int my,bool b1,bool b2,bool key,BYTE state,RenderClient*hRC)
{
	static DWORD OldId=(*Rasterizer)->MP;
	if(state==1)//first means that the mousecursor just moved from another window to this one
	{
//		((setmousepointer)(*Rasterizer,MP2Id,0,-16));
	}
	else if(state==2)
	{
//		((setmousepointer)(*Rasterizer,OldId,0,-16));
	}
	MPx=mx;
	MPy=my;
	MState=state;
	return 0;
}
/*
*/

bool scrolldown_updevents(bool mpos,int mx,int my,bool b1,bool b2,bool key,BYTE state,RenderClient*hRC)
{
	static bool mbdown=0;

	if(b1)mbdown=1;
	else mbdown=0;

	if(mbdown&&Scroll<199)
	{
		int scroll_offs=((int)(*Lines)-(int)(Scroll+2));
		float val=(((-1.f/rc1->camera.aspect)+scroll_offs*(0.08f*rc1->camera.zoom))/rc1->camera.zoom);
		if(val>((-1.f/rc1->camera.aspect)/rc1->camera.zoom))
		{
			Scroll++;
			rc1->NeedUpdate=2;
			if(Sound)
			{
				__UPDATESOUND(SC,&sound00,0);
				((resetsound)(*Sound,sound00));
				((playsound)(*Sound,sound00,0));
			}
			return 1;
		}
	}
	if(!state||state==1)
	{
		if(state)
			ScrollEvent->Push(1,MOUSE_OVER);
	}
	else
		ScrollEvent->Push(1,MOUSE_LEFT);
	return 0;
}

bool scrollup_updevents(bool mpos,int mx,int my,bool b1,bool b2,bool key,BYTE state,RenderClient*hRC)
{
	static bool mbdown=0;

	if(b1)mbdown=1;
	else mbdown=0;

	if(mbdown&&Scroll>0)
	{
		Scroll--;
		rc1->NeedUpdate=2;
		if(Sound)
		{
			__UPDATESOUND(SC,&sound00,0);
			((resetsound)(*Sound,sound00));
			((playsound)(*Sound,sound00,0));
		}
		return 1;
	}
	if(!state||state==1)
	{
		if(state)
			ScrollEvent->Push(1,MOUSE_OVER);
	}
	else
		ScrollEvent->Push(1,MOUSE_LEFT);
	return 0;
}

void RestoreControl()
{
	rc1->UpdateWindow=Update_View;
	rc1->RenderWindow=Render_View;
	rc1->cr=0.878;
	rc1->cg=0.905;
	rc1->cb=0.874;
	/*
	if(*Net_Inited)
		__REGNET(DLL_NAME);
	*/
}

//returns if certain characters were pressed
BYTE GetKey()
{
	for(int i='0';i<'9'+1;i++)
		if((IsKeyDown(i)))
			return i;

	for(i='A';i<'Z'+1;i++)
		if((IsKeyDown(i)))
			return i;

	if((IsKeyDown(VK_SPACE)))
		return 32;
	return 0;
}

//kills server app
void __exit()
{
	((push)(Server,1,SHUTDOWN));
}

//throws all functions in dd into the _logfile
void __listfuncs(_DLLData*dd)
{
	if(!dd)return;
	_ImpFunc *func=dd->funcs;

	while(func)
	{
		if(func->name)
		{
			((_log)(Server,"   :%s:",func->name));
		}
		func=func->next;	
	}
}

void __listtasks(bool detail)
{
	((_log)(Server,"listing tasks ..."));
	for(DWORD d=0;d<Server->Num_Windows;d++)
	{
		if(Server->windows[d])
		{
			_MsgProc upd=(_MsgProc)Server->windows[d]->UpdateWindow;
			_DrawProc rnd=(_DrawProc)Server->windows[d]->RenderWindow;
			if(upd||rnd)
			{
				((_log)(Server,""));
				if(detail)
				{
					char wnd_name[255]="";
					sprintf(wnd_name,"Window%d",Server->windows[d]->number);
					QObject* mo=Desktop->FindObject(wnd_name);
					if(mo&&mo->Parent)
						((_log)(Server,"Owner'%s(%s)'",mo->Settings.father,mo->Parent->ClassName));
				}
				((_log)(Server,"TaskId %d Update 0x%x Draw 0x%x",Server->windows[d]->number,upd,rnd));
			}
		}
	}
}

//sends all registered dlls to __listfuncs
void __listreg()
{
	((_log)(Server,"Listing registered values"));
	_DLLData* data=DLLData;
	while(data)
	{
		if(data->name)
		{
			((_log)(Server,":%s:",data->name));
			__listfuncs(data);
		}
		data=data->next;
	}
	((_log)(Server,"done"));
}

//searches for a space
char* GetArg(char *cmd_l,char * cmd_b)
{
	char * orig=cmd_l;
	int i=0;
	BYTE len=strlen(cmd_l);
	while(*cmd_l&&*cmd_l!=32&&i++<len)cmd_l++;
	memcpy(cmd_b,orig,cmd_l-orig);//get first arg to cmd_buf
	cmd_b[cmd_l-orig]=0;
	cmd_l++;//remove space
	return cmd_l;
}

//update callback
void Update_Commandline(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	if((IsKeyDown(VK_TAB))&&rc1->UpdateWindow!=__CALLBACK_VOID)
	{
		/*
		if(CommandlineEnabled)
		{
			__DELETEWINDOW(rc->number);
		}
		__UPDATEALL();
		*/
	}
	else if((IsKeyDown(VK_F3)))
	{
		__UPDATEALL();
	}
	else if((IsKeyDown(VK_F4)))
	{
		if(rc1->UpdateWindow==__CALLBACK_VOID)
			RestoreControl();
		else 
		{
			rc1->cr=0;
			rc1->cg=0;
			rc1->cb=0;
			rc1->UpdateWindow=__CALLBACK_VOID;
			rc1->RenderWindow=__CALLBACK_VOID;		
		}
		__UPDATEALL();
		do{}while(IsKeyDown(VK_F4));
	}
	if(CommandlineEnabled)
	{
		if((IsKeyDown(VK_F7)))
		{
			cam->zoom*=1.1f;
			*nu=2;
		}
		else if((IsKeyDown(VK_F8)))
		{
			cam->zoom/=1.1f;
			*nu=2;
		}
		BYTE c=GetKey();
		if(c)
		{
			if(Sound)
			{
				__UPDATESOUND(SC,&sound03,3);
				((resetsound)(*Sound,sound03));
				((playsound)(*Sound,sound03,0));
			}
			do{}while(GetKey());
			if(!(IsKeyDown(VK_SHIFT))&&(c>='A'&&c<='Z'))
				c-='A'-'a';
			*nu=2;
			Commandline[strlen(Commandline)]=c;
			Commandline[strlen(Commandline)+1]=0;
		}
		else if(IsKeyDown(VK_CONTROL)&&IsKeyDown(VK_SHIFT))
		{
			rc1->NeedUpdate=2;
			memcpy(last_Commandline,Commandline,200);
//			((_log)(Server,Commandline));
			char cmdb[50]="";
			char *cmdl=Commandline;
			cmdl=GetArg(cmdl,cmdb);
			if(!strcmp(">pass",cmdb))
			{
				FILE* pass=fopen("admin.epf","rb");
				DWORD buffer;
				cmdl=GetArg(cmdl,cmdb);
				DWORD len=strlen(cmdb);
				DWORD sr=0;
				DWORD mix=1;
				DWORD num_rand=(len+1)/4;
				bool pass_ok=1;
				for(DWORD r=0;r<num_rand;r++)
				{
					BYTE* bp=(BYTE*)(&sr);
					for(DWORD d=0;d<4;d++)
					{
						*bp=cmdb[d] % 30;
						bp++;
					}
					mix+=sqrt(sr*mix);
					
				}
				srand(mix);
				fread(&buffer,4,1,pass);
				DWORD ll=len;
				len=buffer/rand();
				if(ll!=len)pass_ok=0;
				for(DWORD d=0;d<len&&d<MAX_PASS-7;d++)
				{
					fread(&buffer,4,1,pass);
					if(buffer/rand()!=cmdb[d])
						pass_ok=0;
				}
				fclose(pass);
				if(pass_ok)PASS=1;
				else PASS=0;
				((_log)(Server,"PASS %d",PASS));
			}
			else if(PASS)
//			if(1)
			{
				if(!strcmp(">reg",cmdb))
				{
					if(((isregistered)(*Importer,cmdl)))
					{
						((_log)(Server,":%s: is already a registered value",cmdl));
					}
					else
					try
					{
						cmdl=GetArg(cmdl,cmdb);
						((reg)(*Importer,cmdb,atoi(cmdl)));
					}
					catch( ... )
					{
						((_log)(Server,"An error occured while executing :%s:",Commandline));
					}
				}
				else if(!strcmp(">wpass",cmdb))
				{
					FILE* pass=fopen("admin.epf","wb");
					DWORD buffer;
					cmdl=GetArg(cmdl,cmdb);
					DWORD len=strlen(cmdb);
					DWORD sr=0;
					DWORD mix=1;
					DWORD num_rand=(len+1)/4;
					for(DWORD r=0;r<num_rand;r++)
					{
						BYTE* bp=(BYTE*)(&sr);
						for(DWORD d=0;d<4;d++)
						{
							*bp=cmdb[d] % 30;
							bp++;
						}
						mix+=sqrt(sr*mix);
					}
					srand(mix);
					buffer=len*rand();
					fwrite(&buffer,4,1,pass);
					for(DWORD d=0;d<len&&d<MAX_PASS-7;d++)
					{
						buffer=cmdb[d]*rand();
						fwrite(&buffer,4,1,pass);
					}
					for(d=0;d<rand()%40;d++)
					{
						buffer=rand();
						fwrite(&buffer,4,1,pass);
					}
					fclose(pass);
					((_log)(Server,"pass written"));
				}
				else if(!strcmp(">mem",cmdb))
				{
					MEMORYSTATUS memstat;
					GlobalMemoryStatus(&memstat);

					((_log)(Server, "Available RAM %f MB", (memstat.dwTotalPhys/1048576.f) )) ;	//output some stats
					((_log)(Server, "Free RAM %f MB", (memstat.dwAvailPhys/1048576.f) )) ;	
					((_log)(Server, "Free Virt. RAM %f MB", (memstat.dwAvailVirtual/1048576.f) )) ;	
					((memstats)(Server));
				}
				else if(!strcmp(">min_ping",cmdb))
				{
					cmdl=GetArg(cmdl,cmdb);
					((dpsend)(*Net,Server->ServerId,2,MIN_PING,atoi(cmdb)));
				}
				else if(!strcmp(">taskview",cmdb))
				{
					cmdl=GetArg(cmdl,cmdb);
					__listtasks(atoi(cmdb));
				}
				else if(!strcmp(">killtask",cmdb))
				{
					cmdl=GetArg(cmdl,cmdb);
					if(strlen(cmdb)&&atoi(cmdb))
					{
						((_log)(Server,"killing task %d ...",atoi(cmdb)));
						Server->windows[atoi(cmdb)]->UpdateWindow=NULL;
						Server->windows[atoi(cmdb)]->RenderWindow=NULL;
						Desktop->Draw();
					}
					else
						((_log)(Server,"invalid TaskId :%s:",cmdb));
				}
				else if(!strcmp(">max_player",cmdb))
				{
					cmdl=GetArg(cmdl,cmdb);
					((dpsend)(*Net,Server->ServerId,2,MAX_PLAYER,atoi(cmdb)));
				}
				else if(!strcmp(">nick",cmdb))
				{
					cmdl=GetArg(cmdl,cmdb);
					if(strlen(cmdb)>0)
					{
						DWORD buf[100];
						DWORD* bp;
						bp=buf;
						*bp=3+40/4+1;
						bp++;
						*bp=Server->Net->PlayerId;
						bp++;
						*bp=NICK;
						bp++;
						memcpy(bp,cmdb,strlen(cmdb)+1);
						((senddata)(*Net,buf,Server->ServerId));
					}
				}
				else if(!strcmp(">play",cmdb))
				{
					if(Sound)
					{
						((readcdinfos)(*Sound));
						cmdl=GetArg(cmdl,cmdb);
						((playcdaudio)(*Sound,atoi(cmdb),0,0));
					}
				}
				else if(!strcmp(">res",cmdb))
				{
					WORD x,y,bpp;
					cmdl=GetArg(cmdl,cmdb);
					x=atoi(cmdb);
					cmdl=GetArg(cmdl,cmdb);
					y=atoi(cmdb);
					cmdl=GetArg(cmdl,cmdb);
					bpp=atoi(cmdb);
					((push)(Server,4,CHANGE_RES,x,y,bpp));
				}
				else if(!strcmp(">stop",cmdb))
				{
					if(Sound)
						((closecdaudio)(*Sound));
				}
				else if(!strcmp(">get",cmdb))
				{
					DWORD *value=NULL;
					if(!((isregistered)(*Importer,cmdl)))
					{
						((_log)(Server,":%s: is not a registered value",cmdl));
					}
					else
					{
						try
						{
							cmdl=GetArg(cmdl,cmdb);
							value=(DWORD*)((getadress)(*Importer,cmdb));
						}
						catch( ... )
						{
							((_log)(Server,"An error occured while executing :%s:",Commandline));
						}
						((_log)(Server,"%s:0x%x",cmdb,value));
					}
				}
				else if(!strcmp(">get_mem",cmdb))
				{
					DWORD *value=NULL;
					if(!((isregistered)(*Importer,cmdl)))
					{
						((_log)(Server,":%s: is not a registered value",cmdl));
					}
					else
					{
						try
						{
							cmdl=GetArg(cmdl,cmdb);
							value=(DWORD*)((getadress)(*Importer,cmdb));
						}
						catch( ... )
						{
							((_log)(Server,"An error occured while executing :%s:",Commandline));
						}
						((_log)(Server,"%s:0x%x -> %d",cmdb,value,*value));
					}
				}
				else if(!strcmp(">exec",cmdb))
				{
					plugin_function pnp_fnc=NULL;
					cmdl=GetArg(cmdl,cmdb);
					if(!((isregistered)(*Importer,cmdb)))
					{
						((_log)(Server,":%s: is not a registered value",cmdl));
					}
					else
					{
						try
						{
//							cmdl=GetArg(cmdl,cmdb);
							pnp_fnc=(plugin_function)((getadress)(*Importer,cmdb));
							((pnp_fnc)(cmdl));
						}
						catch( ... )
						{
							((_log)(Server,"An error occured while executing :%s:",Commandline));
						}
//						((_log)(Server,"%s:0x%x",cmdb,pnp_fnc));
					}
				}
				else if(!strcmp(">set",cmdb))
				{
					DWORD *value=NULL;
					cmdl=GetArg(cmdl,cmdb);
					if(!((isregistered)(*Importer,cmdb)))
					{
						((_log)(Server,":%s: is not a registered value",cmdb));
					}
					else
					{
						try
						{
							_ImpFunc *func=DLLData->funcs;

							while(strcmp(func->name,cmdb))
								func=func->next;
							if(!((isregistered)(*Importer,cmdl)))
							{
								DWORD dval=atoi(cmdl);
								void * val;
								memcpy(&val,&dval,4);
								func->func=(lpFunc)val;
							}
							else
							{
								_ImpFunc *func2=DLLData->funcs;

								while(strcmp(func2->name,cmdl))
									func2=func2->next;
								func->func=func2->func;						
							}
						}
						catch( ... )
						{
							((_log)(Server,"An error occured while executing :%s:",Commandline));
						}
					}
				}
				else if(!strcmp(">help",cmdb))
				{
					((_log)(Server,"commands: reg get get_mem set dump_reg exec mem taskview kill task wpass play stop nick max_player min_ping load unload exit res"));
				}
				else if(!strcmp(">unload",cmdb))
				{
					try
					{
						sprintf(unloadName,"%s%c",cmdl,0);
						((push)(Server,2,UNLOAD_DLL,unloadName));
						if(rc1->UpdateWindow==__CALLBACK_VOID)
							RestoreControl();
						__UPDATEALL();
					}
					catch(...)
					{
						((_log)(Server,"An error occured while executing :%s:",Commandline));				
					}
				}
				else if(!strcmp(">exit",cmdb))
				{
					try
					{
						((push)(Server,1,SHUTDOWN));
					}
					catch(...)
					{
						((_log)(Server,"An error occured while executing :%s:",Commandline));				
					}
				}
				else if(!strcmp(">dump_reg",cmdb))
				{
					try
					{
						__listreg();
					}
					catch(...)
					{
						((_log)(Server,"An error occured while executing :%s:",Commandline));				
					}
				}
				else if(!strcmp(">load",cmdb))
				{
					rc1->UpdateWindow=__CALLBACK_VOID;
					rc1->RenderWindow=__CALLBACK_VOID;
					rc1->cr=0;
					rc1->cg=0;
					rc1->cb=0;
					lpFunc f=NULL;
					try
					{
						float a[4]={0,0,1,0.95f};
						sprintf(unloadName,"%s%c",cmdl,0);
						__DLLINSTALL(DLL_NAME,unloadName,a);
						_DLLData* data=DLLData;
						bool found=0;
						while(data)
						{
							if(data->name)
							{
								if(!strcmp(data->name,unloadName))
								{
									found=1;
									break;
								}
							}
							data=data->next;
						}

						if(found)
						{
							lpFunc Init;
							Init=((importfunc)(*Importer,unloadName,"DLLInterface"));
							try
							{
								((Init)(push,Server));
							}
							catch(...)
							{
								((_log)(Server,"An error occured while executing :%s:",Commandline));
							}
							lpFunc DLLRequest;
							DLLRequest=((importfunc)(*Importer,unloadName,"DLLInterface_Init"));
							try
							{
								((DLLRequest)());
							}
							catch(...)
							{
								((_log)(Server,"An error occured while executing :%s:",Commandline));
							}
						}
					}
					catch(...)
					{
						((_log)(Server,"An error occured while executing :%s:",Commandline));
						RestoreControl();
					}

					try
					{
						sprintf(unloadName,"%s%c",cmdl,0);
						f=((importfunc)(*Importer,unloadName,"DLLInterface_ReturnControl"));
						if(f)((f)(RestoreControl));
						else ((_log)(Server,"%s does not support 'DLLInterface_ReturnControl'",unloadName));
					}
					catch(...)
					{
						((_log)(Server,"An error occured while executing :%s:",Commandline));
						RestoreControl();
						try
						{
							sprintf(unloadName,"%s%c",cmdl,0);
							((push)(Server,2,UNLOAD_DLL,unloadName));
						}
						catch(...)
						{
							((_log)(Server,"An error occured while executing :%s:",Commandline));				
						}
					}
				}
				else 
				{
					DWORD	buf[200];
					DWORD*	dwp=&buf[0];
					*dwp=5+((strlen(Commandline))/4);
					dwp++;
					*dwp=Server->NetId;
					dwp++;
					*dwp=NET;
					dwp++;
					*dwp=UIN;
					dwp++;
					sprintf((char*)dwp,"%s%c",Commandline,0);
					((senddata)(*Net,buf,Server->ServerId));
					//((dpsend)(*Net,Server->ServerId,3+(strlen(cmdl)+1)/4,NET,UIN,cmdl));
				}
			}
			else 
			{
				DWORD	buf[200];
				DWORD*	dwp=&buf[0];
				*dwp=5+((strlen(Commandline))/4);
				dwp++;
				*dwp=Server->NetId;
				dwp++;
				*dwp=NET;
				dwp++;
				*dwp=UIN;
				dwp++;
				sprintf((char*)dwp,"%s%c",Commandline,0);
				((senddata)(*Net,buf,Server->ServerId));
				//((dpsend)(*Net,Server->ServerId,3+(strlen(cmdl)+1)/4,NET,UIN,cmdl));
			}
			if(Sound)
			{
				__UPDATESOUND(SC,&sound02,2);
				((resetsound)(*Sound,sound02));
				((playsound)(*Sound,sound02,0));
			}
			/*
			if(!((residentsound)(*Sound,sound00,SC->GetTime(0))))
				sound00=((uploadsound)(*Sound,SC,0));
			((playsound)(*Sound,sound00,0));
			*/
			do{}while((IsKeyDown(VK_CONTROL)));
			*nu=2;
		for(int i=0;i<200;i++)
			Commandline[i]=0;
		}
		else if((IsKeyDown(VK_UP)&&IsKeyDown(VK_SHIFT)))
		{
			memcpy(Commandline,last_Commandline,200);
			do{}while((IsKeyDown(VK_UP)));
			*nu=2;
		}
		else if((IsKeyDown(VK_BACK)))
		{
			Commandline[strlen(Commandline)-1]=0;
			Commandline[strlen(Commandline)]=0;
			do{}while((IsKeyDown(VK_BACK)));
			*nu=2;
		}
		else if(*Time-_time>500)
			*nu=2;
		if((IsKeyDown(VkKeyScan('_')))&&(IsKeyDown(VK_SHIFT)))
		{
			Commandline[strlen(Commandline)]='_';
			Commandline[strlen(Commandline)+1]=0;	
			do{}while((IsKeyDown(VkKeyScan('_'))));
			*nu=2;
		}
		else if((IsKeyDown(VkKeyScan(':')))&&(IsKeyDown(VK_SHIFT)))
		{
			Commandline[strlen(Commandline)]=':';
			Commandline[strlen(Commandline)+1]=0;	
			do{}while((IsKeyDown(VkKeyScan(':'))));
			*nu=2;
		}
		else if((IsKeyDown(VkKeyScan('.'))))
		{
			Commandline[strlen(Commandline)]='.';
			Commandline[strlen(Commandline)+1]=0;	
			do{}while((IsKeyDown(VkKeyScan('.'))));
			*nu=2;
		}
		else if((IsKeyDown(VkKeyScan(','))))
		{
			Commandline[strlen(Commandline)]=',';
			Commandline[strlen(Commandline)+1]=0;	
			do{}while((IsKeyDown(VkKeyScan(','))));
			*nu=2;
		}
		else if((IsKeyDown(VkKeyScan('*'))))
		{
			Commandline[strlen(Commandline)]='*';
			Commandline[strlen(Commandline)+1]=0;	
			do{}while((IsKeyDown(VkKeyScan('*'))));
			*nu=2;
		}
		else if((IsKeyDown(VkKeyScan('-'))))
		{
			Commandline[strlen(Commandline)]='-';
			Commandline[strlen(Commandline)+1]=0;	
			do{}while((IsKeyDown(VkKeyScan('-'))));
			*nu=2;
		}
		else if((IsKeyDown(VkKeyScan('>'))))
		{
			Commandline[strlen(Commandline)]='>';
			Commandline[strlen(Commandline)+1]=0;	
			do{}while((IsKeyDown(VkKeyScan('>'))));
			*nu=2;
		}
	}
	else showCursor=0;

}

//render callback
void Render_Commandline(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();
	glScalef (1, -1, -1);//left hand system
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	glDepthFunc(GL_ALWAYS);
	glScalef ((absf(cam->zoom)), -(absf(cam->zoom))*cam->aspect, -1);//left hand system
	glDepthFunc(GL_ALWAYS);
//	((drawquad)(*Rasterizer,43,-1.05f/cam->zoom,-1.05f/cam->zoom,2.1f/cam->zoom,2.1f/cam->zoom,1,0.1,1,0.1,1,1));	//draw background
	glLoadIdentity();
	glScalef ((absf(cam->zoom)), -(absf(cam->zoom))*cam->aspect, -1);//left hand system
	char cmdb[50]="";
	char *cmdl=Commandline;
	cmdl=GetArg(cmdl,cmdb);
	char cmd[200]="";
	sprintf(cmd,Commandline);
	if(!strcmp(">pass",cmdb))
	{
		for(DWORD d=6;d<strlen(cmd);d++)
		{
			cmd[d]='*';
		}
	}
	((drawtext)(*Rasterizer,cmd,-1.f/cam->zoom,(-0.04f/cam->zoom),0.08f,1,0,0,0,1,1));		
	if(CommandlineEnabled)
	{
		if(*Time-_time>500)
		{
			_time=*Time;
			showCursor=(bool)(1-showCursor);
		}
		if(showCursor)
		{
			char blink[200]="";
			for(int i=0;i<strlen(Commandline);i++)
				blink[i]=' ';
			blink[strlen(Commandline)]='o';

			if(showCursor)
				((drawtext)(*Rasterizer,blink,-1.f/cam->zoom,(-0.04f/cam->zoom),0.08f,1,0,0,0,1,1));		
		}
	}

	glDepthFunc(GL_LEQUAL);

	gluPerspective(70, 1.f, 0.1, 512);
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();

	


}

void Render_Scroll(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	static float col=1.0f;
	void* Data=ScrollEvent->Pop();
	while(Data)
	{
		switch(*((DWORD*)Data))
		{
		case MOUSE_OVER:
			col=0.5f;
			*nu=2;
			break;
		case MOUSE_LEFT:
			col=1.0f;
			*nu=2;
			break;
		default:
			break;
		}
		Data=ScrollEvent->Pop();
	}
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();
	glScalef (1, -1, -1);//left hand system
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
//	glScalef (1, -1, -1);//left hand system
	glDepthFunc(GL_ALWAYS);
//    glBlendFunc( GL_ONE, GL_ONE );
	glMatrixMode(GL_TEXTURE);
	if(rc->number==rc4->number)
		glRotatef(-90,0,0,1);
	else 
		glRotatef(90,0,0,1);
	((drawquad)(*Rasterizer,41,-1.05f,-1.05f,2.1f,2.1f,1,0,col,0,1,1));	//draw background
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);
	glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
	glDepthFunc(GL_LEQUAL);

	gluPerspective(70, 1, 0.1, 512);
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();
	
}

void Update_Scroll(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	if(!ScrollEvent->Empty())*nu=1;	
	if(rc==rc4)
		rc5->NeedUpdate=1;
	else 
		rc4->NeedUpdate=1;
}

//update callback
void Update_View(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	static int mLines=*Lines;
	static char firstLetter=*ScreenBuffer;
	static int firstlen=strlen(ScreenBuffer);

	if(mLines!=*Lines)//number of lines changed->update
	{
		Scroll+=*Lines-mLines;
		mLines=*Lines;
		*nu=2;
	}
	else if(firstLetter!=*ScreenBuffer||firstlen!=strlen(ScreenBuffer))//first letter changed->update
	{
		firstLetter=*ScreenBuffer;
		firstlen=strlen(ScreenBuffer);
		if(Scroll<199)Scroll++;
		*nu=2;
	}
	if((IsKeyDown(VK_F7)))//zoom in
	{
		cam->zoom*=1.1f;
		*nu=2;
	}
	else if((IsKeyDown(VK_F8)))//zoom out
	{
		cam->zoom/=1.1f;
		*nu=2;
	}
	else if((IsKeyDown(VK_F2)))
	{
		SwapBuffers((*Rasterizer)->hDC);
		do{}while(IsKeyDown(VK_F2));
	}
	else if((IsKeyDown(VK_F3)))
	{
		*nu=2;
	}
/*	else if((IsKeyDown(VK_TAB))&&rc1->UpdateWindow!=__CALLBACK_VOID)
	{
		if(CommandlineEnabled)
		{
			float a[4]={0,0,1,1};//{x,y,x_size,y_size}
			__SETWINDOW(DLL_NAME,a,rc);
			float b[4]={0.95,0.95,0.05,0.05};//{x,y,x_size,y_size}
			__SETWINDOW(DLL_NAME,b,rc4);
		}
		else
		{
			__GETWINDOW(Update_Commandline,Render_Commandline,DLL_NAME,0,0.95f,1,0.05f,0.01,0.01,0.01,&rc2);
			float a[4]={0,0,1,0.95};//{x,y,x_size,y_size}
			__SETWINDOW(DLL_NAME,a,rc);
			float b[4]={0.95,0.90,0.05,0.05};//{x,y,x_size,y_size}
			__SETWINDOW(DLL_NAME,b,rc4);
	
		}
		CommandlineEnabled=1-CommandlineEnabled;
		*nu=2;
		do{}while((IsKeyDown(VK_TAB)));
	}
*/
}

//render callback
void Render_View(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();
	glScalef (1, -1, -1);//left hand system
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	glScalef ((absf(cam->zoom)), -(absf(cam->zoom)), -1);//left hand system
	glDepthFunc(GL_ALWAYS);
//	((drawquad)(*Rasterizer,43,-1.05f/cam->zoom,-1.05f/cam->zoom,2.1f/cam->zoom,2.1f/cam->zoom,1,0.8,1,0.8,1,1));	//draw background
	glLoadIdentity();
	glScalef ((absf(cam->zoom)), -(absf(cam->zoom))*cam->aspect, -1);//left hand system
	WORD mLines=0;
	for(int i=*Lines-1-Scroll;i>=0;i--)
	{
		char buf[200];
		char *bp=&buf[0];
		memcpy(buf,ScreenBuffer+200*(*Lines-(i+1)),200);
		while(*bp)//output and break too long lines
		{
			char buf2[200];
			BYTE len=(BYTE)((2.f/cam->zoom)/0.056f);
			if(strlen(bp)>len)
			{
				for(int j=len;j>0;j--)//find closest space
				{
					if(bp[j]==' ')
					{
						len=j;
						break;
					}
				}
			}
			else len=strlen(bp);
			memcpy(buf2,bp,len);
			bp+=len;
			buf2[len]=0;
			float val=(((1.f/cam->aspect)-(mLines+1)*(0.08f*cam->zoom))/cam->zoom);
			if(val<((1.f/cam->aspect)/cam->zoom)&&val>((-1.f/cam->aspect)/cam->zoom))
			{
				((drawtext)(*Rasterizer,buf2,-1.f/cam->zoom,val,0.08f,1,0,0,0,1,1));		
				mLines++;
			}
			else break;
		}
	}
	glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
	glDepthFunc(GL_LEQUAL);

	gluPerspective(70, 1, 0.1, 512);
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();

	rc4->NeedUpdate=2;
	rc5->NeedUpdate=2;
}

void InitRC1x()
{
	rc1->camera.zoom/=1.21f;
}


bool Update_Button_Events(bool mpos,int mx,int my,bool b1,bool b2,bool key,BYTE state,RenderClient*hRC)
{
	static WORD xpos=mx;
	static bool View=1;
	static BYTE st=state;
	if(!state||state==1)
	{
//		if(mpos)
//			ButtonEvent->Push(3,MOUSE_MOVE,mx,my);
		if(b1)
		{
			if(rc1->UpdateWindow!=__CALLBACK_VOID)
			{
				if(View)
				{
					__CLEARBUFFERS();
					WORD xsize=rc3->window.TopLeft.x;
					__DELETEWINDOW(rc1->number);
					__DELETEWINDOW(rc4->number);
					__DELETEWINDOW(rc5->number);
					float a[4]={0.95,0,0.05,1};//{x,y,x_size,y_size}
					__SETWINDOW(DLL_NAME,a,rc3);
					xsize=rc3->window.TopLeft.x-xsize;
					if(CommandlineEnabled)
					{
						__DELETEWINDOW(rc2->number);
						CommandlineEnabled=0;
					}
					View=0;
					
					WORD xpos=rc3->window.TopLeft.x;
					float x=xpos/(float)(xpos-xsize);
					for(int i=0;i<Server->Num_Windows;i++)
					{
						if(Server->windows[i])
						{
							Window_ *wnd=&Server->windows[i]->window;
							if(wnd->Center.x<rc3->window.Center.x)
							{
								wnd->TopLeft.x*=x;
								wnd->width*=x;
								wnd->BottomRight.x=wnd->TopLeft.x+wnd->width;
								wnd->Center.x=wnd->TopLeft.x+wnd->width/2;
							}
						}
					}
					__UPDATEALL();
				}
				else
				{
					__CLEARBUFFERS();
					WORD xsize=rc3->window.TopLeft.x;
					float a[4]={0,0,0.05,1};//{x,y,x_size,y_size}
					__SETWINDOW(DLL_NAME,a,rc3);
					xsize-=rc3->window.TopLeft.x;
					__GETWINDOW(Update_View,Render_View,DLL_NAME,0,0,1,1,0.01,0.01,0.01,&rc1);
					__GETWINDOW(Update_Scroll,Render_Scroll,DLL_NAME,0.95,0.95f,0.05,0.05f,0.01,0.01,0.01,&rc4);
					__GETWINDOW(Update_Scroll,Render_Scroll,DLL_NAME,0.95,0.0f,0.05,0.05f,0.01,0.01,0.01,&rc5);
					__RUNFUNC(DLL_NAME,"InitRC1x");
					View=1;			
					WORD xpos=rc3->window.TopLeft.x;
					float x=xpos/(float)(xpos+xsize);
					for(int i=0;i<Server->Num_Windows;i++)
					{
						if(Server->windows[i])
						{
							Window_ *wnd=&Server->windows[i]->window;
							if(wnd->Center.x<rc3->window.Center.x)
							{
								wnd->TopLeft.x*=x;
								wnd->width*=x;
								wnd->BottomRight.x=wnd->TopLeft.x+wnd->width;
								wnd->Center.x=wnd->TopLeft.x+wnd->width/2;
							}
						}
					}
					__UPDATEALL();
				}
			}
//			ButtonEvent->Push(1,MOUSE_LEFT_BUTTON_DOWN);
		}
/*
		else
			ButtonEvent->Push(1,MOUSE_LEFT_BUTTON_UP);
		if(b2)
			ButtonEvent->Push(1,MOUSE_RIGHT_BUTTON_DOWN);
		else
			ButtonEvent->Push(1,MOUSE_RIGHT_BUTTON_UP);
		if(key)
			ButtonEvent->Push(1,KEYBOARD);
*/		if(state)
			ButtonEvent->Push(1,MOUSE_OVER);
	}
	else
		ButtonEvent->Push(1,MOUSE_LEFT);
	return 0;
}

void Update_Button(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	if(!ButtonEvent->Empty())*nu=1;
}

//render callback
void Render_Button(int *nu,void* data,Camera_* cam,RenderClient *rc)
{
	static float col=0.5f;
	void* Data=ButtonEvent->Pop();
	while(Data)
	{
		switch(*((DWORD*)Data))
		{
		case MOUSE_OVER:
			col=1.f;
			*nu=2;
			break;
		case MOUSE_LEFT:
			col=0.5f;
			*nu=2;
			break;
		default:
			break;
		}
		Data=ButtonEvent->Pop();
	}

	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();
	glScalef (1, -1, -1);//left hand system
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
//	glDepthFunc(GL_ALWAYS);
	glScalef ((absf(cam->zoom)), -(absf(cam->zoom)), -1);//left hand system
	glDepthFunc(GL_ALWAYS);
	((drawquad)(*Rasterizer,43,-10.0f/cam->zoom,-1.f/cam->zoom,20.f/cam->zoom,2.f/cam->zoom,1,0.7,col,0.7,1,1));	//draw background
	glDepthFunc(GL_LEQUAL);
	gluPerspective(70, 1.f, 0.1, 512);
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();
	glDepthFunc(GL_LEQUAL);
}


void InitRC1()
{
	rc1->camera.zoom/=1.21f;
	__GETEVENTUPDATE(rc1,updevents);
	__GETEVENTUPDATE(rc5,scrollup_updevents);
	__GETEVENTUPDATE(rc4,scrolldown_updevents);
//	__GETEVENTUPDATE(rc3,Update_Button_Events);
	
//	MP2Id=__TEXLOAD("textures\\ttdebug\\mp2.tga",0);
	__UPDATEALL();
	__REG("InitRC1x",InitRC1x);
}

//<<<<DLLInterface functions>>>>

//optional interface func
void DLLInterface_CheckVersion()
{
	if(atof(Version)<PNPDLL_VERSION)
		((error)(Server,"server version is %d but %d is needed",(DWORD)(10000*atof(Version)),(DWORD)(10000*PNPDLL_VERSION)));
	((_log)(Server,"TTdebug.dll(ref%d) (c) Alex ",(DWORD)(10000*PNPDLL_VERSION)));
}

void DLLInterface_InitSound()
{
	__GETVALUE(OBJ_SOUND,(void***)&Sound);
	if(Sound)
	{
		__GETCMD(CMD_S_LOADSOUND,&loadsound);
		__GETCMD(CMD_S_UPLOADSOUND,&uploadsound);
		__GETCMD(CMD_S_RESIDENTSOUND,&residentsound);

		__GETCMD(CMD_S_PLAYSOUND,&playsound);
		__GETCMD(CMD_S_STOPSOUND,&stopsound);
		__GETCMD(CMD_S_RESETSOUND,&resetsound);

		__GETCMD(CMD_CDA_PLAYCDAUDIO,&playcdaudio);
		__GETCMD(CMD_CDA_CLOSECDAUDIO,&closecdaudio);
		__GETCMD(CMD_CDA_READCDINFOS,&readcdinfos);
	}

	__RUNFUNC(DLL_NAME,"DLLInterface_Register");
}

//optional interface func
void DLLInterface_Register()
{
	__REG("__exit",__exit);
	__REG("__listreg",__listreg);
	__REG("InitRC1",InitRC1);
	__REG("pnp_log",pnp_log);
	__RUNFUNC(DLL_NAME,"InitRC1");
	if(Sound)
	{
		SC->Init(4);
		((loadsound)(*Sound,"sounds\\ttdebug\\borg1.wav",0,SC));
		((loadsound)(*Sound,"sounds\\ttdebug\\borg2.wav",0,SC));
		((loadsound)(*Sound,"sounds\\ttdebug\\borg3.wav",0,SC));
		((loadsound)(*Sound,"sounds\\ttdebug\\borg4.wav",0,SC));
		sound00=((uploadsound)(*Sound,SC,0));
		sound01=((uploadsound)(*Sound,SC,1));
		sound02=((uploadsound)(*Sound,SC,2));
		sound03=((uploadsound)(*Sound,SC,3));
	}
//	((playsound)(*Sound,sound01,1));
}

//<<DllFuncInit func..must be avalable in all dlls>>
void DLLInterface_Init()//push all funcs you need
{
	__TESTCOM();

	__GETCMD(PNP_VERSION,&Version);
	__GETCMD(CMD_LOG,&_log);
	__RUNFUNC(DLL_NAME,"DLLInterface_CheckVersion");
	
	__GETCMD(VAL_TIME,&Time);

	__GETCMD(CMD_ERROR,&error);
	
	__GETCMD(OBJ_IMPORTER,&Importer);
	
		__GETCMD(CMD_IMPORTDLL,&importdll);
		__GETCMD(CMD_UNLOADDLL,&unloaddll);
		__GETCMD(CMD_GETADRESS,&getadress);
		__GETCMD(CMD_REGISTER,&reg);
		__GETCMD(CMD_ISREGISTERED,&isregistered);
		__GETCMD(CMD_GETCLIENTAREA,&getclientarea);
		__GETCMD(CMD_IMPORTFUNC,&importfunc);
		
		__GETCMD(VAL_DLLDATA,&DLLData);
		
	__GETCMD(OBJ_WINMANAGER,&WinManager);

		__GETCMD(VAL_LINES,&Lines);
		__GETCMD(VAL_SCREENBUFFER,&ScreenBuffer);

	__GETCMD(OBJ_RASTERIZER,&Rasterizer);

		__GETCMD(CMD_DRAWTEXT,&drawtext);
		__GETCMD(CMD_DRAWQUAD,&drawquad);
		__GETCMD(CMD_TEXACTIVATE,&texactivate);
		__GETCMD(CMD_TEXARRAY,&texarray);
		__GETCMD(CMD_TEXEREASE,&texerease);
		__GETCMD(CMD_TEXLOAD,&texload);
		__GETCMD(CMD_TPUACTIVATE,&tpuactivate);

		__GETCMD(VAL_NUMTPUS,&Num_TPUs);
		__GETCMD(VAL_ACTTPU,&Act_TPU);

		__GETCMD(CMD_SETMOUSEPOINTER,&setmousepointer);
		__GETCMD(CMD_INITMOUSEBUFFER,&initmousebuffer);
		
	__GETCMD(OBJ_NET,&Net);

		__GETCMD(CMD_SENDDATA,&senddata);			
		__GETCMD(CMD_SEND,&dpsend);
		__GETCMD(VAL_NET_INITED,&Net_Inited);		

		__GETCMD(CMD_SENDDATA,&senddata);			
		__GETCMD(CMD_SEND,&dpsend);
		__GETCMD(VAL_NET_INITED,&Net_Inited);		

	__GETCMD(OBJ_DESKTOP,&Desktop);

	__GETCMD(CMD_MEMSTATS,&memstats);

	__RUNFUNC(DLL_NAME,"DLLInterface_InitSound");

	__GETWINDOW(Update_View,Render_View,DLL_NAME,0,0,0.95,0.95,0.878,0.905,0.874,&rc1);
//	__GETWINDOW(Update_Button,Render_Button,DLL_NAME,0,0,0.05,1,0.01,0.01,0.01,&rc3);
	__GETWINDOW(Update_Scroll,Render_Scroll,DLL_NAME,0.95,0.90f,0.05,0.05f,0.0,0.0,0.0,&rc4);
	__GETWINDOW(Update_Scroll,Render_Scroll,DLL_NAME,0.95,0.0f,0.05,0.05f,0.0,0.0,0.0,&rc5);
	__GETWINDOW(Update_Commandline,Render_Commandline,DLL_NAME,0,0.95f,1,0.05f,0.878,0.905,0.874,&rc2);
	__GETNETUPDATE(updnet);
	
	ButtonEvent=new EventHandler;
	ScrollEvent=new EventHandler;
//	((push)(Server,2,REQUEST_NET,updnet));
	SC=new SoundClient;
}

void Cleanup_Sound()
{
	if(!Sound)return;

	if(((residentsound)(*Sound,sound01,SC->GetTime(1))))
		((stopsound)(*Sound,sound01));
	SC->DeleteSB(0);
	SC->DeleteSB(1);
	SC->DeleteSB(2);
	SC->DeleteSB(3);
	delete SC;
}

//<<DllShutDown func..must be avalable in all dlls>>
void DLLInterface_ShutDown()
{
	__DELEVENTUPDATE(updevents);
	__DELEVENTUPDATE(Update_Button_Events);
	__DELNETUPDATE(updnet);
	__DELEVENTUPDATE(scrollup_updevents);
	__DELEVENTUPDATE(scrolldown_updevents);
	if(rc1)__DELETEWINDOW(rc1->number);//cleanup yourself
	if(rc2)__DELETEWINDOW(rc2->number);//cleanup yourself
	if(rc3)__DELETEWINDOW(rc3->number);//cleanup yourself
	if(rc4)__DELETEWINDOW(rc4->number);//cleanup yourself
	if(rc5)__DELETEWINDOW(rc5->number);//cleanup yourself
	delete ButtonEvent;
	delete ScrollEvent;

	Cleanup_Sound();

	((_log)(Server,"ttdebug.dll shutdown"));	
}


