<Header Section>
Compiler Version: 5.100000, Debug Info: 0
<Code Section>
0: jmp const 3672 
28: mov data , const 112 
52: sne 
60: mov reg1 , const 1066192077 
84: mov reg2 , const 0 
108: mov [ reg2 ] , reg1 
136: mov reg1 , const 1634492780 
160: mov [ const 24 ] , reg1 
192: mov reg1 , const 24940 
216: mov [ const 28 ] , reg1 
248: mov reg1 , const 24 
272: mov [ const 32 ] , reg1 
304: mov reg1 , const 1634492780 
328: mov [ const 36 ] , reg1 
360: mov reg1 , const 3301740 
384: mov [ const 40 ] , reg1 
416: mov reg1 , const 24940 
440: mov [ const 44 ] , reg1 
472: mov reg1 , const 36 
496: mov [ const 48 ] , reg1 
528: mov reg1 , const 1734963791 
552: mov [ const 52 ] , reg1 
584: mov reg1 , const 1818324585 
608: mov [ const 56 ] , reg1 
640: mov reg1 , const 976380960 
664: mov [ const 60 ] , reg1 
696: mov reg1 , const 25637 
720: mov [ const * 67 , reg1 
752: mov reg1 , const 52 
776: mov [ const 68 ] , reg1 
808: mov reg1 , const 544695630 
832: mov [ const 72 ] , reg1 
864: mov reg1 , const 1630024292 
888: mov [ const 76 ] , reg1 
920: mov reg1 , const 1919251558 
944: mov [ const 80 ] , reg1 
976: mov reg1 , const 1836016416 
1000: mov [ const 84 ] , reg1 
1032: mov reg1 , const 1769103728 
1056: mov [ const 88 ] , reg1 
1088: mov reg1 , const 544108403 
1112: mov [ const 92 ] , reg1 
1144: mov reg1 , const 941649780 
1168: mov [ const 96 ] , reg1 
1200: mov reg1 , const 1680161321 
1224: mov [ const 100 ] , reg1 
1256: mov reg1 , const 25600 
1280: mov [ const 104 ] , reg1 
1312: mov reg1 , const 72 
1336: mov [ const 108 ] , reg1 
1368: ret 
1376: mov reg1 , data 
1396: sne 
1404: add data , const 4 
1428: mov reg2 , const 10 
1452: neg reg2 
1464: mov reg3 , reg1 + const 0 
1496: mov [ reg3 ] , reg2 
1524: sne 
1532: mov data , reg1 
1552: ret 
1560: mov reg1 , data 
1580: sne 
1588: add data , const 8 
1612: mov reg2 , const 0 
1636: mov reg3 , reg1 + const 4 
1668: mov [ reg3 ] , reg2 
1696: mov reg2 , const 8 
1720: add reg2 , const 0 
1744: mov reg3 , const 32 
1768: mov reg3 , [ reg3 ] 
1796: mov [ reg2 ] , reg3 
1824: mov reg2 , const 8 
1848: add reg2 , const 4 
1872: mov reg3 , const 16 
1896: mov reg3 , [ reg3 ] 
1924: mov [ reg2 ] , reg3 
1952: mov reg2 , const 8 
1976: add reg2 , const 4 
2000: mov reg2 , [ reg2 ] 
2028: add reg2 , const 0 
2052: mov reg3 , const 48 
2076: mov reg3 , [ reg3 ] 
2104: mov [ reg2 ] , reg3 
2132: mov reg2 , const 8 
2156: add reg2 , const 4 
2180: mov reg2 , [ reg2 ] 
2208: add reg2 , const 4 
2232: mov reg3 , const 0 
2256: mov [ reg2 ] , reg3 
2284: mov reg1 , const 0 
2308: inc data 
2320: fcmp [ const 0 ] , const 1067030938 
2356: je const 2284 
2372: ret 
2380: mov reg2 , const 4 
2404: mov reg3 , const 7 
2428: mov reg4 , const 2 
2452: mov reg5 , const 3 
2476: mov reg6 , const 10 
2500: mov reg7 , const 2 
2524: and reg3 , reg4 
2544: mul reg3 , reg5 
2564: add reg3 , reg6 
2584: div reg3 , reg7 
2604: mov [ reg2 ] , reg3 
2632: pushn reg1 , const 2 
2656: mov reg2 , const 68 
2680: mov reg2 , [ reg2 ] 
2708: push reg2 
2720: mov reg2 , const 4 
2744: mov reg2 , [ reg2 ] 
2772: push reg2 
2784: se 
2792: call const 12 
2808: mov reg3 , reg1 
2828: sub data , const 8 
2852: pop reg1 , const 2 
2876: mov reg2 , reg3 
2896: mov reg2 , const 8 
2920: mov reg3 , const 4 
2944: mov reg3 , [ reg3 ] 
2972: cmp reg3 , reg2 
2992: jne const 3048 
3008: mov reg3 , const 1 
3032: jmp const 3072 
3048: mov reg3 , const 0 
3072: mov reg2 , reg3 
3092: cmp reg2 , const 0 
3116: je const 3224 
3132: mov reg3 , const 4 
3156: mov reg4 , const 16 
3180: mov [ reg3 ] , reg4 
3208: jmp const 3328 
3224: mov reg3 , const 4 
3248: mov reg4 , const 78 
3272: mov reg4 , [ reg4 ] 
3300: mov [ reg3 ] , reg4 
3328: pushn reg1 , const 3 
3352: mov reg2 , const 108 
3376: mov reg2 , [ reg2 ] 
3404: push reg2 
3416: mov reg2 , const 4 
3440: mov reg2 , [ reg2 ] 
3468: push reg2 
3480: call const 12 
3496: mov reg4 , reg1 
3516: sub data , const 8 
3540: pop reg1 , const 3 
3564: mov reg3 , reg4 
3584: sne 
3592: mov data , reg1 
3612: mov reg1 , const 4 
3636: mov reg1 , [ reg1 ] 
3664: ret 
3672:  <Link Section>
	<Imports>
		__cdecl void printf(*char,?) @ 2800
		__mem DWORD style @ 3264
		__cdecl void printf(*char,?) @ 3488
	<Uses>
		global @ 172
		global @ 228
		global @ 264
		global @ 284
		global @ 340
		global @ 396
		global @ 452
		global @ 488
		global @ 508
		global @ 564
		global @ 620
		global @ 676
		global @ 732
		global @ 768
		global @ 788
		global @ 844
		global @ 900
		global @ 956
		global @ 1012
		global @ 1068
		global @ 1124
		global @ 1180
		global @ 1236
		global @ 1292
		global @ 1328
		global @ 1348
		global @ 1712
		global @ 1760
		global @ 1840
		global @ 1888
		global @ 1968
		global @ 2068
		global @ 2148
		global @ 2332
		global @ 2396
		global @ 2672
		global @ 2736
		global @ 2936
		global @ 3148
		global @ 3240
		global @ 3368
		global @ 3432
		global @ 3628
	<Exports>
		void TTT(*float) @ 1376
		DWORD Test() @ 1560
	<Info Section>
		test::dd @ 0
		test::nn @ 16
		test::ttt @ 32
		ILinkedList::Item @ 0
		ILinkedList::Next @ 16
		printf(0)::c @ -12
		printf(0)::?CompilerGeneratedID11712873 @ -8
		global(0)::dag @ 0
		global(0)::d2 @ 4
		global(0)::style @ 0
		global(0)::il @ 8
		global(0)::il2 @ 16
		TTT(0)::bb @ -4
		string0 @ 32
		string1 @ 48
		Test(1)::dd @ 0
		string2 @ 68
		Test(1)::chp @ 4
		string3 @ 108
		TTT(1)::d2 @ 0
<End>