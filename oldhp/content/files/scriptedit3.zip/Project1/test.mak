/*ScripEdit*/

  #pragma enable debug_info

  #define _ALLIGN DWORD

  //asm listing

//include_file_insert_pos
//#include "debug\test.asm"

//#include "header\defs.h"


//script_file_insert_pos
#compile "source\test2.c"

#compile "source\test.c"


